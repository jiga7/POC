(function($) {
    $(document).ready(function(){
        /*if(window.location.pathname.indexOf("/servlet/benchmark-data/referential")>0)
            refreshListMethodsOfControl();*/
    });
})(AJS.$ || jQuery);

let resetFormControlMethod = () => {
    AJS.$("input#codeMethodControl").val("");
    AJS.$("input#nameMethodControl").val("");
    AJS.$("#subsidiaryMethodControl").val("");
}

let addControlMethod = () => {
    // GET INPUT VALUE
    let codeValue = AJS.$("input#codeMethodControl").val();
    let methodValue = AJS.$("input#nameMethodControl").val();
    let subsidiaryValue = document.getElementById("subsidiaryMethodControl").value;

    if(codeValue=='' || methodValue=='' || subsidiaryValue=='' ){
        AJS.messages.error("#display-messages", {
            title: "Echec de l'opération",
            body: "<p>Veuillez renseigner tous les champs obligatoires.</p>"
        });
    }else {
        // INIT OBJECT TO POST DATA
        let data = {
            "code" : codeValue,
            "method" : methodValue,
            "subsidiary" : subsidiaryValue
        };
        let url = AJS.contextPath() + "/rest/benchmark-data/1.0/methods/add";

        fetch(url, { method : "POST", headers: [
                ["Content-Type", "application/json"]
            ],
            credentials: "include",
            body: JSON.stringify(data)
        }).then(function(response){
            if(response.status<300){
                resetFormControlMethod();
                refreshListMethodsOfControl();
                AJS.messages.info("#display-messages", {
                    title: "Opération effectuée avec succés",
                    body: "<p>Méthode de contrôle correctement ajoutée.</p>"
                });
            }else{
                AJS.messages.error("#display-messages", {
                    title: "Echec de l'opération",
                    body: "<p>Une erreur est survenue lors de l'exécution de l'opération.</p>"
                });
            }
        }).catch(function(error){
                AJS.messages.error("#display-messages", {
                    title: "Echec sur le serveur",
                    body: "<p>Une erreur est survenue lors de l'exécution de l'opération.</p>"
                });
        });
    }
};

let refreshListMethodsOfControl = () => {

    let subsidiary = document.getElementById("searchSubsidiaryControlMethod").value;
    let url = AJS.contextPath() + `/rest/benchmark-data/1.0/methods/views/${subsidiary}/all`;
    AJS.$("#methods-table tbody").empty();
    $.getJSON(url, function(data) {
        var items = [];
        $.each(data, function(i, item){
            items.push(`<tr>
                            <td>${++i}</td>
                            <td>${item.code}</td>
                            <td class="aui-table-column-unsortable">${item.method}</td>
                            <td>${new Date(item.created).toLocaleDateString()}</td>
                            <td>${item.active? '<span class="aui-lozenge aui-lozenge-success">Activé</span>' : '<span class="aui-lozenge aui-lozenge-subtle aui-lozenge-removed">Dèsactivé</span>'}</td>
                        </tr>`);
        });
        $("<tbody/>", {"class" : "methods-list", html : items.join("")}).appendTo("#methods-table");
    });
};