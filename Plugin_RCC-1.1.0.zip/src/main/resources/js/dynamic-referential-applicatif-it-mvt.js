let resetFormApplicatifITMVT = () => {
    AJS.$("input#codeApplicatifITMVT").val("");
    AJS.$("input#labelApplicatifITMVT").val("");
    AJS.$("#subsidiaryApplicatifITMVT").val("");
}

let addApplicatifITMVT = () => {
    // GET INPUT VALUE
    let codeValue = AJS.$("input#codeApplicatifITMVT").val();
    let labelValue = AJS.$("input#labelApplicatifITMVT").val();
    let subsidiaryValue = document.getElementById("subsidiaryApplicatifITMVT").value;

    if(codeValue=='' || labelValue=='' || subsidiaryValue=='' ){
        AJS.messages.error("#display-messages", {
            title: "Echec de l'opération",
            body: "<p>Veuillez renseigner tous les champs obligatoires.</p>"
        });
    }else {
        // INIT OBJECT TO POST DATA
        let data = {
            "code" : codeValue,
            "lib" : labelValue,
            "subsidiary": subsidiaryValue
        };
        let url = AJS.contextPath() + "/rest/benchmark-data/1.0/applicatifs/movement/add";

        fetch(url, { method : "POST", headers: [
                ["Content-Type", "application/json"]
            ],
            credentials: "include",
            body: JSON.stringify(data)
        }).then(function(response){
            if(response.status<300){
                resetFormApplicatifITMVT();
                refreshListApplicatifITMVT();
                AJS.messages.info("#display-messages", {
                    title: "Opération effectuée avec succés",
                    body: "<p>Applicatif de type <b>Mouvement</b> correctement ajouté.</p>"
                });
            }else{
                AJS.messages.error("#display-messages", {
                    title: "Echec de l'opération",
                    body: "<p>Une erreur est survenue lors de l'exécution de l'opération.</p>"
                });
            }
        }).catch(function(error){
        });
    }
}

let refreshListApplicatifITMVT = () => {

    let subsidiary = document.getElementById("searchSubsidiaryApplicatifITMVT").value;
    let url = AJS.contextPath() + `/rest/benchmark-data/1.0/applicatifs/views/${subsidiary}/movement`;

    AJS.$("#applicatifITMVT-table tbody").empty();
    $.getJSON(url, function(data) {
        var items = [];
        $.each(data, function(i, item){
            items.push(`<tr>
                            <td>${++i}</td>
                            <td>${item.code}</td>
                            <td class="aui-table-column-unsortable">${item.lib}</td>
                            <td class="aui-table-column-unsortable">${item.subsidiary}</td>
                            <td>Mouvement</td>
                            <td>${item.active? '<span class="aui-lozenge aui-lozenge-success">Activé</span>' : '<span class="aui-lozenge aui-lozenge-subtle aui-lozenge-removed">Dèsactivé</span>'}</td>
                        </tr>`);
        });
        $("<tbody/>", {"class" : "applicatifITMVT-list", html : items.join("")}).appendTo("#applicatifITMVT-table");
    });
}