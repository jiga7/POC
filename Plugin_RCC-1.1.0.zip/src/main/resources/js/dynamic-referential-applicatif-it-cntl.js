let resetFormApplicatifITCNTL = () => {
    AJS.$("input#codeApplicatifITCNTL").val("");
    AJS.$("input#labelApplicatifITCNTL").val("");
    AJS.$("subsidiaryApplicatifITCNTL").val("");
}

let addApplicatifITCNTL = () => {
    // GET INPUT VALUE
    let codeValue = AJS.$("input#codeApplicatifITCNTL").val();
    let labelValue = AJS.$("input#labelApplicatifITCNTL").val();
    let subsidiaryValue = document.getElementById("subsidiaryApplicatifITCNTL").value;

    if(codeValue=='' || labelValue=='' || subsidiaryValue=='' ){
        AJS.messages.error("#display-messages", {
            title: "Echec de l'opération",
            body: "<p>Veuillez renseigner tous les champs obligatoires.</p>"
        });
    }else {
        // INIT OBJECT TO POST DATA
        let data = {
            "code" : codeValue,
            "lib" : labelValue,
            "subsidiary": subsidiaryValue
        };
        let url = AJS.contextPath() + "/rest/benchmark-data/1.0/applicatifs/control/add";

        fetch(url, { method : "POST", headers: [
                ["Content-Type", "application/json"]
            ],
            credentials: "include",
            body: JSON.stringify(data)
        }).then(function(response){
            if(response.status<300){
                resetFormApplicatifITCNTL();
                refreshListApplicatifITCNTL();
                AJS.messages.info("#display-messages", {
                    title: "Opération effectuée avec succés",
                    body: "<p>Applicatif de type <b>Mouvement</b> correctement ajouté.</p>"
                });
            }else{
                AJS.messages.error("#display-messages", {
                    title: "Echec de l'opération",
                    body: "<p>Une erreur est survenue lors de l'exécution de l'opération.</p>"
                });
            }
        }).catch(function(error){
        });
    }
}

let refreshListApplicatifITCNTL = () => {

    let subsidiary = document.getElementById("searchSubsidiaryApplicatifITCNTL").value;
    let url = AJS.contextPath() + `/rest/benchmark-data/1.0/applicatifs/views/${subsidiary}/control`;

    AJS.$("#applicatifITCNTL-table tbody").empty();
    $.getJSON(url, function(data) {
        var items = [];
        $.each(data, function(i, item){
            items.push(`<tr>
                            <td>${++i}</td>
                            <td>${item.code}</td>
                            <td class="aui-table-column-unsortable">${item.lib}</td>
                            <td class="aui-table-column-unsortable">${item.subsidiary}</td>
                            <td>Contrôle</td>
                            <td>${item.active? '<span class="aui-lozenge aui-lozenge-success">Activé</span>' : '<span class="aui-lozenge aui-lozenge-subtle aui-lozenge-removed">Dèsactivé</span>'}</td>
                        </tr>`);
        });
        $("<tbody/>", {"class" : "applicatifITCNTL-list", html : items.join("")}).appendTo("#applicatifITCNTL-table");
    });
}