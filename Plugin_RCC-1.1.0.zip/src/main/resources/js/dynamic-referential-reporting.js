let resetFormReporting = () => {
    AJS.$("input#codeReporting").val("");
    AJS.$("input#nameReporting").val("");
    AJS.$("#subsidiaryReporting").val("");
}

let addReporting = () => {
    // GET INPUT VALUE
    let codeValue = AJS.$("input#codeReporting").val();
    let labelValue = AJS.$("input#nameReporting").val();
    let subsidiaryValue = document.getElementById("subsidiaryReporting").value;

    if(codeValue=='' || labelValue=='' || subsidiaryValue=='' ){
        AJS.messages.error("#display-messages", {
            title: "Echec de l'opération",
            body: "<p>Veuillez renseigner tous les champs obligatoires.</p>"
        });
    }else {
        // INIT OBJECT TO POST DATA
        let data = {
            "code" : codeValue,
            "lib" : labelValue,
            "subsidiary": subsidiaryValue
        };
        let url = AJS.contextPath() + "/rest/benchmark-data/1.0/reporting/add";

        fetch(url, { method : "POST", headers: [
                ["Content-Type", "application/json"]
            ],
            credentials: "include",
            body: JSON.stringify(data)
        }).then(function(response){
            if(response.status<300){
                refreshListReporting();
                resetFormReporting();
                AJS.messages.info("#display-messages", {
                    title: "Opération effectuée avec succés",
                    body: "<p>Reporting correctement ajouté.</p>"
                });
            }else{
                AJS.messages.error("#display-messages", {
                    title: "Echec de l'opération",
                    body: "<p>Une erreur est survenue lors de l'exécution de l'opération.</p>"
                });
            }
        }).catch(function(error){
        });
    }
}

let refreshListReporting = () => {

    let subsidiary = document.getElementById("searchSubsidiaryReporting").value;
    let url = AJS.contextPath() + `/rest/benchmark-data/1.0/reporting/views/${subsidiary}/all`;
    AJS.$("#reportings-table tbody").empty();
    $.getJSON(url, function(data) {
        var items = [];
        $.each(data, function(i, item){
            items.push(`<tr>
                            <td>${++i}</td>
                            <td>${item.code}</td>
                            <td class="aui-table-column-unsortable">${item.lib}</td>
                            <td>${item.active? '<span class="aui-lozenge aui-lozenge-success">Activé</span>' : '<span class="aui-lozenge aui-lozenge-subtle aui-lozenge-removed">Dèsactivé</span>'}</td>
                        </tr>`);
        });
        $("<tbody/>", {"class" : "reportings-list", html : items.join("")}).appendTo("#reportings-table");
    });
}