/*AJS.$(document).on('change', "#searchSubsidiaryCheckAccount", function() {

    refreshListControl();
});*/

AJS.$(document).on('click', "button#controlRefreshButton", function(){
    refreshListControl();
});

let loadControlForEdit = (key) => {

};

AJS.$(document).on('change', "input#controlImportFile", function(e) {
     $('button#controlImportSubmit').attr('disabled', e.target.files.length<1);
});

AJS.$(document).on("click", "button#controlImportButton", function (e) {
    e.preventDefault();
    AJS.dialog2("#controlImportDialog").show();
    $('button#controlImportSubmit').attr('disabled', true);
    addListProjectToSelect(['controlImportSubsidiary']);
});

AJS.$(document).on("click", "button#controlImportCancel", function (e) {
    e.preventDefault();
    $('input#controlImportSubsidiary').val("");
    $('input#controlImportFile').val("");
    AJS.dialog2("#controlImportDialog").hide();
});

AJS.$(document).on("click", "button#controlImportSubmit", function (e) {
    e.preventDefault();
    $('button#controlImportSubmit').attr('disabled', true);
    let subsidiaryElt = document.getElementById("controlImportSubsidiary");
    let subsidiary = subsidiaryElt!=null? subsidiaryElt.value : null;
    let file = $('input#controlImportFile').get(0).files[0];
    if(subsidiary!==undefined && subsidiary!=null && subsidiary.length>2 && file!==undefined){
        const formData = new FormData();
        formData.append('controlFile', file);
        let url = AJS.contextPath() + `/rest/benchmark-data/1.0/controls/data/${subsidiary}/import`;
        fetch(url, {method:'POST', headers: [
                ["X-Atlassian-Token", "no-check"]
            ],
            credentials: "include",
            body: file
        }).then(response => response.json()
        ).then(data => {
        }).catch(error => {
        })
    }else{
    }
});

AJS.$('button#testButton').click(function(e){
    e.preventDefault();
    AJS.dialog2('#test-dialog').show();
});

let refreshListControl = () => {
    let subsidiary = document.getElementById("searchSubsidiaryCheckAccount").value;
    let url =AJS.contextPath() + `/rest/benchmark-data/1.0/controls/${subsidiary}/lists`;

    AJS.$("#controls-table tbody").empty();
    $.getJSON(url, function(data) {
        var items = [];
        $.each(data, function(i, item){
            items.push(`<tr>
                            <td class="hidden">${item.key}</td>
                            <td>${item.chap}</td>
                            <td>${item.ncp}</td>
                            <td>${item.inti}</td>
                            <td>${item.age}</td>
                            <td>${item.libDev}</td>
                            <td>${item.soul}</td>
                            <td>${item.methodControl?.method}</td>
                            <td class="hidden">${item.key}</td>
                            <td class="hidden">${item.key}</td>
                            <td class="hidden">${item.key}</td>
                            <td>${item.frequency}</td>
                            <td>${item.status}</td> /* /refapp */
                            <td><a href="/plugins/servlet/benchmark-data/control?key=${item.key}"><span class="aui-icon aui-icon-small aui-iconfont-edit-filled"></span></a></td>
                        </tr>`);
        });
        $("<tbody/>", {"class" : "controls-lists", html: items.join("")}).appendTo("#controls-table");
        $('#controls-table').tablemanager({
            firstSort: [[5,0],[6,0]],
            disable: ["last"],
            appendFilterby: true,
            dateFormat: [], //[4,"mm-dd-yyyy"]
            debug: false,
            vocabulary: {
                voc_filter_by: 'Filtrer par ',
                voc_type_here_filter: '...',
                voc_show_rows: 'Lignes par page'
            },
            pagination: true,
            showrows: [10,20,50,100,500],
            disableFilterBy: [1,9,10,11]
        });
    });
};



AJS.$(document).on("click", "button#upload-file-submit", function (e) {
    e.preventDefault();
    let file = $('input#upload-file').get(0).files[0];
    let path = $('input#file-path').val();

    if(file!==undefined && file !==null && path!==undefined){
        let filename = file.name;

        var formData = new FormData();
        formData.append('file', file);
        formData.append('filename', filename);
        formData.append('path', path);
        AJS.$.ajax({
            type: "POST",
            async: true,
            cache: false,
            credentials: "include",
            url: AJS.contextPath() + `/rest/benchmark-data/1.0/log/fileloaded/upload-file`,
            contentType: false,
            processData: false,
            data: formData,
            dataType: 'text',
            success: function(data){
                location.reload();
            },
            error: function(msg){
            console.log(msg);
            },complete: function(){
                console.ok('ok');
            }
        });
    }
});