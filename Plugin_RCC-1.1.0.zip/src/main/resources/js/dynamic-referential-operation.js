let resetFormOperation = () => {
    AJS.$("input#codeOperation").val("");
    AJS.$("input#labelOperation").val("")
    AJS.$("subsidiaryOperation").val("");
}

let addOperation = () => {
    // GET INPUT VALUE
    let codeValue = AJS.$("input#codeOperation").val();
    let labelValue = AJS.$("input#labelOperation").val();
    let subsidiaryValue = document.getElementById("subsidiaryOperation").value;

    if(codeValue=='' || labelValue=='' || subsidiaryValue=='' ){
        AJS.messages.error("#display-messages", {
            title: "Echec de l'opération",
            body: "<p>Veuillez renseigner tous les champs obligatoires.</p>"
        });
    }else {
        // INIT OBJECT TO POST DATA
        let data = {
            "ope" : codeValue,
            "lib" : labelValue,
            "subsidiary": subsidiaryValue
        };
        let url = AJS.contextPath() + "/rest/benchmark-data/1.0/operations/add";

        fetch(url, { method : "POST", headers: [
                ["Content-Type", "application/json"]
            ],
            credentials: "include",
            body: JSON.stringify(data)
        }).then(function(response){
            if(response.status<300){
                refreshListOperation();
                resetFormOperation();
                AJS.messages.info("#display-messages", {
                    title: "Opération effectuée avec succés",
                    body: "<p>Opération correctement ajoutée.</p>"
                });
            }else{
                AJS.messages.error("#display-messages", {
                    title: "Echec de l'opération",
                    body: "<p>Une erreur est survenue lors de l'exécution de l'opération.</p>"
                });
            }
        }).catch(function(error){
        });
    }
}

let refreshListOperation = () => {
    let subsidiary = document.getElementById("searchSubsidiaryOperation").value;
    let url = AJS.contextPath() + `/rest/benchmark-data/1.0/operations/views/${subsidiary}/all`;

    AJS.$("#operations-table tbody").empty();
    $.getJSON(url, function(data) {
        var items = [];
        $.each(data, function(i, item){
            items.push(`<tr>
                            <td>${++i}</td>
                            <td>${item.ope}</td>
                            <td class="aui-table-column-unsortable">${item.lib}</td>
                            <td>${item.subsidiary}</td>
                            <td>${item.active? '<span class="aui-lozenge aui-lozenge-success">Activé</span>' : '<span class="aui-lozenge aui-lozenge-subtle aui-lozenge-removed">Dèsactivé</span>'}</td>
                        </tr>`);
        });
        $("<tbody/>", {"class" : "opera", html : items.join("")}).appendTo("#operations-table");
    });
};