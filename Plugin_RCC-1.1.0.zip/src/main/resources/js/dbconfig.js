function refreshProperties(){
    AJS.$('form#formSubsidiary').submit();
}