(function($) {
    $(document).ready(function(){

        // Import data in control;
        let searchParams = new URLSearchParams(window.location.search);
        let keyControl = searchParams.has('key')? searchParams.get('key') : null;
        putDataInForm(keyControl);
    });
})(AJS.$ || jQuery);

// Only for test
let users = {"self":"http://localhost:9060/rest/api/2/group/member?includeInactiveUsers=false&maxResults=50&groupname=jira-core-users&startAt=0","maxResults":50,"startAt":0,"total":12,"isLast":true,"values":[{"self":"http://localhost:9060/rest/api/2/user?username=admin","name":"admin","key":"admin","emailAddress":"admin@b.com","avatarUrls":{"48x48":"http://localhost:9060/secure/useravatar?avatarId=10346","24x24":"http://localhost:9060/secure/useravatar?size=small&avatarId=10346","16x16":"http://localhost:9060/secure/useravatar?size=xsmall&avatarId=10346","32x32":"http://localhost:9060/secure/useravatar?size=medium&avatarId=10346"},"displayName":"Administrator","active":true,"timeZone":"Africa/Casablanca"},{"self":"http://localhost:9060/rest/api/2/user?username=agcr1","name":"agcr1","key":"JIRAUSER10302","emailAddress":"agcr1@aa.cc","avatarUrls":{"48x48":"http://localhost:9060/secure/useravatar?avatarId=10336","24x24":"http://localhost:9060/secure/useravatar?size=small&avatarId=10336","16x16":"http://localhost:9060/secure/useravatar?size=xsmall&avatarId=10336","32x32":"http://localhost:9060/secure/useravatar?size=medium&avatarId=10336"},"displayName":"Agent Courrier 1","active":true,"timeZone":"Africa/Casablanca"},{"self":"http://localhost:9060/rest/api/2/user?username=agcr2","name":"agcr2","key":"JIRAUSER10303","emailAddress":"agcr2@aa.cc","avatarUrls":{"48x48":"https://www.gravatar.com/avatar/1cbcc5ce4c86bee0f2c73fe0170c8317?d=mm&s=48","24x24":"https://www.gravatar.com/avatar/1cbcc5ce4c86bee0f2c73fe0170c8317?d=mm&s=24","16x16":"https://www.gravatar.com/avatar/1cbcc5ce4c86bee0f2c73fe0170c8317?d=mm&s=16","32x32":"https://www.gravatar.com/avatar/1cbcc5ce4c86bee0f2c73fe0170c8317?d=mm&s=32"},"displayName":"Agent Courrier 2","active":true,"timeZone":"Africa/Casablanca"},{"self":"http://localhost:9060/rest/api/2/user?username=arch1","name":"arch1","key":"JIRAUSER10300","emailAddress":"arch1@aaa.cc","avatarUrls":{"48x48":"http://localhost:9060/secure/useravatar?avatarId=10503","24x24":"http://localhost:9060/secure/useravatar?size=small&avatarId=10503","16x16":"http://localhost:9060/secure/useravatar?size=xsmall&avatarId=10503","32x32":"http://localhost:9060/secure/useravatar?size=medium&avatarId=10503"},"displayName":"Archiviste 1","active":true,"timeZone":"Africa/Casablanca"},{"self":"http://localhost:9060/rest/api/2/user?username=arch2","name":"arch2","key":"JIRAUSER10301","emailAddress":"arch2@aaa.cc","avatarUrls":{"48x48":"https://www.gravatar.com/avatar/ec9ff230ef1e196341c92935921f5b1c?d=mm&s=48","24x24":"https://www.gravatar.com/avatar/ec9ff230ef1e196341c92935921f5b1c?d=mm&s=24","16x16":"https://www.gravatar.com/avatar/ec9ff230ef1e196341c92935921f5b1c?d=mm&s=16","32x32":"https://www.gravatar.com/avatar/ec9ff230ef1e196341c92935921f5b1c?d=mm&s=32"},"displayName":"Archiviste 2","active":true,"timeZone":"Africa/Casablanca"},{"self":"http://localhost:9060/rest/api/2/user?username=boo","name":"boo","key":"JIRAUSER10201","emailAddress":"boo@b.com","avatarUrls":{"48x48":"http://localhost:9060/secure/useravatar?avatarId=10341","24x24":"http://localhost:9060/secure/useravatar?size=small&avatarId=10341","16x16":"http://localhost:9060/secure/useravatar?size=xsmall&avatarId=10341","32x32":"http://localhost:9060/secure/useravatar?size=medium&avatarId=10341"},"displayName":"Back Officer","active":true,"timeZone":"Africa/Casablanca"},{"self":"http://localhost:9060/rest/api/2/user?username=bov","name":"bov","key":"JIRAUSER10202","emailAddress":"bov@b.com","avatarUrls":{"48x48":"http://localhost:9060/secure/useravatar?avatarId=10504","24x24":"http://localhost:9060/secure/useravatar?size=small&avatarId=10504","16x16":"http://localhost:9060/secure/useravatar?size=xsmall&avatarId=10504","32x32":"http://localhost:9060/secure/useravatar?size=medium&avatarId=10504"},"displayName":"Back Officer Valideur","active":true,"timeZone":"Africa/Casablanca"},{"self":"http://localhost:9060/rest/api/2/user?username=foo1","name":"foo1","key":"foo1","emailAddress":"foo1@b.com","avatarUrls":{"48x48":"http://localhost:9060/secure/useravatar?avatarId=10342","24x24":"http://localhost:9060/secure/useravatar?size=small&avatarId=10342","16x16":"http://localhost:9060/secure/useravatar?size=xsmall&avatarId=10342","32x32":"http://localhost:9060/secure/useravatar?size=medium&avatarId=10342"},"displayName":"Front Officer 1","active":true,"timeZone":"Africa/Casablanca"},{"self":"http://localhost:9060/rest/api/2/user?username=foo2","name":"foo2","key":"foo2","emailAddress":"foo2@b.com","avatarUrls":{"48x48":"https://www.gravatar.com/avatar/272aac01c21bb33eae817f091af64ddb?d=mm&s=48","24x24":"https://www.gravatar.com/avatar/272aac01c21bb33eae817f091af64ddb?d=mm&s=24","16x16":"https://www.gravatar.com/avatar/272aac01c21bb33eae817f091af64ddb?d=mm&s=16","32x32":"https://www.gravatar.com/avatar/272aac01c21bb33eae817f091af64ddb?d=mm&s=32"},"displayName":"Front Officer 2","active":true,"timeZone":"Africa/Casablanca"},{"self":"http://localhost:9060/rest/api/2/user?username=fov1","name":"fov1","key":"fov1","emailAddress":"fov1@b.com","avatarUrls":{"48x48":"https://www.gravatar.com/avatar/c02434592ca219e56012ec1e8698b3ed?d=mm&s=48","24x24":"https://www.gravatar.com/avatar/c02434592ca219e56012ec1e8698b3ed?d=mm&s=24","16x16":"https://www.gravatar.com/avatar/c02434592ca219e56012ec1e8698b3ed?d=mm&s=16","32x32":"https://www.gravatar.com/avatar/c02434592ca219e56012ec1e8698b3ed?d=mm&s=32"},"displayName":"Front Officer Valideur 1","active":true,"timeZone":"Africa/Casablanca"},{"self":"http://localhost:9060/rest/api/2/user?username=fov2","name":"fov2","key":"JIRAUSER10200","emailAddress":"fov2@b.com","avatarUrls":{"48x48":"http://localhost:9060/secure/useravatar?avatarId=10339","24x24":"http://localhost:9060/secure/useravatar?size=small&avatarId=10339","16x16":"http://localhost:9060/secure/useravatar?size=xsmall&avatarId=10339","32x32":"http://localhost:9060/secure/useravatar?size=medium&avatarId=10339"},"displayName":"Front Officer Valideur 2","active":true,"timeZone":"Africa/Casablanca"},{"self":"http://localhost:9060/rest/api/2/user?username=SUP","name":"SUP","key":"JIRAUSER10203","emailAddress":"abc@bac.com","avatarUrls":{"48x48":"http://localhost:9060/secure/useravatar?avatarId=10347","24x24":"http://localhost:9060/secure/useravatar?size=small&avatarId=10347","16x16":"http://localhost:9060/secure/useravatar?size=xsmall&avatarId=10347","32x32":"http://localhost:9060/secure/useravatar?size=medium&avatarId=10347"},"displayName":"Superviseur","active":true,"timeZone":"Africa/Casablanca"}]};

let refreshListReporting = (control) => {

    let subsidiary = document.getElementById("subsidiary").value;
    let url = AJS.contextPath() + `/rest/benchmark-data/1.0/reporting/lists/${subsidiary}`;

    AJS.$("#reportingListSelect2").empty();
    $.getJSON(url, function(data){
        let items = [];
        $.each(data, function(i, item){
            items.push(`<option value="${item.value}">${item.label}</option>`);
        });
        $(items.join("")).appendTo("#reportingListSelect2");
        $("#reportingListSelect2").val(
            $.map(control.reportings, function(value, index){
                return [value.id.toString()];
            })
        );
        $("#reportingListSelect2").change();
    });
};

let refreshListMethodControl = (control) => {

    let subsidiary = document.getElementById("subsidiary").value;
    let url = AJS.contextPath() + `/rest/benchmark-data/1.0/methods/lists/${subsidiary}`;

    AJS.$("#methodControl").empty();
    $.getJSON(url, function(data){
        let items = [];
        $.each(data, function(i, item){
            items.push(`<option value="${item.value}">${item.label}</option>`);
        });
        $(items.join("")).appendTo("#methodControl");
        $("#methodControl").val(control?.methodControl?.code);
        $("#methodControl").change();
    });
};

let refreshListApplicatifITCNTL = (control) => {

    let subsidiary = document.getElementById("subsidiary").value;
    let url = AJS.contextPath() + `/rest/benchmark-data/1.0/applicatifs/lists/control/${subsidiary}`;

    AJS.$("#applicatifsITCNTLListSelect2 select").empty();
    $.getJSON(url, function(data) {
        let items = [];
        $.each(data, function(i, item){
            items.push(`<option value="${item.value}">${item.label}</option>`);
        });
        $(items.join("")).appendTo("#applicatifsITCNTLListSelect2");
        $("#applicatifsITCNTLListSelect2").val(
            $.map(control.applicatifIts, function(value, index){
                 return [value.id.toString()];
            })
        );
        $("#applicatifsITCNTLListSelect2").change();
    });
};

let refreshListApplicatifITMVT = (control) => {

    let subsidiary = document.getElementById("subsidiary").value;
    let url = AJS.contextPath() + `/rest/benchmark-data/1.0/applicatifs/lists/movement/${subsidiary}`;

    AJS.$("#applicatifsITMVTListSelect2 select").empty();
    $.getJSON(url, function(data) {
        let items = [];
        $.each(data, function(i, item){
            items.push(`<option value="${item.value}">${item.label}</option>`);
        });
        $(items.join("")).appendTo("#applicatifsITMVTListSelect2");
        $("#applicatifsITMVTListSelect2").val(
            $.map(control.applicatifIts, function(value, index){
              return [value.id.toString()];
            })
         );
        $("#applicatifsITMVTListSelect2").change();
    });
};

let refreshListOperations = (control) => {

    let subsidiary = document.getElementById("subsidiary").value;
    let url = AJS.contextPath() + `/rest/benchmark-data/1.0/operations/lists/${subsidiary}`;

    AJS.$("#operationsListSelect2").empty();
    $.getJSON(url, function(data){
        let items = [];
        $.each(data, function(i, item){
            items.push(`<option value="${item.value}">${item.label}</option>`);
        });
        $(items.join("")).appendTo("#operationsListSelect2");
        $("#operationsListSelect2").val(
           $.map(control.operations, function(value, index){
                return [value.id.toString()];
           })
        );
        $("#operationsListSelect2").change();
    });
};

let refreshListController = (control) => {

    let subsidiary = document.getElementById("subsidiary").value;
    let url = `http://localhost:9060/rest/api/2/group/member?groupname=jira-core-users&includeInactiveUsers=false`;
    AJS.$("#controllerListSelect2").empty();
  //  $.getJSON(users.values, function(data){
        let items = [];
        $.each(users.values, function(i, item){
            items.push(`<option value="${item.displayName}(${item.name})">${item.displayName}</option>`);
        });
        $(items.join("")).appendTo("#controllerListSelect2");
        $("#controllerListSelect2").val(`${control?.officerFullname}(${control.officer})`);
        $("#controllerListSelect2").change();
 //   });
};

let refreshListContributors = (control) => {

    let subsidiary = document.getElementById("subsidiary").value;
    let url = `http://localhost:9060/rest/api/2/group/member?groupname=jira-core-users&includeInactiveUsers=false`;
    AJS.$("#contributorListSelect2").empty();
    //$.getJSON(url, function(data){
        let items = [];
        $.each(users.values, function(i, item){
            items.push(`<option value="${item.displayName}(${item.name})">${item.displayName}</option>`);
        });
        $(items.join("")).appendTo("#contributorListSelect2");
        $("#contributorListSelect2").val(
            $.map(control.contributors, function(value, index){
                 return [value.id.toString()];
            })
         );
        $("#contributorListSelect2").change();
    //});
};

let refreshListValidor1 = (control) => {

    let subsidiary = document.getElementById("subsidiary").value;
    let url = `http://localhost:9060/rest/api/2/group/member?groupname=jira-core-users&includeInactiveUsers=false`;
    AJS.$("#validor1ListSelect2").empty();
    //$.getJSON(users.values, function(data){
        let items = [];
        $.each(users.values, function(i, item){
            items.push(`<option value="${item.displayName}(${item.name})">${item.displayName}</option>`);
        });
        $(items.join("")).appendTo("#validor1ListSelect2");
        $("#validor1ListSelect2").val(`${control?.validor1Fullname}(${control.validor1})`);
        $("#validor1ListSelect2").change();
    //});
};

let refreshListValidor2 = (control) => {

    let subsidiary = document.getElementById("subsidiary").value;
    let url = `http://localhost:9060/rest/api/2/group/member?groupname=jira-core-users&includeInactiveUsers=false`;
    AJS.$("#validor2ListSelect2").empty();
   // $.getJSON(users.values, function(data){
        let items = [];
        $.each(users.values, function(i, item){
            items.push(`<option value="${item.displayName}(${item.name})">${item.displayName}</option>`);
        });
        $(items.join("")).appendTo("#validor2ListSelect2");
        $("#validor2ListSelect2").val(`${control?.validor2Fullname}(${control.validor2})`);
        $("#validor2ListSelect2").change();
   // });
};

let putDataInForm = (key) => {

    let url = AJS.contextPath() + `/rest/benchmark-data/1.0/controls/${key}`;
    $.getJSON(url, function(control) {
        console.log(control);
        result = control;
        if(control!=null){
            $("input#subsidiary").val(control.subsidiary);
            $("#reportingListSelect2").auiSelect2();
            refreshListReporting(control);
            $("#contributorListSelect2").auiSelect2();
            refreshListContributors(control);
            $("#applicatifsITMVTListSelect2").auiSelect2();
            refreshListApplicatifITMVT(control);
            $("#applicatifsITCNTLListSelect2").auiSelect2();
            refreshListApplicatifITCNTL(control);
            $("#controllerListSelect2").auiSelect2();
            refreshListController(control);
            $("#validor1ListSelect2").auiSelect2();
            refreshListValidor1(control);
            $("#validor2ListSelect2").auiSelect2();
            refreshListValidor2(control);
            $("#operationsListSelect2").auiSelect2();
            refreshListOperations(control);
            $("#methodControl").auiSelect2();
            refreshListMethodControl(control);

            $("input#controlKEY").val(control.key);
            $("input#descChapCpt").val(control.descChapCpt);
            $("#typMvt").val(control.typMvt);
            $("#riskCompt").val(control.riskCompt);
            $("#duration").val(control.duration);
            $("input#delaiSuspens").val(control.delaiSuspens);
            $("#orig").val(control.orig);
            $("#frequency").val(control.frequency);
            $("input#durationValid1").val(control.durationValid1);
            $("input#durationValid2").val(control.durationValid2);
            $(control.sensible==="O"? "#sensibleO" : "#sensibleN").attr("checked", true);

            displayPCIData(control);
        }
    });
};

let displayPCIData = (control) => {
        var items = [];
        items.push(`<tr>
                        <th class="row">ID:</th>
                        <td class="resource-key"><code>${control.key}</code></td>
                    </tr>`);
        items.push(`<tr>
                        <th class="row">Chapitre:</th>
                        <td class="resource-key"><code>${control.chap}</code></td>
                    </tr>`);
        items.push(`<tr>
                        <th class="row">Libellé chapitre:</th>
                        <td class="resource-key"><code>${control.libChap}</code></td>
                    </tr>`);
        items.push(`<tr>
                        <th class="row">Numéro de compte:</th>
                        <td class="resource-key"><code>${control.ncp}</code></td>
                    </tr>`);
        items.push(`<tr>
                        <th class="row">Intitulé du compte:</th>
                        <td class="resource-key"><code>${control.inti}</code></td>
                    </tr>`);
        items.push(`<tr>
                        <th class="row">Code devise:</th>
                        <td class="resource-key"><code>${control.dev}</code></td>
                    </tr>`);
        items.push(`<tr>
                        <th class="row">Devise:</th>
                        <td class="resource-key"><code>${control.libDev}</code></td>
                    </tr>`);
        items.push(`<tr>
                        <th class="row">Code agence:</th>
                        <td class="resource-key"><code>${control.age}</code></td>
                    </tr>`);
        items.push(`<tr>
                        <th class="row">Statut du compte:</th>
                        <td class="resource-key"><code>${control.accountStatus}</code></td>
                    </tr>`);
        items.push(`<tr>
                        <th class="row">Soumis à lettrage:</th>
                        <td class="resource-key"><code>${control.soul}</code></td>
                    </tr>`);
        items.push(`<tr>
                        <th class="row">Sens du compte:</th>
                        <td class="resource-key"><code>${control.sbi}</code></td>
                    </tr>`);
        $("<tbody/>", {"class" : "data-pci", html : items.join("")}).appendTo("#data-pci-table");
};

AJS.$(document).on('click', '#saveFieldHorsPCIButton', function() {
    let controlKEY = $("input#controlKEY").val();
    let applicatifsIT = [];
    $.each($("#applicatifsITMVTListSelect2").val(), function(i, app){
        applicatifsIT.push({"id": parseInt(app), "typ": "MVT"});
    });
    $.each($("#applicatifsITCNTLListSelect2").val(), function(i, app){
        applicatifsIT.push({"id": parseInt(app), "typ": "CNTL"});
    });
    let reportings = [];
    $.each($("#reportingListSelect2").val(), function(i, rep){
        reportings.push({"id": parseInt(rep)});
    });
    let operations = [];
    $.each($("#operationsListSelect2").val(), function(i, ope) {
        operations.push({"id" : parseInt(ope) });
    });
    let contributors = [];
    $.each($("#contributorListSelect2").val(), function(i, contributor){
        contributors.push( {"username" : contributor.split("(")[1].replace(")", ""), "fullname" : contributor.split("(")[0], "subsidiary" : $("input#subsidiary").val() });
    });

    let data = {
        "key" : controlKEY,
        "descChapCpt" : $("input#descChapCpt").val(),
        "delaiSuspens" : $("input#delaiSuspens").val(),
        "typMvt" : $("#typMvt").val(),
        "riskCompt" : $("#riskCompt").val(),
        "duration" : $("#duration").val(),
        "orig" : $("#orig").val(),
        "frequency" : $("#frequency").val(),
        "sensible" : $("#sensibleO").is(":checked")? "O" : ($("#sensibleN").is(":checked")? "N" : ""),
        "durationValid1" : $("input#durationValid1").val(),
        "durationValid2" : $("input#durationValid2").val(),
        "reporting" : $("reportingListSelect2").val(),
        "methodControl" : {"code" : $('#methodControl').val()},
        "officer" : $("#controllerListSelect2").val()?.length > 4 ? $("#controllerListSelect2").val().split("(")[1].replace(")", ""):"",
        "officerFullname" : $("#controllerListSelect2").val()?.length > 4 ? $("#controllerListSelect2").val().split("(")[0]:"",
        "validor1" : $("#validor1ListSelect2").val()?.length > 4 ? $("#validor1ListSelect2").val().split("(")[1].replace(")", ""):"",
        "validor1Fullname" : $("#validor1ListSelect2").val()?.length > 4 ? $("#validor1ListSelect2").val().split("(")[0]:"",
        "validor2" : $("#validor2ListSelect2").val()?.length > 4 ? $("#validor2ListSelect2").val().split("(")[1].replace(")", ""):"",
        "validor2Fullname" : $("#validor2ListSelect2").val()?.length > 4 ? $("#validor2ListSelect2").val().split("(")[0]:"",
        "applicatifIts" : applicatifsIT,
        "reportings" : reportings,
        "operations" : operations,
        "contributors" : contributors
    };

    let url = AJS.contextPath() + "/rest/benchmark-data/1.0/controls/horspci/save";
    fetch(url, {method: "POST", headers: [
            ["Content-Type", "application/json"]
        ],
        credentials: "include",
        body: JSON.stringify(data)
    }).then(function(response){
        if(response.status < 300){
            putDataInForm(controlKey);
            AJS.messages.info("#display-messages", {
                title: "Mise à jour effectuée avec succés",
                body: "<p>Les informations <b>hors PCI</b> ont bien été mises à jour.</p>"
            });
        }else{
            AJS.messages.error("#display-messages", {
                title: "Echec de l'opération",
                body: "<p>Une erreur est survenue lors de l'exécution de l'opération.</p>"
            });
        }
    }).catch(function(error){
    });
});

AJS.$(document).on('click', '#resetControlInfoButton', function() {
    let keyControl = $("input#controlKEY").val();
    putDataInForm(keyControl);
});