package com.tc.labt.sgabs.benchmarkdata.utils;

import javax.ws.rs.FormParam;
import java.io.Serializable;

public class FileUpload implements Serializable {

    private byte[] data;

    public byte[] getData() {
        return data;
    }

    @FormParam("controlImportFile")
    public void setData(byte[] data) {
        this.data = data;
    }
}
