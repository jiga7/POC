package com.tc.labt.sgabs.benchmarkdata.configuration.service;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.plugin.spring.scanner.annotation.component.Scanned;
import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import com.tc.labt.sgabs.benchmarkdata.ao.*;
import com.tc.labt.sgabs.benchmarkdata.configuration.BusinessActiveObjects;
import com.tc.labt.sgabs.benchmarkdata.configuration.crypto.Encryption;
import com.tc.labt.sgabs.benchmarkdata.configuration.database.DatabaseType;
import com.tc.labt.sgabs.benchmarkdata.configuration.database.DatasourceType;
import com.tc.labt.sgabs.benchmarkdata.configuration.database.dto.DatabaseDTO;
import com.tc.labt.sgabs.benchmarkdata.configuration.database.dto.DatasourceDTO;
import com.tc.labt.sgabs.benchmarkdata.configuration.database.dto.PropertyDTO;
import com.tc.labt.sgabs.benchmarkdata.configuration.database.repo.DatabaseManagerRepo;
import com.tc.labt.sgabs.benchmarkdata.configuration.sql.AbstractDefinition;
import com.tc.labt.sgabs.benchmarkdata.configuration.sql.SqlDefinitionProvider;
import com.tc.labt.sgabs.benchmarkdata.utils.MessageError;
import net.java.ao.EntityManager;
import net.java.ao.builder.*;
import org.hibernate.Session;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;
import org.hibernate.cfg.Environment;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.inject.Named;
import java.sql.DriverManager;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

@Component
@Named
@Scanned
public class DatasourceConfigurationService implements IConfigurationService{

    private static final Logger log = LoggerFactory.getLogger(DatasourceConfigurationService.class);

    private final DatabaseManagerRepo databaseManager;
    private final Map<String, BusinessActiveObjects> cache;

    private EntityManager entityManager;

    @Autowired
    public DatasourceConfigurationService(DatabaseManagerRepo databaseManagerRepo){
        this.databaseManager = databaseManagerRepo;
        this.cache = new HashMap<>();
    }

    @Override
    public ActiveObjects getActiveObjects(String subsidiary){
        BusinessActiveObjects activeObjects = this.cache.get(subsidiary);
        if(activeObjects != null)
            return activeObjects;
        try {
            EntityManager entityManager = buildEntityManager(subsidiary);
            activeObjects = (BusinessActiveObjects) BusinessActiveObjects.build(entityManager);
            log.error("Why i'm null");
        } catch (Exception e) {
            log.error("TEST1459 " + e.getMessage());
            e.printStackTrace();
        }
        this.cache.put(subsidiary, activeObjects);
        return activeObjects;
    }

    @Override
    public EntityManager buildEntityManager(final String subsidiary) throws Exception{

        DatabaseDTO database = this.databaseManager.getByDatasourceName(subsidiary);
        if(database == null) throw MessageError.build(MessageError.NOT_EXIST);
        AbstractDefinition sqlDefinition = SqlDefinitionProvider.build(database.getType().getValue());
        try {
            log.error("TEST145 ++ " + Class.forName("org.postgresql.Driver").getName());
        }catch (Exception e){
            log.error("TEST145 " + e.getMessage());
        }
        //DatabaseProviderFactory
        //JdbcDriverDatabaseProviderFactory
        //EntityManager em;
        //em.getSchemaConfiguration() em.getFieldNameConverter() em.getNameConverters() em.getTableNameConverter()
        // new EntityManagerFactoryImpl(new PostgreSQLDatabaseProvider(new C3poDataSourceFactory().getDataSource(Driver.class, sqlDefinition.buildUrlFromConfiguration(database), database.getLogin(), Encryption.decrypt(database.getSecretKey(), database.getPasswordEncrypted())), database.getSchema()));

        DriverManager.registerDriver((java.sql.Driver) Class.forName("org.postgresql.Driver").newInstance());
        log.error("Test " + DriverManager.getConnection(sqlDefinition.buildUrlFromConfiguration(database), database.getLogin(), Encryption.decrypt(database.getSecretKey(), database.getPasswordEncrypted())).getSchema());

        return EntityManagerBuilder
                .url(sqlDefinition.buildUrlFromConfiguration(database))
                .username(database.getLogin())
                .password(Encryption.decrypt(database.getSecretKey(), database.getPasswordEncrypted()))
                .schema(sqlDefinition.hasSchemaSupport()? database.getSchema() : null)
                .auto()
                .build();

        /*return EntityManagerBuilder
                .url("jdbc:postgresql://localhost:5433/postgres")
                .username("postgres")
                .password("123")
                .schema("public")
                .auto()
                .build();*/
    }

    public Session getSession(){
        AnnotationConfiguration cfg = new AnnotationConfiguration();
        cfg.addAnnotatedClass(com.tc.labt.sgabs.benchmarkdata.entity.MethodControlAO.class);
        cfg.getProperties().setProperty(Environment.URL, "jdbc:postgresql://localhost:5433/postgres");
        cfg.getProperties().setProperty(Environment.USER, "postgres");
        cfg.getProperties().setProperty(Environment.PASS, "123");
        cfg.getProperties().setProperty(Environment.DEFAULT_SCHEMA, "public");
        cfg.getProperties().setProperty(Environment.DRIVER, "org.postgresql.Driver");
        cfg.getProperties().setProperty(Environment.AUTO_CLOSE_SESSION, "true");
        cfg.getProperties().setProperty(Environment.SHOW_SQL, "true");
        cfg.getProperties().setProperty(Environment.DIALECT, "org.hibernate.dialect.PostgreSQLDialect");
        return cfg.buildSessionFactory().openSession();
    }

    public DatabaseDTO saveOrUpdate(final DatabaseDTO databaseDTO) throws Exception {
        DatabaseDTO databaseStored = this.databaseManager.getByDatasourceName(databaseDTO.getDatasourceDTO().getName());
        if(Objects.nonNull(databaseStored)){
            databaseDTO.setType(databaseStored.getType());
            databaseDTO.setId(databaseStored.getId());
        }
        return databaseManager.update(databaseDTO);
    }

    @Override
    public boolean initDatabase(final String subsidiary) throws Exception {
        ActiveObjects activeObjects = this.getActiveObjects(subsidiary);
        if(activeObjects == null)
            throw MessageError.build(MessageError.NULL_OBJECT);
        try {
            activeObjects.migrate(MethodControlAO.class, OperationAO.class, ReportingAO.class, ContributorAO.class,
                    FileLoadedAuditAO.class, LogAuditAO.class, ApplicatifITAO.class, CheckAccountAO.class,
                    ApplicatifITCAFKAO.class, ContributorCAFKAO.class, OperationCAFKAO.class, ReportingCAFKAO.class);
        }catch (Exception e){

        }
        return true;
    }

    public List<PropertyDTO> getDatabaseProperties(String subsidiary, DatabaseDTO paramDTO){
        List<PropertyDTO> properties = Lists.newArrayList();
        DatabaseDTO databaseDTO = paramDTO == null ? databaseManager.getByDatasourceName(subsidiary) : paramDTO;
        properties.add(PropertyDTO.build("NAME", databaseDTO==null? "" : Strings.nullToEmpty(databaseDTO.getName())));
        properties.add(PropertyDTO.build("TYPE", databaseDTO==null || databaseDTO.getType()==null? null : Strings.nullToEmpty(databaseDTO.getType().getValue())));
        properties.add(PropertyDTO.build("HOST", databaseDTO==null? "" : Strings.nullToEmpty(databaseDTO.getHost())));
        properties.add(PropertyDTO.build("LOGIN", databaseDTO==null? "" : Strings.nullToEmpty(databaseDTO.getLogin())));
        properties.add(PropertyDTO.build("PASSWORD", ""));
        properties.add(PropertyDTO.build("PORT", databaseDTO==null? "" :  Strings.nullToEmpty(databaseDTO.getPort())));
        properties.add(PropertyDTO.build("SCHEMA", databaseDTO==null? "" :  Strings.nullToEmpty(databaseDTO.getSchema())));
        properties.add(PropertyDTO.build("SERVICE", databaseDTO==null? "" :  Strings.nullToEmpty(databaseDTO.getService())));
        return properties;
    }

    public DatabaseDTO retrieveDataInRequest(Map<String, String[]> parameters){
        DatabaseDTO databaseDTO = new DatabaseDTO();
        databaseDTO.setName(getValueOfProperty(parameters.getOrDefault("NAME", null)));
        databaseDTO.setHost(getValueOfProperty(parameters.getOrDefault("HOST", null)));
        databaseDTO.setPort(getValueOfProperty(parameters.getOrDefault("PORT", null)));
        databaseDTO.setLogin(getValueOfProperty(parameters.getOrDefault("LOGIN", null)));
        databaseDTO.setPassword(getValueOfProperty(parameters.getOrDefault("PASSWORD", null)));
        databaseDTO.setSchema(getValueOfProperty(parameters.getOrDefault("SCHEMA", null)));
        databaseDTO.setService(getValueOfProperty(parameters.getOrDefault("SERVICE", null)));
        String databaseType = getValueOfProperty(parameters.getOrDefault("TYPE", null));
        log.info("Database Type " +  databaseType);
        databaseDTO.setType(Objects.nonNull(databaseType)? DatabaseType.valueOf(databaseType.toUpperCase()) : null);
        databaseDTO.setDatasourceDTO(new DatasourceDTO(null, DatasourceType.DATABASE, getValueOfProperty(parameters.getOrDefault("SUBSIDIARY", null))));
        return databaseDTO;
    }

    private String getValueOfProperty(String[] values){
        return values==null || values.length==0 ? null : values[0];
    }
}
