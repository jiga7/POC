package com.tc.labt.sgabs.benchmarkdata.api;

import javax.inject.Inject;

import com.atlassian.plugin.spring.scanner.annotation.component.Scanned;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.atlassian.activeobjects.external.ActiveObjects;
import com.tc.labt.sgabs.benchmarkdata.ao.ReportingAO;
import com.tc.labt.sgabs.benchmarkdata.dto.Reporting;
import com.tc.labt.sgabs.benchmarkdata.business.ReportingRepo;
import com.tc.labt.sgabs.benchmarkdata.utils.MessageResponse;

import javax.servlet.http.HttpServletRequest;

import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.PathParam;
import javax.ws.rs.Path;
import javax.ws.rs.POST;
import javax.ws.rs.GET;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.MediaType;

import java.io.IOException;
import java.util.List;

@Path("/reporting")
@Scanned
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class ReportingRestAPI {

    @ComponentImport
    private final ActiveObjects activeObjects;

    private final ReportingRepo reportingRepo;

    @Inject
    public ReportingRestAPI(ActiveObjects activeObjects){
        super();
        this.activeObjects = activeObjects;
        reportingRepo = new ReportingRepo(this.activeObjects);
    }

    @POST
    @Path("/add")
    public Response addReporting(final Reporting reporting) throws IOException {

        if(reporting == null || reporting.getCode().isEmpty() || reporting.getSubsidiary() == null ||  reporting.getSubsidiary().isEmpty())
            return Response.status(422).entity(MessageResponse._422).build();

        ReportingAO reportingAO = reportingRepo.save(reporting);
        return reportingAO.getID() == 0 ? Response.status(500).entity(MessageResponse._500).build() : Response.ok(Reporting.retrievesAOToModel(reportingAO)).build();
    }

    @GET
    @Path("/views/{subsidiary}/all")
    public Response getAllReportings(final @PathParam("subsidiary") String subsidiary, @Context HttpServletRequest request) throws IOException{
        List<Reporting> reportings = Reporting.retrievesAOsToModels(reportingRepo.retrievesBySubsidiary(subsidiary));
        return reportings == null || reportings.size() == 0 ? Response.status(204).entity(MessageResponse._204).build() : Response.ok(reportings).build();
    }

    @GET
    @Path("/lists/{subsidiary}")
    public Response getReportingsList(final @PathParam("subsidiary") String subsidiary, @Context HttpServletRequest request) throws IOException{
        return  Response.ok(Reporting.retrievesListOption(reportingRepo.retrievesEnabledBySubsidiary(subsidiary))).build();
    }
}
