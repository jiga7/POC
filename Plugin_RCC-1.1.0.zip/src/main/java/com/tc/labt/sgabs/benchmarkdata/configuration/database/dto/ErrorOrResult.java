package com.tc.labt.sgabs.benchmarkdata.configuration.database.dto;

public class ErrorOrResult <T> {

    public final T result;

    public final Exception exception;

    public ErrorOrResult(T result){
        this.result = result;
        this.exception = null;
    }

    public ErrorOrResult(Exception e){
        this.exception = e;
        this.result = null;
    }

    public static <T> ErrorOrResult<T> ok(T result){
        return new ErrorOrResult<>(result);
    }

    public static <T> ErrorOrResult<T> error(Exception e){
        return new ErrorOrResult<>(e);
    }
}
