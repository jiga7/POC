package com.tc.labt.sgabs.benchmarkdata.utils;

import com.tc.labt.sgabs.benchmarkdata.dto.CheckAccount;
import com.tc.labt.sgabs.benchmarkdata.service.ManageDataPCI;

import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class ManageFile {

    public static String CONSTANT_EXPORT = "_JIRA";
    public static String CONSTANT_IMPORT = "_BI";
    public static String EXTENSION_XLSX = ".xlsx";

    public static String DIRECTORY_SP = "S:\\Workspace_Luna\\benchmark-data\\import";
    public static String SEPARATOR_PATH = "\\";
    //public static String DIRECTORY_SP = "/var/atlassian/application-data/TEST_jira_TEST/data/";
    //public static String SEPARATOR_PATH = "/";

    public static List<CheckAccount> getDataPCIFromFile(File file, boolean header) throws IOException {

        if(file == null || !file.exists() || !file.canRead())
            return null;

        BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
        List<CheckAccount> checkAccounts = new ArrayList<>();
        String subsidiary = getSubsidiaryFromFilename(file.getName());
        String line = "";
        if(header)
            bufferedReader.readLine();
        while((line = bufferedReader.readLine()) != null){
            String[] data = line.split(";");
            checkAccounts.add(new CheckAccount(data[0], data[1], data[2], data[3], data[4], data[5], data[5], data[6], data[7], data[8], data[9], subsidiary));
        }
        return checkAccounts;
    }

    public static List<File> retrieveFileIfExist(String typeFile) {

        File allFilesInFolderSP = new File(DIRECTORY_SP);

        return allFilesInFolderSP.exists() && allFilesInFolderSP.isDirectory() && allFilesInFolderSP.canRead()
                ? Arrays.asList(allFilesInFolderSP.listFiles()).stream().parallel()
                .filter(it -> (it.getName().contains(typeFile+CONSTANT_IMPORT) && it.getName().toLowerCase().endsWith(EXTENSION_XLSX))).collect(Collectors.toList())
                : null;
    }

    public static String getNameFileToExportByType(String subsidiary, String fileType) {

        String fileName = DIRECTORY_SP.concat(SEPARATOR_PATH+ subsidiary);
        if(fileType.toUpperCase().equals(fileType))
            fileName = fileName.concat("_"+fileType+CONSTANT_EXPORT);
        return fileName.concat(EXTENSION_XLSX);
    }

    public static String getSubsidiaryFromFilename(String filename){

        String entityBI = filename.substring(0, 3).toString();
        if(entityBI.equals("SEN"))
            return "SGBS";
        return null;
    }
}
