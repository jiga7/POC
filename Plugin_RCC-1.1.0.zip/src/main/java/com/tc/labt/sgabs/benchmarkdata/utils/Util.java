package com.tc.labt.sgabs.benchmarkdata.utils;

import java.util.function.BiConsumer;

public class Util {

    public static <T> void forEachWithIndex(Iterable<T> source, BiConsumer<Integer, T> consumer) {
        int i=0;
        for(T item : source) {
            if(item!=null)
                consumer.accept(i++, item);
        }
    }
}
