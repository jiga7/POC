package com.tc.labt.sgabs.benchmarkdata.ao;

import net.java.ao.Entity;
import net.java.ao.OneToMany;

import java.util.Date;

public interface ApplicatifITCAFKAO extends Entity {

    public ApplicatifITAO getApplicatifITAO();
    public void setApplicatifITAO(ApplicatifITAO applicatifITAO);

    public CheckAccountAO getCheckAccountAO();
    public void setCheckAccountAO(CheckAccountAO checkAccountAO);

    public Date getAddedAt();
    public void setAddedAt(Date addedAt);

    @OneToMany(reverse="getApplicatifITCAFKAO")
    public LogAuditAO[] getLogAudits();
}
