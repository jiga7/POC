package com.tc.labt.sgabs.benchmarkdata.business;

import com.tc.labt.sgabs.benchmarkdata.ao.LogAuditAO;
import com.tc.labt.sgabs.benchmarkdata.dto.LogAudit;

import com.atlassian.activeobjects.tx.Transactional;

import java.util.List;

@Transactional
public interface ILogAuditRepo {

    LogAuditAO save(LogAudit logAudit);

    List<LogAuditAO> retrievesAll();

    List<LogAuditAO> retrievesAll(int page, int size);

    List<LogAuditAO> retrievesBySubsidiary(String subsidiary);

    List<LogAuditAO> retrievesBySubsidiary(String subsidiary, int page, int size);

    List<LogAuditAO> retrievesByAuthor(String author);

    List<LogAuditAO> retrievesByAuthor(String author, int page, int size);

}
