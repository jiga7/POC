package com.tc.labt.sgabs.benchmarkdata.business;

import com.tc.labt.sgabs.benchmarkdata.ao.OperationAO;
import com.tc.labt.sgabs.benchmarkdata.dto.Operation;

import com.atlassian.activeobjects.tx.Transactional;

import java.util.List;

@Transactional
public interface IOperationRepo {

    OperationAO save(Operation operation);

    List<OperationAO> saveOrRetrievesAll(List<Operation> operations);

    OperationAO retrievesByCode(String code);

    List<OperationAO> retrievesAll();

    List<OperationAO> retrievesEnabled();

    List<OperationAO> retrievesBySubsidiary(String subsidiary);

    List<OperationAO> retrievesEnabledBySubsidiary(String subsidiary);

    List<OperationAO> retrievesAllByIds(List<Integer> ids);
}
