package com.tc.labt.sgabs.benchmarkdata.configuration.service;

import com.atlassian.activeobjects.external.ActiveObjects;
import net.java.ao.EntityManager;
import org.hibernate.Session;

public interface IConfigurationService {

    ActiveObjects getActiveObjects(String subsidiary);

    EntityManager buildEntityManager(final String subsidiary) throws Exception;

    boolean initDatabase(final String subsidiary) throws Exception;

    Session getSession();
}
