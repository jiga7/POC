package com.tc.labt.sgabs.benchmarkdata.business;

import com.tc.labt.sgabs.benchmarkdata.ao.CheckAccountAO;
import com.tc.labt.sgabs.benchmarkdata.ao.ReportingAO;
import com.tc.labt.sgabs.benchmarkdata.ao.ReportingCAFKAO;

import javax.inject.Inject;
import javax.inject.Named;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.plugin.spring.scanner.annotation.component.Scanned;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@Named
@Scanned
public class ReportingCAFKRepo implements IReportingCAFKRepo{

    @ComponentImport
    private ActiveObjects activeObjects;

    private final ReportingRepo reportingRepo;

    @Inject
    public ReportingCAFKRepo(ActiveObjects activeObjects) {
        super();
        this.activeObjects = activeObjects;
        this.reportingRepo = new ReportingRepo(activeObjects);
    }

    @Override
    public ReportingCAFKAO save(ReportingAO reportingAO, CheckAccountAO checkAccountAO) {

        if(reportingAO.getID() == 0 || checkAccountAO.getKey().isEmpty())
            return null;

        ReportingCAFKAO[] reportingCAFKAOs = activeObjects.find(ReportingCAFKAO.class, "REPORTING_ID = ? AND CHECK_ACCOUNT_ID = ?", reportingAO.getID(), checkAccountAO.getKey());
        if(reportingCAFKAOs.length == 0){
            ReportingCAFKAO reportingCAFKAO = activeObjects.create(ReportingCAFKAO.class);
            reportingCAFKAO.setReporting(reportingAO);
            reportingCAFKAO.setCheckAccount(checkAccountAO);
            reportingCAFKAO.setAddedAt(new Date());
            reportingCAFKAO.save();
            return reportingCAFKAO;
        }else
            return reportingCAFKAOs[0];
    }

    @Override
    public List<ReportingCAFKAO> save(List<ReportingAO> reportingAOs, CheckAccountAO checkAccountAO) {

        if(reportingAOs.size() <= 0)
            return null;

        List<ReportingCAFKAO> reportingCAFKAOs = new ArrayList<>();
        reportingAOs.parallelStream().forEach(reportingAO -> reportingCAFKAOs.add(save(reportingAO, checkAccountAO)));
        return reportingCAFKAOs;
    }

    @Override
    public List<ReportingCAFKAO> saveAll(List<Integer> reporting_IDs, CheckAccountAO checkAccountAO) {
        List<ReportingCAFKAO> reportingCAFKAOs = retrievesByCheckAccountID(checkAccountAO.getKey())
                .stream().parallel()
                .filter(reportingCAFKAO -> !reporting_IDs.contains(reportingCAFKAO.getReporting().getID()))
                .collect(Collectors.toList());

        deleteAll(reportingCAFKAOs);
        return reporting_IDs.size()<=0 ? null : this.save(reportingRepo.retrievesAllByIds(reporting_IDs), checkAccountAO);
    }

    @Override
    public List<ReportingCAFKAO> retrievesByCheckAccountID(String checkControlID) {
        if(checkControlID.isEmpty())
            return null;
        return Arrays.asList(activeObjects.find(ReportingCAFKAO.class, "CHECK_ACCOUNT_ID = ?", checkControlID));
    }

    @Override
    public List<ReportingCAFKAO> deleteAll(List<ReportingCAFKAO> reportingCAFKAOs) {
        reportingCAFKAOs.parallelStream().forEach(reportingCAFKAO -> activeObjects.delete(reportingCAFKAO));
        return reportingCAFKAOs;
    }
}
