package com.tc.labt.sgabs.benchmarkdata.configuration.sql;

import com.tc.labt.sgabs.benchmarkdata.configuration.database.DatabaseType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SqlDefinitionProvider {

    private static final Logger log = LoggerFactory.getLogger(SqlDefinitionProvider.class);

    public static AbstractDefinition build(String databaseType){
        if(DatabaseType.POSTGRESQL.getValue().equalsIgnoreCase(databaseType)) {
            log.info("Driver got POSTGRESQL");
            return new PostgresqlDefinition();
        }if(DatabaseType.MYSQL.getValue().equalsIgnoreCase(databaseType))
            return new MysqlDefinition();
        if(DatabaseType.SQLSERVER.getValue().equalsIgnoreCase(databaseType))
            return new SqlServerDefinition();
        if (DatabaseType.ORACLE.getValue().equalsIgnoreCase(databaseType))
            return new OracleDefinition();
        return null;
    }

    public static AbstractDefinition build(DatabaseType databaseType){
        return build(databaseType.getValue());
    }
}
