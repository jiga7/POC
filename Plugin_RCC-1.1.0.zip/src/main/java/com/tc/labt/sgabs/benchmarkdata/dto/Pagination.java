package com.tc.labt.sgabs.benchmarkdata.dto;

import java.io.Serializable;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlElement;

public class Pagination <T> implements Serializable {

    private int count;
    private int page;

    @XmlElement
    private List<T> values;

    public Pagination() {
        super();
    }

    public Pagination(int page, List<T> values) {
        this.count = values.size();
        this.page = page;
        this.values = values;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    public List<T> getValues() {
        return values;
    }

    public void setValues(List<T> values) {
        this.values = values;
    }
}
