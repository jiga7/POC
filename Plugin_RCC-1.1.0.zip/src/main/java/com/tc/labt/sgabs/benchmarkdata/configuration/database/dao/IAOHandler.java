package com.tc.labt.sgabs.benchmarkdata.configuration.database.dao;

public interface IAOHandler<E, M> {

    public E createAOEntity(M m) throws Exception;

    public E updateAOEntity(M m) throws Exception;

    public boolean deleteAOEntity(E e) throws Exception;
}
