package com.tc.labt.sgabs.benchmarkdata.api;

import javax.inject.Inject;
import javax.inject.Named;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.plugin.spring.scanner.annotation.component.Scanned;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.atlassian.jira.security.groups.GroupManager;
import com.atlassian.jira.component.ComponentAccessor;
import com.tc.labt.sgabs.benchmarkdata.dto.Option;

import javax.servlet.http.HttpServletRequest;

import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.PathParam;
import javax.ws.rs.Path;
import javax.ws.rs.GET;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.MediaType;
import java.util.List;
import java.util.stream.Collectors;

@Path("/jira")
@Scanned
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class JiraComponentRestAPI {

    public final static String prefixProject = "SG";

    @ComponentImport
    private final ActiveObjects activeObjects;

    @Inject
    public JiraComponentRestAPI(ActiveObjects activeObjects){
        super();
        this.activeObjects = activeObjects;
    }

   /* @GET
    @Path("/users/{jiraGroup}")
    public Response getAllUsers(final @PathParam("jiraGroup") String jiraGroup, @Context HttpServletRequest request){
        GroupManager groupManager = ComponentAccessor.getGroupManager();
        List<Option> options = groupManager.getUsersInGroup(jiraGroup).stream().parallel()
                .filter(user -> user.isActive())
                .map(user -> new Option(user.getDisplayName(), user.getEmailAddress ()))
                .collect(Collectors.toList());
        return Response.ok(options).build();
    }

    @GET
    @Path("/projects")
    public Response getAllProjectWithPrefixSG(@Context HttpServletRequest request){
        ProjectManager projectManager = ComponentAccessor.getProjectManager();
        List<Option> options = projectManager.getProjectObjects()
                .stream().parallel()
                .filter(project -> project.getName().startsWith(prefixProject))
                .map(project -> new Option(project.getName(), project.getOriginalKey()))
                .collect(Collectors.toList());
        return Response.ok(options).build();
    }*/
}
