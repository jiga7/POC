package com.tc.labt.sgabs.benchmarkdata.business;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.plugin.spring.scanner.annotation.component.Scanned;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;

import com.tc.labt.sgabs.benchmarkdata.ao.CheckAccountAO;
import com.tc.labt.sgabs.benchmarkdata.ao.OperationAO;
import com.tc.labt.sgabs.benchmarkdata.ao.OperationCAFKAO;

import javax.inject.Inject;
import javax.inject.Named;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@Scanned
@Named
public class OperationCAFKRepo implements IOperationCAFKRepo{

    @ComponentImport
    private ActiveObjects activeObjects;

    private final OperationRepo operationRepo;

    @Inject
    public OperationCAFKRepo(ActiveObjects activeObjects){
        super();
        this.activeObjects = activeObjects;
        this.operationRepo = new OperationRepo(activeObjects);
    }

    @Override
    public OperationCAFKAO save(OperationAO operationAO, CheckAccountAO checkAccountAO) {
        if(operationAO.getID() == 0 || checkAccountAO.getKey().isEmpty())
            return null;

        OperationCAFKAO[] operationCAFKAOs = activeObjects.find(OperationCAFKAO.class, "OPERATION_ID = ? AND CHECK_ACCOUNT_ID = ?", operationAO.getID(), checkAccountAO.getKey());
        if(operationCAFKAOs.length == 0){
            OperationCAFKAO operationCAFKAO = activeObjects.create(OperationCAFKAO.class);
            operationCAFKAO.setOperation(operationAO);
            operationCAFKAO.setCheckAccount(checkAccountAO);
            operationCAFKAO.setAddedAt(new Date());
            operationCAFKAO.save();
            return operationCAFKAO;
        }else
            return null;
    }

    @Override
    public List<OperationCAFKAO> save(List<OperationAO> operationAOs, CheckAccountAO checkAccountAO) {

        if(operationAOs.size() <= 0)
            return null;

        List<OperationCAFKAO> operationCAFKAOs = new ArrayList<>();
        operationAOs.parallelStream().forEach(operationAO -> operationCAFKAOs.add(save(operationAO, checkAccountAO)));
        return operationCAFKAOs;
    }

    @Override
    public List<OperationCAFKAO> saveAll(List<Integer> operation_IDs, CheckAccountAO checkAccountAO) {
        List<OperationCAFKAO> operationCAFKAOs = retrieveByCheckAccountID(checkAccountAO.getKey())
                .stream().parallel()
                .filter(operationCAFKAO -> !operation_IDs.contains(operationCAFKAO.getOperation().getID()))
                .collect(Collectors.toList());
        deleteAll(operationCAFKAOs);
        return operation_IDs.size() <= 0 ? null : this.save(operationRepo.retrievesAllByIds(operation_IDs), checkAccountAO);
    }

    @Override
    public List<OperationCAFKAO> retrieveByCheckAccountID(String checkAccountID) {
        if(checkAccountID.isEmpty())
            return null;
        return Arrays.asList(activeObjects.find(OperationCAFKAO.class, "CHECK_ACCOUNT_ID = ?", checkAccountID));
    }

    @Override
    public List<OperationCAFKAO> deleteAll(List<OperationCAFKAO> operationCAFKAOs) {
        operationCAFKAOs.parallelStream().forEach(operationCAFKAO -> activeObjects.delete(operationCAFKAO));
        return operationCAFKAOs;
    }
}
