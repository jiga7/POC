package com.tc.labt.sgabs.benchmarkdata.business;


import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.plugin.spring.scanner.annotation.component.Scanned;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.tc.labt.sgabs.benchmarkdata.ao.ApplicatifITAO;
import com.tc.labt.sgabs.benchmarkdata.ao.ApplicatifITCAFKAO;
import com.tc.labt.sgabs.benchmarkdata.ao.CheckAccountAO;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.*;
import java.util.stream.Collectors;

@Scanned
@Named
public class ApplicatifCAFKRepo implements IApplicatifCAFKRepo{

    @ComponentImport
    private ActiveObjects activeObjects;

    private final ApplicatifITRepo applicatifITRepo;

    @Inject
    public ApplicatifCAFKRepo(ActiveObjects activeObjects){

        super(); //this();
        this.activeObjects = activeObjects;
        this.applicatifITRepo = new ApplicatifITRepo(activeObjects);
    }

    @Override
    public ApplicatifITCAFKAO save(ApplicatifITAO applicatifITAO, CheckAccountAO checkAccountAO) {

        if(applicatifITAO.getID() == 0 || checkAccountAO.getKey().isEmpty())
            return null;

        ApplicatifITCAFKAO[] applicatifITCAFKAOs = activeObjects.find(ApplicatifITCAFKAO.class, "APPLICATIF_ITAOID = ? AND CHECK_ACCOUNT_AOID = ?", applicatifITAO.getID(), checkAccountAO.getKey());
        if(applicatifITCAFKAOs.length == 0){
            ApplicatifITCAFKAO applicatifITCAFKAO = activeObjects.create(ApplicatifITCAFKAO.class);
            applicatifITCAFKAO.setApplicatifITAO(applicatifITAO);
            applicatifITCAFKAO.setCheckAccountAO(checkAccountAO);
            applicatifITCAFKAO.setAddedAt(new Date());
            applicatifITCAFKAO.save();
            return applicatifITCAFKAO;
        }else{
            return applicatifITCAFKAOs[0];
        }
    }

    @Override
    public List<ApplicatifITCAFKAO> save(List<ApplicatifITAO> applicatifITAOs, CheckAccountAO checkAccountAO) {

        if(applicatifITAOs.size() <= 0)
            return null;

        List<ApplicatifITCAFKAO> applicatifITCAFKAOs = new ArrayList<>();
        applicatifITAOs.parallelStream().forEach(applicatifITAO -> applicatifITCAFKAOs.add(save(applicatifITAO, checkAccountAO)));
        return applicatifITCAFKAOs;
    }

    @Override
    public List<ApplicatifITCAFKAO> saveAll(List<Integer> applicatifIT_IDs, final CheckAccountAO checkAccountAO) {

        List<ApplicatifITCAFKAO> applicatifITCAFKAOs = retrieveByCheckAccountID(checkAccountAO.getKey())
                .stream().parallel()
                .filter(applicatifITCAFKAO -> !applicatifIT_IDs.contains(applicatifITCAFKAO.getApplicatifITAO().getID()))
                .collect(Collectors.toList());

        deleteAll(applicatifITCAFKAOs);
        return applicatifIT_IDs.size()<=0 ? null : this.save(applicatifITRepo.retrievesAllByIds(applicatifIT_IDs), checkAccountAO);
    }

    @Override
    public List<ApplicatifITCAFKAO> retrieveByCheckAccountID(String checkAccountID) {
        if(checkAccountID.isEmpty())
            return null;
        return Arrays.asList(activeObjects.find(ApplicatifITCAFKAO.class, "CHECK_ACCOUNT_AOID = ?", checkAccountID));
    }

    @Override
    public List<ApplicatifITCAFKAO> deleteAll(List<ApplicatifITCAFKAO> applicatifITCAFKAOs) {
        applicatifITCAFKAOs.parallelStream().forEach( applicatifITCAFKAO -> activeObjects.delete(applicatifITCAFKAO));
        return applicatifITCAFKAOs;
    }
}
