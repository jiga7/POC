package com.tc.labt.sgabs.benchmarkdata.dto;

import com.tc.labt.sgabs.benchmarkdata.ao.OperationAO;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlElement;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class Operation implements Serializable {

	private int id;
	@XmlElement
	private String ope;
	@XmlElement
	private String lib;
	@XmlElement
	private String subsidiary;
	private boolean active;

	private CheckAccount[] checkAccounts;

	public Operation() {
	}

	public Operation(String ope, String lib, String subsidiary) {
		this.ope = ope;
		this.lib = lib;
		this.subsidiary = subsidiary;
	}

	public Operation(int id, String ope, String lib, String subsidiary, boolean active) {
		this(ope, lib, subsidiary);
		this.id = id;
		this.active = active;
	}

	public int getId() { return id; }

	public void setId(int id) { this.id = id; }

	public String getOpe() {
		return ope;
	}

	public void setOpe(String ope) {
		this.ope = ope;
	}

	public String getLib() {
		return lib;
	}

	public void setLib(String lib) {
		this.lib = lib;
	}

	public String getSubsidiary() {
		return subsidiary;
	}

	public void setSubsidiary(String subsidiary) {
		this.subsidiary = subsidiary;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public static Operation retrievesAOToModel(OperationAO operationAO){
		return operationAO.getID() == 0 ? null : new Operation(operationAO.getID(), operationAO.getOpe(), operationAO.getLib(), operationAO.getSubsidiary(), operationAO.isActive());
	}


	public static List<Operation> retrievesAOsToModels(OperationAO[] operationAOs) {
		return retrievesAOsToModels(Arrays.asList(operationAOs));
	}

	public static List<Operation> retrievesAOsToModels(List<OperationAO> operationAOs) {
		List<Operation> operations = new ArrayList<>(operationAOs.size());
		operationAOs.forEach(operationAO -> operations.add(retrievesAOToModel(operationAO)));
		return operations;
	}

	public static List<Option> retrievesListOption(final List<OperationAO> operationAOs){
		return operationAOs
				.stream().parallel()
				.map(operationAO -> new Option(operationAO.getID(), operationAO.getLib(), operationAO.getOpe()))
				.collect(Collectors.toList());
	}
}