package com.tc.labt.sgabs.benchmarkdata.business;

import com.google.common.collect.Lists;
import com.tc.labt.sgabs.benchmarkdata.ao.MethodControlAO;
import com.tc.labt.sgabs.benchmarkdata.configuration.service.DatasourceConfigurationService;
import com.tc.labt.sgabs.benchmarkdata.configuration.service.IConfigurationService;
import com.tc.labt.sgabs.benchmarkdata.dto.MethodControl;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.plugin.spring.scanner.annotation.component.Scanned;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import javax.inject.Named;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

@Scanned
@Named
@Component
public class MethodControlRepo implements IMethodControlRepo{

    private static final Logger log = LoggerFactory.getLogger(MethodControlRepo.class);

    private IConfigurationService configurationService;
    @Inject
    public MethodControlRepo(DatasourceConfigurationService datasourceConfigurationService){
        super();
        this.configurationService = datasourceConfigurationService;
    }

    @Override
    public MethodControlAO save(final MethodControl methodControl) {

        if(methodControl != null){
            ActiveObjects businessActiveObjects = this.configurationService.getActiveObjects(methodControl.getSubsidiary());
            if(businessActiveObjects.find(MethodControlAO.class, "code = ?", methodControl.getCode()).length==0){
                MethodControlAO methodControlAO = businessActiveObjects.create(MethodControlAO.class);
                methodControlAO.setCode(methodControl.getCode());
                methodControlAO.setMethod(methodControl.getMethod());
                methodControlAO.setSubsidiary(methodControl.getSubsidiary());
                methodControlAO.setCreated(new Date());
                methodControlAO.setActive(Boolean.TRUE);
                methodControlAO.save();
                return methodControlAO;
            }else {
                // logs
            }
        }
        return null;
    }

    public com.tc.labt.sgabs.benchmarkdata.entity.MethodControlAO saveP(final MethodControl methodControl) {

        if(methodControl != null){
            Session session = this.configurationService.getSession();
            Transaction transaction = session.beginTransaction();
            com.tc.labt.sgabs.benchmarkdata.entity.MethodControlAO mm = new com.tc.labt.sgabs.benchmarkdata.entity.MethodControlAO(15L, methodControl.getCode(), methodControl.getMethod(), methodControl.getSubsidiary(), new Date(), true);
            session.save(mm);
            transaction.commit();
            return mm;
        }
        return null;
    }

    @Override
    public MethodControlAO retrievesByCode(String code, String subsidiary) {
        MethodControlAO[] methodControlAOs = this.configurationService.getActiveObjects(subsidiary).find(MethodControlAO.class, "CODE = ?", code);
        return methodControlAOs.length == 1 ? methodControlAOs[0] : null;
    }

    @Override
    public MethodControlAO enableOrDisable(MethodControl methodControl, boolean enable) {
        return null;
    }

    @Override
    public List<MethodControlAO> retrievesBySubsidiary(String subsidiary) {
        log.error(subsidiary +"-"+(this.configurationService == null));
        if(this.configurationService.getActiveObjects(subsidiary) != null)
            return Arrays.asList(this.configurationService.getActiveObjects(subsidiary).find(MethodControlAO.class, "SUBSIDIARY = ?", subsidiary));
        else
            return Lists.newArrayList();
    }

    @Override
    public List<com.tc.labt.sgabs.benchmarkdata.entity.MethodControlAO> retrievesBySubsidiaryP(String subsidiary) {
        return this.configurationService.getSession().createCriteria(com.tc.labt.sgabs.benchmarkdata.entity.MethodControlAO.class).list();
    }

    @Override
    public List<MethodControlAO> retrievesEnabledBySubsidiary(String subsidiary) {
        return Arrays.asList(this.configurationService.getActiveObjects(subsidiary).find(MethodControlAO.class, "SUBSIDIARY = ? AND ACTIVE IS ?", subsidiary, Boolean.TRUE));
    }
}
