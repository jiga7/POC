package com.tc.labt.sgabs.benchmarkdata.dto;

import com.tc.labt.sgabs.benchmarkdata.ao.ReportingAO;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlElement;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class Reporting implements Serializable {

	private int id;
	@XmlElement
	private String code;
	@XmlElement
	private String lib;
	@XmlElement
	private String subsidiary;
	private boolean active;

	private CheckAccount[] checkAccounts;

	public Reporting() {
		super();
	}

	public Reporting(String code, String lib, String subsidiary) {
		this();
		this.code = code;
		this.lib = lib;
		this.subsidiary = subsidiary;
	}

	public Reporting(int id, String code, String lib, String subsidiary, boolean active) {
		this(code, lib, subsidiary);
		this.id = id;
		this.active = active;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getLib() {
		return lib;
	}

	public void setLib(String lib) {
		this.lib = lib;
	}

	public String getSubsidiary() {
		return subsidiary;
	}

	public void setSubsidiary(String subsidiary) {
		this.subsidiary = subsidiary;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public CheckAccount[] getCheckAccounts() {
		return checkAccounts;
	}

	public void setCheckAccounts(CheckAccount[] checkAccounts) {
		this.checkAccounts = checkAccounts;
	}

	public static Reporting retrievesAOToModel(ReportingAO reportingAO){
		return reportingAO==null || reportingAO.getID()==0 ? null : new Reporting(reportingAO.getID(), reportingAO.getCode(), reportingAO.getLib(), reportingAO.getSubsidiary(), reportingAO.isActive());
	}

	public static List<Reporting> retrievesAOsToModels(ReportingAO[] reportingAOs){
		return retrievesAOsToModels(Arrays.asList(reportingAOs));
	}

	public static List<Reporting> retrievesAOsToModels(List<ReportingAO> reportingAOs){
		List<Reporting> reportings = new ArrayList<>();
		reportingAOs.forEach(reportingAO -> reportings.add(retrievesAOToModel(reportingAO)));
		return reportings;
	}

	public static List<Option> retrievesListOption(final List<ReportingAO> reportingAOs){
		return reportingAOs
				.stream().parallel()
				.map(reportingAO -> new Option(reportingAO.getID(), reportingAO.getLib(), reportingAO.getCode()))
				.collect(Collectors.toList());
	}
}