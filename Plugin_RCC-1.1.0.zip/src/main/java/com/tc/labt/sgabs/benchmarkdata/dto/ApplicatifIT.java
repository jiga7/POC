package com.tc.labt.sgabs.benchmarkdata.dto;

import com.tc.labt.sgabs.benchmarkdata.ao.ApplicatifITAO;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlElement;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class ApplicatifIT implements Serializable {

	public static String typCNTL = "CNTL";
	public static String typMVT = "MVT";

	private int id;
	@XmlElement
	private String code;
	@XmlElement
	private String lib;
	@XmlElement
	private String typ;
	@XmlElement
	private String subsidiary;
	private boolean active;

	private CheckAccount[] checkAccounts;

	public ApplicatifIT(){
		super();
	}

	public ApplicatifIT(String code, String lib, String subsidiary){
		this.code = code;
		this.lib = lib;
		this.subsidiary = subsidiary;
	}

	public ApplicatifIT(int id, String code, String lib, String typ, String subsidiary, boolean active){
		this(code, lib, subsidiary);
		this.id = id;
		this.active = active;
		this.typ = typ;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getLib() {
		return lib;
	}

	public void setLib(String lib) {
		this.lib = lib;
	}

	public String getTyp() {
		return typ;
	}

	public void setTyp(String typ) {
		this.typ = typ;
	}

	public String getSubsidiary() {
		return subsidiary;
	}

	public void setSubsidiary(String subsidiary) {
		this.subsidiary = subsidiary;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public static ApplicatifIT retrievesAOToModel(ApplicatifITAO applicatifITAO){
		return applicatifITAO == null || applicatifITAO.getID() == 0 ? null : new ApplicatifIT(applicatifITAO.getID(), applicatifITAO.getCode(), applicatifITAO.getLib(), applicatifITAO.getTyp(), applicatifITAO.getSubsidiary(), applicatifITAO.isActive());
	}

	public static List<ApplicatifIT> retrievesAOsToModels(ApplicatifITAO[] applicatifITAOs){
		return retrievesAOsToModels(Arrays.asList(applicatifITAOs));
	}

	public static List<ApplicatifIT> retrievesAOsToModels(List<ApplicatifITAO> applicatifITAOs){

		return (applicatifITAOs == null || applicatifITAOs.size()==0) ?
			 null:
			 applicatifITAOs
				.stream().parallel()
				.map(ApplicatifIT::retrievesAOToModel)
				.collect(Collectors.toList());
	}

	public static List<Option> retrievesListOption(final List<ApplicatifITAO> applicatifITAOs){
		return applicatifITAOs
				.stream().parallel()
				.map(applicatifITAO -> new Option(applicatifITAO.getID(), applicatifITAO.getLib(), applicatifITAO.getCode()))
				.collect(Collectors.toList());
	}

}
