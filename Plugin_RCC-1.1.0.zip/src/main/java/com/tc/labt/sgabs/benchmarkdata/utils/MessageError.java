package com.tc.labt.sgabs.benchmarkdata.utils;

public class MessageError {

    public static final String NULL_OBJECT = "Cannot create object null";

    public static final String ALREADY_EXIST = "Object already exists";

    public static final String NOT_EXIST = "Object does not exist";

    public static Exception build(String e){
        return new Exception(e);
    }
}
