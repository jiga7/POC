package com.tc.labt.sgabs.benchmarkdata.dto;

import com.tc.labt.sgabs.benchmarkdata.ao.LogAuditAO;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlElement;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class LogAudit implements Serializable {

	@XmlElement
	private String author;
	@XmlElement
	private String description;
	@XmlElement
	private Integer index;
	@XmlElement
	private Date created;

	private CheckAccount checkAccount;
	private FileLoadedAudit fileLoadedAudit;

	public LogAudit() {
		super();
	}

	public LogAudit(String author, String description) {
		this();
		this.author = author;
		this.description = description;
	}

	public LogAudit(String author, String description, Integer index) {
		this(author, description);
		this.index = index;
	}

	public LogAudit(String author, String description, Integer index, Date created, CheckAccount checkAccount, FileLoadedAudit fileLoadedAudit) {
		this(author, description, index);
		this.created = created;
		this.checkAccount = checkAccount;
		this.fileLoadedAudit = fileLoadedAudit;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Integer getIndex() {
		return index;
	}

	public void setIndex(Integer index) {
		this.index = index;
	}

	public Date getCreated() {
		return created;
	}

	public void setCreated(Date created) {
		this.created = created;
	}

	public CheckAccount getCheckAccount() {
		return checkAccount;
	}

	public void setCheckAccount(CheckAccount checkAccount) {
		this.checkAccount = checkAccount;
	}

	public FileLoadedAudit getFileLoadedAudit() {
		return fileLoadedAudit;
	}

	public void setFileLoadedAudit(FileLoadedAudit fileLoadedAudit) {
		this.fileLoadedAudit = fileLoadedAudit;
	}

	public static LogAudit retrievesAOToModel(LogAuditAO logAuditAO) {
		return logAuditAO == null || logAuditAO.getID()==0 ? null : new LogAudit(logAuditAO.getAuthor(), logAuditAO.getDescription(), logAuditAO.getIndex(), logAuditAO.getCreated(), null /* checkAccount */, FileLoadedAudit.retrievesAOToModel(logAuditAO.getFileLoadedAudit()));
	}

	public static List<LogAudit> retrievesAOsToModels(LogAuditAO[] logAuditsAos) {
		return retrievesAOsToModels(Arrays.asList(logAuditsAos));
	}

	public static List<LogAudit> retrievesAOsToModels(List<LogAuditAO> logAuditsAos) {
		List<LogAudit> logAudits = new ArrayList<>();
		logAuditsAos.forEach(logAuditAO -> logAudits.add(retrievesAOToModel(logAuditAO)));
		return logAudits;
	}
}