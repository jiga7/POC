package com.tc.labt.sgabs.benchmarkdata.business;

import com.tc.labt.sgabs.benchmarkdata.ao.ContributorAO;
import com.tc.labt.sgabs.benchmarkdata.dto.Contributor;

import com.atlassian.activeobjects.tx.Transactional;

import java.util.List;

@Transactional
public interface IContributorRepo {

    ContributorAO saveOrRetrieves(Contributor contributor);

    List<ContributorAO> saveOrRetrievesAll(List<Contributor> contributors);

    List<ContributorAO> retrievesAll();

    List<ContributorAO> retrievesAllByCheckControl(Integer checkControlID);

    List<ContributorAO> retrievesAllBySubsidiary(String subsidiary);

    List<ContributorAO> retrievesAllByIds(List<Integer> ids);
}
