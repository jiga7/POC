package com.tc.labt.sgabs.benchmarkdata.api;

import javax.inject.Inject;
import javax.inject.Named;

import com.atlassian.jira.component.ComponentAccessor;
import com.atlassian.plugin.spring.scanner.annotation.component.Scanned;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.plugins.rest.common.security.AnonymousAllowed;
import com.atlassian.sal.api.user.UserManager;
import com.atlassian.seraph.auth.AuthenticationContext;
import com.atlassian.seraph.auth.DefaultAuthenticator;
import com.tc.labt.sgabs.benchmarkdata.service.ManageDataPCI;
import org.apache.commons.httpclient.HttpStatus;
import org.springframework.beans.factory.annotation.Autowired;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.Path;
import javax.ws.rs.GET;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Context;
import java.io.IOException;

@Scanned
@Path("/schedule")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class TestMethodToSchedule {

    private UserManager userManager;

    @Autowired
    public TestMethodToSchedule(@ComponentImport UserManager userManager){
        this.userManager = userManager;
    }

    @Path("/test1")
    @GET
    @AnonymousAllowed
    public Response test1(@Context HttpServletRequest request, @Context HttpServletResponse response) throws ServletException, IOException {
        String test = "REF APP 1";
        request.getSession().setAttribute(DefaultAuthenticator.LOGGED_IN_KEY, userManager.resolve("admin"));
        request.getSession().setAttribute(DefaultAuthenticator.LOGGED_OUT_KEY, null);
        //response.sendRedirect("http://localhost:8090/secure/Dashboard.jspa");
        return Response.ok(test).build();
    }
}
