package com.tc.labt.sgabs.benchmarkdata.configuration.database.ao;

import com.tc.labt.sgabs.benchmarkdata.configuration.database.DatabaseType;
import net.java.ao.schema.Table;

@Table("database")
public interface DatabaseAO extends EntityWithIdAndAuditAO {

    public String getName();
    public void setName(String name);

    public DatabaseType getType();
    public void setType(DatabaseType type);

    public String getHost();
    public void setHost(String host);

    public String getLogin();
    public void setLogin(String login);

    public String getPassword();
    public void setPassword(String password);

    public String getPasswordEncrypted();
    public void setPasswordEncrypted(String passwordEncrypted);

    public String getSecretKey();
    public void setSecretKey(String secretKey);

    public String getPort();
    public void setPort(String port);

    public String getSchema();
    public void setSchema(String schema);

    public String getService();
    public void setService(String service);

    public DatasourceAO getDatasourceAO();
    public void setDatasourceAO(DatasourceAO datasourceAO);
}
