package com.tc.labt.sgabs.benchmarkdata.ao;

import net.java.ao.Entity;
import net.java.ao.OneToMany;

import java.util.Date;

public interface ReportingCAFKAO extends Entity{

    public ReportingAO getReporting();
    public void setReporting(ReportingAO reporting);

    public CheckAccountAO getCheckAccount();
    public void setCheckAccount(CheckAccountAO checkAccount);

    public Date getAddedAt();
    public void setAddedAt(Date addedAt);

    @OneToMany(reverse="getReportingCAFKAO")
    public LogAuditAO[] getLogAudits();
}
