package com.tc.labt.sgabs.benchmarkdata.configuration;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.activeobjects.internal.EntityManagedActiveObjects;
import com.atlassian.activeobjects.internal.TransactionManager;
import com.atlassian.activeobjects.spi.DatabaseType;
import com.atlassian.sal.api.transaction.TransactionCallback;
import com.google.common.collect.ImmutableMap;
import net.java.ao.ActiveObjectsException;
import net.java.ao.EntityManager;
import net.java.ao.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Map;
import java.util.Objects;

public final class BusinessActiveObjects extends EntityManagedActiveObjects {

    private static final Logger log = LoggerFactory.getLogger(BusinessActiveObjects.class);

    private static final Map<String, DatabaseType> DATABASE_PRODUCT_TO_TYPE_MAP = ImmutableMap.<String, DatabaseType>builder()
            .put("H2", DatabaseType.H2)
            .put("HSQL Database Engine", DatabaseType.HSQL)
            .put("MySQL", DatabaseType.MYSQL)
            .put("PostgreSQL", DatabaseType.POSTGRESQL)
            .put("Oracle", DatabaseType.ORACLE)
            .put("Microsoft SQL Server", DatabaseType.MS_SQL)
            .put("DB2", DatabaseType.DB2)
            .build();

    private BusinessActiveObjects(final EntityManager entityManager) {
        super(entityManager, new TransactionManager() {
            @Override
            public <T> T doInTransaction(final TransactionCallback<T> callback) {
                try {
                    return new Transaction<T>(entityManager){
                        public T run() { return callback.doInTransaction(); }
                    }.execute();
                } catch (SQLException e) {
                    throw new ActiveObjectsException(e);
                }
            }
        }, findDatabaseType(entityManager));
    }

    private static DatabaseType findDatabaseType(final EntityManager entityManager){
        Connection connection = null;
        try{
            connection = entityManager.getProvider().getConnection();
            String dbName = connection.getMetaData().getDatabaseProductName();
            for(Map.Entry<String, DatabaseType> entry : DATABASE_PRODUCT_TO_TYPE_MAP.entrySet()){
                if(dbName.toUpperCase().startsWith(entry.getKey().toUpperCase()))
                    return entry.getValue();
            }
        }catch(Exception e){
            throw new ActiveObjectsException(e);
        }finally{
            if(connection != null){
                try{
                    connection.close();
                }catch (SQLException e){
                    throw new ActiveObjectsException(e);
                }
            }
        }
        return DatabaseType.UNKNOWN;
    }

    public static ActiveObjects build(final EntityManager entityManager){
        return new BusinessActiveObjects(entityManager);
    }
}
