package com.tc.labt.sgabs.benchmarkdata.dto;

import com.tc.labt.sgabs.benchmarkdata.ao.CheckAccountAO;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlElement;
import java.io.Serializable;
import java.util.List;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class DataPCIImportLog implements Serializable{

    @XmlElement
    private String subsidiary;
    private int totalLines;
    private int totalInserted;
    private int totalUpdated;
    private int totalAborted;

    public DataPCIImportLog() {
        super();
    }

    public DataPCIImportLog(String subsidiary, int totalLines, int totalInserted, int totalUpdated, int totalAborted) {
        this();
        this.subsidiary = subsidiary;
        this.totalLines = totalLines;
        this.totalInserted = totalInserted;
        this.totalUpdated = totalUpdated;
        this.totalAborted = totalAborted;
    }

    public String getSubsidiary() {
        return subsidiary;
    }

    public void setSubsidiary(String subsidiary) {
        this.subsidiary = subsidiary;
    }

    public int getTotalLines() {
        return totalLines;
    }

    public void setTotalLines(int totalLines) {
        this.totalLines = totalLines;
    }

    public int getTotalInserted() {
        return totalInserted;
    }

    public void setTotalInserted(int totalInserted) {
        this.totalInserted = totalInserted;
    }

    public int getTotalUpdated() {
        return totalUpdated;
    }

    public void setTotalUpdated(int totalUpdated) {
        this.totalUpdated = totalUpdated;
    }

    public int getTotalAborted() {
        return totalAborted;
    }

    public void setTotalAborted(int totalAborted) {
        this.totalAborted = totalAborted;
    }

    public static DataPCIImportLog retrieveResultsLog(List<CheckAccountAO> checkAccountAOs){
        DataPCIImportLog dataPCIImportLog = new DataPCIImportLog();
        if(checkAccountAOs==null || checkAccountAOs.size()<=0)
            return dataPCIImportLog;
        dataPCIImportLog.setSubsidiary(checkAccountAOs.get(0).getSubsidiary());
        dataPCIImportLog.setTotalLines(checkAccountAOs.size());
        checkAccountAOs.stream().forEach(checkAccountAO -> {
            if(checkAccountAO.getCreated() == null)
                dataPCIImportLog.setTotalAborted(dataPCIImportLog.getTotalAborted()+1);
            else if(checkAccountAO.getDdmPci() == null)
                dataPCIImportLog.setTotalInserted(dataPCIImportLog.getTotalInserted()+1);
            else
                dataPCIImportLog.setTotalUpdated(dataPCIImportLog.getTotalUpdated()+1);
        });
        return dataPCIImportLog;
    }
}
