package com.tc.labt.sgabs.benchmarkdata.dto;

import java.io.Serializable;
import java.util.Date;

public class ContributorCAFK implements Serializable {

    private Contributor contributor;
    private CheckAccount checkAccount;
    private Date addedAt;

    public ContributorCAFK() {
        super();
    }

    public ContributorCAFK(Contributor contributor, CheckAccount checkAccount, Date addedAt) {
        this();
        this.contributor = contributor;
        this.checkAccount = checkAccount;
        this.addedAt = addedAt;
    }

    public Contributor getContributor() {
        return contributor;
    }

    public void setContributor(Contributor contributor) {
        this.contributor = contributor;
    }

    public CheckAccount getCheckAccount() {
        return checkAccount;
    }

    public void setCheckAccount(CheckAccount checkAccount) {
        this.checkAccount = checkAccount;
    }

    public Date getAddedAt() {
        return addedAt;
    }

    public void setAddedAt(Date addedAt) {
        this.addedAt = addedAt;
    }
}
