package com.tc.labt.sgabs.benchmarkdata.configuration.database.dto;

import com.tc.labt.sgabs.benchmarkdata.configuration.database.DatasourceType;

import java.io.Serializable;

public class DatasourceDTO implements Serializable {

    private Integer id;
    private DatasourceType type;
    private String name;

    public DatasourceDTO() { }

    public DatasourceDTO(Integer id, DatasourceType type, String name) {
        this.id = id;
        this.type = type;
        this.name = name;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public DatasourceType getType() {
        return type;
    }

    public void setType(DatasourceType type) {
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
