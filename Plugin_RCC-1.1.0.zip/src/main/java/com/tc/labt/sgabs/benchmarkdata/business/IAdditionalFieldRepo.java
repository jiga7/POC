package com.tc.labt.sgabs.benchmarkdata.business;

import com.tc.labt.sgabs.benchmarkdata.ao.AdditionalFieldAO;
import com.tc.labt.sgabs.benchmarkdata.ao.CheckAccountAO;
import com.tc.labt.sgabs.benchmarkdata.dto.AdditionalField;

import com.atlassian.activeobjects.tx.Transactional;

import java.util.List;

@Transactional
public interface IAdditionalFieldRepo {

    List<AdditionalFieldAO> saveAll(List<AdditionalField> additionalFields, CheckAccountAO checkAccountAO);

    List<AdditionalFieldAO> retrievesAllByCheckAccount(String checkAccountID);
}
