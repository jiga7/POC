package com.tc.labt.sgabs.benchmarkdata.ui;

import javax.inject.Inject;
import javax.inject.Named;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.atlassian.plugin.spring.scanner.annotation.component.Scanned;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.atlassian.sal.api.user.UserManager;
import com.atlassian.sal.api.auth.LoginUriProvider;
import com.atlassian.templaterenderer.TemplateRenderer;

import java.io.IOException;
import java.net.URI;

@Scanned
@Named
public class HomePageReferentialServlet extends HttpServlet{

    @ComponentImport
    private final UserManager userManager;
    @ComponentImport
    private final LoginUriProvider loginUriProvider;
    @ComponentImport
    private final TemplateRenderer templateRenderer;

    @Inject
    public HomePageReferentialServlet(UserManager userManager,LoginUriProvider loginUriProvider,
                                      TemplateRenderer templateRenderer){
        this.userManager = userManager;
        this.loginUriProvider = loginUriProvider;
        this.templateRenderer = templateRenderer;
    }

    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException{

        String username = userManager.getRemoteUserKey(request).getStringValue();
        if(username == null){
            redirectToLoginPage(request, response);
            return ;
        }
        response.setContentType("text/html;charset=utf-8");
        templateRenderer.render("/vm/homepage-referential.vm", response.getWriter());
    }

    private void redirectToLoginPage(HttpServletRequest request, HttpServletResponse response) throws IOException{
        response.sendRedirect(loginUriProvider.getLoginUri(getUri(request)).toASCIIString());
    }

    private URI getUri(HttpServletRequest request){

        StringBuffer buffer = request.getRequestURL();
        if(request.getQueryString() != null){
            buffer.append("?");
            buffer.append(request.getQueryString());
        }
        return URI.create(buffer.toString());
    }
}
