package com.tc.labt.sgabs.benchmarkdata.api;

import javax.inject.Inject;

import com.atlassian.plugin.spring.scanner.annotation.component.Scanned;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.atlassian.activeobjects.external.ActiveObjects;
import com.tc.labt.sgabs.benchmarkdata.ao.CheckAccountAO;
import com.tc.labt.sgabs.benchmarkdata.configuration.service.DatasourceConfigurationService;
import com.tc.labt.sgabs.benchmarkdata.dto.CheckAccount;
import com.tc.labt.sgabs.benchmarkdata.dto.DataPCIImportLog;
import com.tc.labt.sgabs.benchmarkdata.business.CheckAccountRepo;
import com.tc.labt.sgabs.benchmarkdata.service.ManageDataHorsPCI;
import com.tc.labt.sgabs.benchmarkdata.service.ManageDataPCI;
import com.tc.labt.sgabs.benchmarkdata.utils.ManageFile;
import com.tc.labt.sgabs.benchmarkdata.utils.MessageResponse;
import org.apache.commons.io.FileUtils;

import javax.servlet.ServletException;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Context;

import javax.servlet.http.HttpServletRequest;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

@Scanned
@Path("/controls")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class ControlRestAPI {

    @ComponentImport
    private final ActiveObjects activeObjects;

    private final CheckAccountRepo checkAccountRepo;
    private final ManageDataPCI manageDataPCI;

    @Inject
    public ControlRestAPI(ActiveObjects activeObjects, DatasourceConfigurationService datasourceConfigurationService){
        super();
        this.activeObjects = activeObjects;
        checkAccountRepo = new CheckAccountRepo(activeObjects, datasourceConfigurationService);
        manageDataPCI = new ManageDataPCI(activeObjects, datasourceConfigurationService);
    }

    @POST
    @Path("/horspci/save")
    public Response saveDataHorsPCI(final CheckAccount checkAccount, @Context HttpServletRequest request){

        if(checkAccount == null || checkAccount.getKey().isEmpty())
            return Response.status(422).entity(MessageResponse._422).build();

        CheckAccountAO checkAccountAO = checkAccountRepo.updateHorsPCI(checkAccount);
        return  Response.ok(CheckAccount.retrievesAOToModel(checkAccountAO)).build();
    }

    @GET
    @Path("/{key}")
    public Response getCheckAccount(final @PathParam("key") String key, @Context HttpServletRequest request) throws IOException{

        if(key.isEmpty())
            return Response.status(422).entity(MessageResponse._422).build();
        CheckAccountAO checkAccountAO = checkAccountRepo.retrievesByKey(key);
        return checkAccountAO.getKey().isEmpty()? Response.status(422).entity(MessageResponse._422).build() :
                Response.ok(CheckAccount.retrievesAOToModel(checkAccountAO)).build();
    }

    @GET
    @Path("/{subsidiary}/lists")
    public Response getCheckAccounts(final @PathParam("subsidiary") String subsidiary, @Context HttpServletRequest request)  throws IOException{

        if(subsidiary.isEmpty())
            return Response.status(422).entity(MessageResponse._422).build();
        return Response.ok(CheckAccount.retrievesAOsToModels(checkAccountRepo.retrievesAllBySubsidiary(subsidiary))).build();
    }

    @GET
    @Path("/bisme/data/load")
    public Response loadControlInFile(@Context HttpServletRequest request) throws IOException {

        List<CheckAccount> checkAccounts = ManageFile.
                getDataPCIFromFile(new File("S:\\Workspace_Luna\\benchmark-data\\import\\sgbs.csv"), true);

        List<CheckAccountAO> checkAccountAOs = checkAccountRepo.saveAll(checkAccounts);

        return Response.ok(DataPCIImportLog.retrieveResultsLog(checkAccountAOs)).build();
    }

    @GET
    @Path("/bisme/data/load/v2")
    public Response loadDataPCI(@Context HttpServletRequest request) throws IOException {
        return Response.ok(manageDataPCI.loadAllDataPCIToJira()).build();
    }

    @GET
    @Path("/bisme/data/export/{subsidiary}")
    public Response exportDataPCI(final @PathParam("subsidiary") String subsidiary, @Context HttpServletRequest request) throws IOException {
        return Response.ok(manageDataPCI.exportDataPCI(subsidiary)).build();
    }

    @GET
    @Path("/data/export")
    @Produces(MediaType.APPLICATION_OCTET_STREAM)
    public Response exportDataHorsPCI(@Context HttpServletRequest request){
        List<CheckAccountAO> checkAccountAOs = checkAccountRepo.retrievesAllBySubsidiary("SGBS");
        return Response.ok(ManageDataHorsPCI.getByteContent(ManageDataHorsPCI.retrieveWorkbook(checkAccountAOs))).build();
    }

    @POST
    @Path("/data/{subsidiary}/import")
    @Consumes(MediaType.WILDCARD)
    public Response importDataHorsPCI(final @PathParam("subsidiary") String subsidiary, byte[] controlFile,
                                      @Context HttpServletRequest request) throws IOException, ServletException {

        System.err.println("JE SUIS LA POURTANT " + (controlFile!=null? controlFile.length+ " - " + controlFile.hashCode() : "tt"));
        if(subsidiary.isEmpty() || controlFile==null)
            return Response.status(422).entity(MessageResponse._422).build();
        File test = Files.createFile(Paths.get("temp/tett")).toFile();
        FileUtils.writeByteArrayToFile(test, controlFile);
        manageDataPCI.loadDataPCIToJira(test);
        return Response.ok("SGBS").build();
    }
}
