package com.tc.labt.sgabs.benchmarkdata.business;

import com.tc.labt.sgabs.benchmarkdata.ao.CheckAccountAO;
import com.tc.labt.sgabs.benchmarkdata.ao.ReportingAO;
import com.tc.labt.sgabs.benchmarkdata.ao.ReportingCAFKAO;

import com.atlassian.activeobjects.tx.Transactional;

import java.util.List;

@Transactional
public interface IReportingCAFKRepo {

    ReportingCAFKAO save(ReportingAO reportingAO, CheckAccountAO checkAccountAO);

    List<ReportingCAFKAO> save(List<ReportingAO> reportingAOs, CheckAccountAO checkAccountAO);

    List<ReportingCAFKAO> saveAll(List<Integer> reporting_IDs, CheckAccountAO checkAccountAO);

    List<ReportingCAFKAO> retrievesByCheckAccountID(String checkControlID);

    List<ReportingCAFKAO> deleteAll(List<ReportingCAFKAO> reportingCAFKAOs);
}
