package com.tc.labt.sgabs.benchmarkdata.ao;

import net.java.ao.Entity;
import net.java.ao.OneToMany;

import java.util.Date;

public interface FileLoadedAuditAO extends Entity {

	public Date getReceived();
	public void setReceived(Date received);

	public String getSubsidiary();
	public void setSubsidiary(String subsidiary);

	public String getPath();
	public void setPath(String path);

	public String getFilename();
	public void setFilename(String filename);

	@OneToMany(reverse="getFileLoadedAudit")
	public LogAuditAO[] getLogAudits();
}