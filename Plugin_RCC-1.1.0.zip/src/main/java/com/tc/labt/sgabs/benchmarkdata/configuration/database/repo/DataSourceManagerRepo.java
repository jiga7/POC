package com.tc.labt.sgabs.benchmarkdata.configuration.database.repo;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.tc.labt.sgabs.benchmarkdata.configuration.database.ao.DatasourceAO;
import com.tc.labt.sgabs.benchmarkdata.configuration.database.dao.DatasourceDAOHandler;
import com.tc.labt.sgabs.benchmarkdata.configuration.database.dto.DatasourceDTO;
import com.tc.labt.sgabs.benchmarkdata.utils.MessageError;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;

@Service
public class DataSourceManagerRepo extends AbstractManager<DatasourceAO, DatasourceDTO, String> {

    private final ActiveObjects ao;
    private final DatasourceDAOHandler daoHandler;

    @Autowired
    public DataSourceManagerRepo(@ComponentImport ActiveObjects activeObjects, DatasourceDAOHandler datasourceDAOHandler){
        this.ao = activeObjects;
        this.daoHandler = datasourceDAOHandler;
    }

    @Override
    public List<DatasourceAO> getAll() {
        return Arrays.asList(this.ao.find(DatasourceAO.class));
    }

    @Override
    public DatasourceAO get(String name) {
        DatasourceAO[] datasourcesAO = this.ao.find(DatasourceAO.class, "NAME = ?", name);
        return datasourcesAO.length == 0 ? null : datasourcesAO[0];
    }

    @Override
    public DatasourceDTO create(DatasourceDTO param) throws Exception {
        if(param == null)
            throw MessageError.build(MessageError.NULL_OBJECT);
        DatasourceAO datasourceAO = this.daoHandler.createAOEntity(param);
        return this.retrieveModel(datasourceAO);
    }

    @Override
    public DatasourceDTO update(DatasourceDTO param) throws Exception {
        if(param == null)
            throw MessageError.build(MessageError.NULL_OBJECT);
        DatasourceAO datasourceAO = this.daoHandler.updateAOEntity((DatasourceDTO) param);
        return this.retrieveModel(datasourceAO);
    }

    @Override
    public boolean delete(String name) throws Exception {
        DatasourceAO[] datasourcesAO = this.ao.find(DatasourceAO.class, "NAME = ? ", name);
        return datasourcesAO.length>0 ?
            daoHandler.deleteAOEntity(datasourcesAO[0]) :
            false;
    }

    public static DatasourceDTO retrieveModel(DatasourceAO datasourceAO){
        DatasourceDTO datasourceDTO = new DatasourceDTO();
        datasourceDTO.setId(datasourceAO.getID());
        datasourceDTO.setType(datasourceAO.getType());
        datasourceDTO.setName(datasourceAO.getName());
        return datasourceDTO;
    }
}
