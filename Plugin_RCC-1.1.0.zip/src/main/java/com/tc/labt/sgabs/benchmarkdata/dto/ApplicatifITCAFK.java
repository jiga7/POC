package com.tc.labt.sgabs.benchmarkdata.dto;

import java.io.Serializable;
import java.util.Date;

public class ApplicatifITCAFK implements Serializable {

    private ApplicatifIT applicatifIT;
    private CheckAccount checkAccount;
    private Date addedAt;

    public ApplicatifITCAFK() {
        super();
    }

    public ApplicatifITCAFK(ApplicatifIT applicatifIT, CheckAccount checkAccount, Date addedAt) {
        this.applicatifIT = applicatifIT;
        this.checkAccount = checkAccount;
        this.addedAt = addedAt;
    }

    public ApplicatifIT getApplicatifIT() {
        return applicatifIT;
    }

    public void setApplicatifIT(ApplicatifIT applicatifIT) {
        this.applicatifIT = applicatifIT;
    }

    public CheckAccount getCheckAccount() {
        return checkAccount;
    }

    public void setCheckAccount(CheckAccount checkAccount) {
        this.checkAccount = checkAccount;
    }

    public Date getAddedAt() {
        return addedAt;
    }

    public void setAddedAt(Date addedAt) {
        this.addedAt = addedAt;
    }
}
