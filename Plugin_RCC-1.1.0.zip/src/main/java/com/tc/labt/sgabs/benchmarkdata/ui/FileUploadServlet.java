package com.tc.labt.sgabs.benchmarkdata.ui;

import com.atlassian.plugin.spring.scanner.annotation.component.Scanned;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.atlassian.sal.api.auth.LoginUriProvider;
import com.atlassian.sal.api.user.UserKey;
import com.atlassian.sal.api.user.UserManager;
import com.atlassian.templaterenderer.TemplateRenderer;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.URI;

@Named
@Scanned
public class FileUploadServlet extends HttpServlet {

    @ComponentImport
    private final UserManager userManager;
    @ComponentImport
    private final LoginUriProvider loginUriProvider;
    @ComponentImport
    private final TemplateRenderer templateRenderer;

    @Inject
    public FileUploadServlet(LoginUriProvider loginUriProvider, TemplateRenderer templateRenderer,
                             UserManager userManager) {

        this.loginUriProvider = loginUriProvider;
        this.templateRenderer = templateRenderer;
        this.userManager = userManager;
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        UserKey username = userManager.getRemoteUserKey(request);
        if(username.getStringValue() == null){
            redirectToLoginPage(request, response);
            return ;
        }
        response.setContentType("text/html;charset=utf-8");
        templateRenderer.render("/vm/uploadfile-page.vm", response.getWriter());
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    }


    private void redirectToLoginPage(HttpServletRequest request, HttpServletResponse response) throws IOException{
        response.sendRedirect(loginUriProvider.getLoginUri(getUri(request)).toASCIIString());
    }

    private URI getUri(HttpServletRequest request){

        StringBuffer buffer = request.getRequestURL();
        if(request.getQueryString() != null){
            buffer.append("?");
            buffer.append(request.getQueryString());
        }
        return URI.create(buffer.toString());
    }
}
