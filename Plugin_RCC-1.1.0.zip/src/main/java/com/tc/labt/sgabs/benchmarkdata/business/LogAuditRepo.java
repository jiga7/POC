package com.tc.labt.sgabs.benchmarkdata.business;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.plugin.spring.scanner.annotation.component.Scanned;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;

import com.tc.labt.sgabs.benchmarkdata.ao.LogAuditAO;
import com.tc.labt.sgabs.benchmarkdata.dto.LogAudit;

import net.java.ao.Query;

import javax.inject.Inject;
import javax.inject.Named;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

@Scanned
@Named
public class LogAuditRepo implements ILogAuditRepo {

    @ComponentImport
    private ActiveObjects activeObjects;

    public LogAuditRepo() {
        super();
    }

    @Inject
    public LogAuditRepo(ActiveObjects activeObjects) {
        this();
        this.activeObjects = activeObjects;
    }

    @Override
    public LogAuditAO save(final LogAudit logAudit) {

        if(logAudit != null){
            LogAuditAO logAuditAO = activeObjects.create(LogAuditAO.class);
            logAuditAO.setAuthor(logAudit.getAuthor());
            logAuditAO.setDescription(logAudit.getDescription());
            logAuditAO.setIndex(logAudit.getIndex());
            logAuditAO.setCreated(new Date());
            logAuditAO.setFileLoadedAudit(null); // A compléter
            logAuditAO.setCheckAccount(null); // A compléter
            logAuditAO.save();
            return logAuditAO;
        }else {
            // logs
        }
        return null;
    }

    @Override
    public List<LogAuditAO> retrievesAll() {
        List<LogAuditAO> logAuditAOs = Arrays.asList(activeObjects.find(LogAuditAO.class));
        return logAuditAOs;
    }

    @Override
    public List<LogAuditAO> retrievesAll(int page, int size) {
        List<LogAuditAO> logAuditAOs = Arrays.asList(activeObjects.find(LogAuditAO.class, Query.select().order("CREATED DESC").limit(size).offset(--page * size)));
        return logAuditAOs;
    }

    @Override
    public List<LogAuditAO> retrievesBySubsidiary(String subsidiary) {
        List<LogAuditAO> logAuditAOs = Arrays.asList(activeObjects.find(LogAuditAO.class, "SUBSIDIARY = ?", subsidiary));
        return logAuditAOs;
    }

    @Override
    public List<LogAuditAO> retrievesBySubsidiary(String subsidiary, int page, int size) {
        List<LogAuditAO> logAuditAOs = Arrays.asList(activeObjects.find(LogAuditAO.class, Query.select().where("SUBSIDIARY = ?", subsidiary).order("CREATED DESC").limit(size).offset(--page * size)));
        return logAuditAOs;
    }

    @Override
    public List<LogAuditAO> retrievesByAuthor(String author) {
        List<LogAuditAO> logAuditAOs = Arrays.asList(activeObjects.find(LogAuditAO.class, "AUTHOR = ?", author));
        return logAuditAOs;
    }

    @Override
    public List<LogAuditAO> retrievesByAuthor(String author, int page, int size) {
        List<LogAuditAO> logAuditAOs = Arrays.asList(activeObjects.find(LogAuditAO.class, Query.select().where("AUTHOR = ?", author).order("CREATED DESC").limit(size).offset(--page * size)));
        return logAuditAOs;
    }
}
