package com.tc.labt.sgabs.benchmarkdata.configuration.database.repo;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.activeobjects.internal.EntityManagerFactoryImpl;
import com.atlassian.jira.component.ComponentAccessor;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.tc.labt.sgabs.benchmarkdata.configuration.database.DatabaseType;
import com.tc.labt.sgabs.benchmarkdata.configuration.database.ao.DatabaseAO;
import com.tc.labt.sgabs.benchmarkdata.configuration.database.dao.DatabaseDAOHandler;
import com.tc.labt.sgabs.benchmarkdata.configuration.database.dto.DatabaseDTO;
import com.tc.labt.sgabs.benchmarkdata.utils.MessageError;
import net.java.ao.EntityManager;
import net.java.ao.schema.info.CachingEntityInfoResolverFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Collection;

@Service
public class DatabaseManagerRepo extends AbstractManager<DatabaseAO, DatabaseDTO, Integer> implements IDatabaseDAO {

    private final ActiveObjects ao;
    private final DatabaseDAOHandler daoHandler;

    private Map<String, DatabaseAO> cache;

    @Autowired
    public DatabaseManagerRepo(@ComponentImport ActiveObjects activeObjects, DatabaseDAOHandler databaseDAOHandler){
        this.ao = activeObjects;
        this.daoHandler = databaseDAOHandler;
    }

    @Override
    public Collection<DatabaseAO> getAll() {
        this.populateCache();
        return cache.values();
    }

    @Override
    public DatabaseAO get(Integer i) {
        return this.ao.get(DatabaseAO.class, i);
    }

    @Override
    public DatabaseDTO create(DatabaseDTO param) throws Exception{
        if(param==null || param.getDatasourceDTO()==null)
            throw MessageError.build(MessageError.NULL_OBJECT);
        DatabaseAO databaseAO = this.daoHandler.createAOEntity(param);
        this.removeCache();
        return this.retrieveModel(databaseAO);
    }

    @Override
    public DatabaseDTO update(DatabaseDTO param) throws Exception{
        if(param==null || param.getDatasourceDTO() == null)
            throw MessageError.build(MessageError.NULL_OBJECT);
        DatabaseAO databaseAO = this.daoHandler.updateAOEntity(param);
        this.removeCache();
        return this.retrieveModel(databaseAO);
    }

    @Override
    public boolean delete(Integer i) throws Exception {
        DatabaseAO databaseAO = this.ao.get(DatabaseAO.class, i);
        return databaseAO!=null ? daoHandler.deleteAOEntity(databaseAO):false;
    }

    @Override
    public DatabaseDTO getByDatasourceName(String name) {
        populateCache();
        DatabaseAO databaseAO = this.cache.get(name);
        return databaseAO==null ? null :  this.retrieveModel(databaseAO);
    }

    private void populateCache() {
        if(this.cache != null)
            return;
        Map<String, DatabaseAO> temporaryCache = new HashMap<>();
        Arrays.asList(ao.find(DatabaseAO.class)).parallelStream().forEach(databaseAO -> temporaryCache.put(databaseAO.getDatasourceAO().getName(), databaseAO));
        this.cache = temporaryCache;
    }

    private void removeCache(){
        this.cache = null;
    }

    private DatabaseDTO retrieveModel(DatabaseAO databaseAO){
        DatabaseDTO databaseDTO = new DatabaseDTO();
        databaseDTO.setId(databaseAO.getID());
        databaseDTO.setName(databaseAO.getName());
        databaseDTO.setType(DatabaseType.POSTGRESQL);
        databaseDTO.setHost(databaseAO.getHost());
        databaseDTO.setPort(databaseAO.getPort());
        databaseDTO.setService(databaseAO.getService());
        databaseDTO.setSchema(databaseAO.getSchema());
        databaseDTO.setLogin(databaseAO.getLogin());
        databaseDTO.setPasswordEncrypted(databaseAO.getPasswordEncrypted());
        databaseDTO.setSecretKey(databaseAO.getSecretKey());
        return databaseDTO;
    }
}
