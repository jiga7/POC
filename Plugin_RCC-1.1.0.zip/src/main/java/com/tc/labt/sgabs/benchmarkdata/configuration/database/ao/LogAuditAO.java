package com.tc.labt.sgabs.benchmarkdata.configuration.database.ao;

import net.java.ao.Entity;

import javax.xml.crypto.Data;
import java.util.Date;

public interface LogAuditAO extends Entity {

    public String getAuthor();
    public void setAuthor(String author);

    public Date getCreated();
    public void setCreated(Date created);

    public String getKey();
    public void setKey(String key);

    public String getTable();
    public void setTable(String table);

    public String getChangeLog();
    public void setChangeLog(String changeLog);

    public DatasourceAO getDatasourceAO();
    public void setDatasourceAO(DatasourceAO datasourceAO);

    public DatabaseAO getDatabaseAO();
    public void setDatabaseAO(DatabaseAO databaseAO);
}
