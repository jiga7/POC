package com.tc.labt.sgabs.benchmarkdata.ao;

import net.java.ao.Entity;
import net.java.ao.ManyToMany;

public interface ApplicatifITAO extends Entity {

	public String getCode();
	public void setCode(String code);

	public String getLib();
	public void setLib(String lib);

	public String getTyp();
	public void setTyp(String typ);

	public String getSubsidiary();
	public void setSubsidiary(String subsidiary);

	public boolean isActive();
	public void setActive(boolean active);

	@ManyToMany(value= ApplicatifITCAFKAO.class)
	public CheckAccountAO[] getCheckAccounts();
}
