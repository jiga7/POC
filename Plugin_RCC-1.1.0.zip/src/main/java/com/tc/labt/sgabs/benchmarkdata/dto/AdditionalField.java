package com.tc.labt.sgabs.benchmarkdata.dto;

import com.tc.labt.sgabs.benchmarkdata.ao.AdditionalFieldAO;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlElement;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class AdditionalField implements Serializable {

	private int id;
	@XmlElement
	private String label;
	@XmlElement
	private String value;

	private CheckAccount checkAccount;

	public AdditionalField() {
		super();
	}

	public AdditionalField(String label, String value) {
		this();
		this.label = label;
		this.value = value;
	}

	public AdditionalField(int id, String label, String value, CheckAccount checkAccount) {
		this(label, value);
		this.id = id;
		this.checkAccount = checkAccount;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public CheckAccount getCheckAccount() {
		return checkAccount;
	}

	public void setCheckAccount(CheckAccount checkAccount) {
		this.checkAccount = checkAccount;
	}

	public static List<AdditionalField> retrievesAOsToModels(List<AdditionalFieldAO> additionalFieldAOs){

		if(additionalFieldAOs==null || additionalFieldAOs.size()==0)
			return null;
		List<AdditionalField> additionalFields = new ArrayList<>();
		additionalFieldAOs.forEach(additionalFieldAO -> additionalFields.add(new AdditionalField(additionalFieldAO.getID(), additionalFieldAO.getLabel(), additionalFieldAO.getValue(), null)));
		return additionalFields;
	}

	public static List<AdditionalField> retrievesAOsToModels(AdditionalFieldAO[] additionalFieldAOs) {
		return retrievesAOsToModels(Arrays.asList(additionalFieldAOs));
	}
}
