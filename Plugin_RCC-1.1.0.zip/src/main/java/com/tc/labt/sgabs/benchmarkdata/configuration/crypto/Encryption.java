package com.tc.labt.sgabs.benchmarkdata.configuration.crypto;

import com.google.common.collect.Maps;

import javax.crypto.*;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.InvalidParameterSpecException;
import java.util.Base64;
import java.util.Map;

public class Encryption {

    private final static String ALGORITHM_KEY_SECRET = "PBKDF2WithHmacSHA512";
    private final static String ALGORITHM_ENCODING = "AES";
    private final static String ALGORITHM_TRANSFORMATION = "AES/CBC/PKCS5Padding";

    private static final String STATIC_PASSWORD_KEY = "*ds !e'%dk24(§+)à'°";

    public final static String IV = "iv";
    public final static String CRYPT = "crypt";

    private static final int iterationCount = 50000;
    private static final int keyLength = 256;
    private static final String salt = "!§*^é[(|)]=}{'_-.0123456789+µ£,;?:/";

    private static SecretKeySpec createSecreKey(char[] password) throws NoSuchAlgorithmException, InvalidKeySpecException {
        PBEKeySpec keySpec = new PBEKeySpec(password, salt.getBytes(), iterationCount, keyLength);
        return new SecretKeySpec(SecretKeyFactory.getInstance(ALGORITHM_KEY_SECRET)
                .generateSecret(keySpec).getEncoded(), ALGORITHM_ENCODING);
    }

    private static  Map<String, String> encrypt(String dataToEncrypt, SecretKeySpec keySpec)
            throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeyException, InvalidParameterSpecException, IllegalBlockSizeException, BadPaddingException {
        Cipher cipher = Cipher.getInstance(ALGORITHM_TRANSFORMATION);
        cipher.init(Cipher.ENCRYPT_MODE, keySpec);
        return retrieveMapResult(Base64.getEncoder().encodeToString(cipher.getParameters().getParameterSpec(IvParameterSpec.class).getIV()),
                Base64.getEncoder().encodeToString(cipher.doFinal(dataToEncrypt.getBytes(StandardCharsets.UTF_8))));
    }

    private static String decrypt(Map<String, String> encrypted, SecretKeySpec keySpec)
            throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidAlgorithmParameterException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
        Cipher cipher = Cipher.getInstance(ALGORITHM_TRANSFORMATION);
        cipher.init(Cipher.DECRYPT_MODE, keySpec, new IvParameterSpec(Base64.getDecoder().decode(encrypted.get(IV))));
        return new String(cipher.doFinal(Base64.getDecoder().decode(encrypted.get(CRYPT))));
    }

    private static Map<String, String> retrieveMapResult(String iv, String crypt){
        Map<String, String> result = Maps.newHashMap();
        result.put(IV, iv);
        result.put(CRYPT, crypt);
        return result;
    }

    public static Map<String, String> encrypt(String password) throws GeneralSecurityException {
        SecretKeySpec keySpec = createSecreKey(STATIC_PASSWORD_KEY.toCharArray());
        return encrypt(password, keySpec);
    }

    public static String decrypt(String iv, String crypt) throws GeneralSecurityException {
        SecretKeySpec keySpec = createSecreKey(STATIC_PASSWORD_KEY.toCharArray());
        return decrypt(retrieveMapResult(iv, crypt), keySpec);
    }
}
