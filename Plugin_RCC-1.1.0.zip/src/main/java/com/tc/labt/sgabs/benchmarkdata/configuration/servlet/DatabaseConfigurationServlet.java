package com.tc.labt.sgabs.benchmarkdata.configuration.servlet;

import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.atlassian.sal.api.auth.LoginUriProvider;
import com.atlassian.sal.api.user.UserManager;
import com.atlassian.templaterenderer.TemplateRenderer;
import com.google.common.base.Strings;
import com.google.common.collect.Maps;
import com.tc.labt.sgabs.benchmarkdata.configuration.database.dto.DatabaseDTO;
import com.tc.labt.sgabs.benchmarkdata.configuration.service.DatasourceConfigurationService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.URI;
import java.util.Arrays;
import java.util.Map;
import java.util.Objects;

public class DatabaseConfigurationServlet extends HttpServlet {

    private static final Logger log = LoggerFactory.getLogger(DatabaseConfigurationServlet.class);

    private final TemplateRenderer renderer;
    private final UserManager userManager;
    private final LoginUriProvider uriProvider;
    private DatasourceConfigurationService configurationService;

    @Inject
    public DatabaseConfigurationServlet(@ComponentImport LoginUriProvider loginUriProvider, @ComponentImport TemplateRenderer templateRenderer,
                                        @ComponentImport UserManager userManager, DatasourceConfigurationService datasourceConfigurationService){
        this.renderer = templateRenderer;
        this.userManager = userManager;
        this.uriProvider = loginUriProvider;
        this.configurationService = datasourceConfigurationService;
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String subsidiary = request.getParameter("subsidiary");
        Map<String, Object> context = Maps.newHashMap();
        context.put("properties", configurationService.getDatabaseProperties(subsidiary, null));
        context.put("databaseTypes", DatabaseDTO.getDatabaseType());
        context.put("subsidiary", Strings.nullToEmpty(subsidiary));
        context.put("subsidiaries", Arrays.asList("SGBS", "SGBG", "SGCAM"));
        response.setContentType("text/html;charset=utf8");
        renderer.render("/vm/dbconfig.vm", context, response.getWriter());
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        DatabaseDTO databaseDTO = configurationService.retrieveDataInRequest(request.getParameterMap());
        Map<String, Object> context = Maps.newHashMap();
        DatabaseDTO dataSaved = null;
        if(databaseDTO.isValid()){
            try {
                dataSaved = configurationService.saveOrUpdate(databaseDTO);
                context.put("success", true);
            } catch (Exception e) {
                context.put("errorMessage", e.getMessage());
            }
        }
        context.put("subsidiary", databaseDTO.getDatasourceDTO().getName());
        context.put("subsidiaries", Arrays.asList("SGBS", "SGBG", "SGCAM"));
        context.put("properties", configurationService.getDatabaseProperties(databaseDTO.getName(), Objects.nonNull(dataSaved)? dataSaved : databaseDTO));
        response.setContentType("text/html;charset=utf8");
        renderer.render("/vm/dbconfig.vm", context, response.getWriter());
    }

    private void redirectLoginPage(HttpServletRequest request, HttpServletResponse response) throws IOException{
        response.sendRedirect(uriProvider.getLoginUri(getURI(request)).toASCIIString());
    }

    private URI getURI(HttpServletRequest request) {
        StringBuffer buffer = request.getRequestURL();
        if(request.getQueryString() != null){
            buffer.append("?");
            buffer.append(request.getQueryString());
        }
        return URI.create(buffer.toString());
    }
}
