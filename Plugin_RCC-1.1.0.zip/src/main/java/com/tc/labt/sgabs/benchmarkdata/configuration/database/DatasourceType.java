package com.tc.labt.sgabs.benchmarkdata.configuration.database;

public enum DatasourceType {

    DATABASE("Database"), API("Api");

    private final String value;

    DatasourceType(String value) {this.value = value;}

    public String getName() {return this.value;}
}
