package com.tc.labt.sgabs.benchmarkdata.api;

import com.tc.labt.sgabs.benchmarkdata.ao.OperationAO;
import com.tc.labt.sgabs.benchmarkdata.dto.Operation;
import com.tc.labt.sgabs.benchmarkdata.business.OperationRepo;
import com.tc.labt.sgabs.benchmarkdata.utils.MessageResponse;

import javax.inject.Inject;

import com.atlassian.plugin.spring.scanner.annotation.component.Scanned;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;

import javax.servlet.http.HttpServletRequest;

import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.PathParam;
import javax.ws.rs.Path;
import javax.ws.rs.POST;
import javax.ws.rs.GET;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.MediaType;

import com.atlassian.activeobjects.external.ActiveObjects;

import java.io.IOException;
import java.util.List;

@Path("/operations")
@Scanned
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class OperationRestAPI {

    @ComponentImport
    private final ActiveObjects activeObjects;

    private final OperationRepo operationRepo;

    @Inject
    public OperationRestAPI(ActiveObjects activeObjects){
        super();
        this.activeObjects = activeObjects;
        operationRepo = new OperationRepo(activeObjects);
    }

    @POST
    @Path("/add")
    public Response addOperation(final Operation operation, @Context HttpServletRequest request) throws IOException{

        if(operation == null || operation.getOpe().isEmpty() || operation.getSubsidiary() ==null || operation.getSubsidiary().isEmpty())
            return Response.status(422).entity(MessageResponse._422).build();

        OperationAO operationAO = operationRepo.save(operation);
        return operationAO.getID() == 0 ?
                Response.status(500).entity(MessageResponse._500).build() :
                Response.ok(Operation.retrievesAOToModel(operationAO)).build();
    }

    @GET
    @Path("/views/{subsidiary}/all")
    public Response getOperations(final @PathParam("subsidiary") String subsidiary, @Context HttpServletRequest request) throws IOException{

        if(subsidiary == null || subsidiary.isEmpty())
            return Response.status(422).entity(MessageResponse._422).build();

        List<Operation> operations = Operation.retrievesAOsToModels(operationRepo.retrievesBySubsidiary(subsidiary));
        return operations==null || operations.size()==0? Response.status(204).entity(MessageResponse._204).build() : Response.ok(operations).build();
    }

    @GET
    @Path("/lists/{subsidiary}")
    public Response getOperationsList(final @PathParam("subsidiary") String subsidiary, @Context HttpServletRequest request) throws IOException{
        return Response.ok(Operation.retrievesListOption(operationRepo.retrievesEnabledBySubsidiary(subsidiary))).build();
    }
}
