package com.tc.labt.sgabs.benchmarkdata.business;

import com.tc.labt.sgabs.benchmarkdata.ao.AdditionalFieldAO;
import com.tc.labt.sgabs.benchmarkdata.ao.CheckAccountAO;
import com.tc.labt.sgabs.benchmarkdata.dto.AdditionalField;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.plugin.spring.scanner.annotation.component.Scanned;

import javax.inject.Inject;
import javax.inject.Named;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Scanned
@Named
public class AdditionalFieldRepo implements IAdditionalFieldRepo{

    private ActiveObjects activeObjects;

    public AdditionalFieldRepo() {
        super();
    }

    @Inject
    public AdditionalFieldRepo(ActiveObjects activeObjects) {
        this();
        this.activeObjects = activeObjects;
    }

    private AdditionalFieldAO save (AdditionalField additionalField, CheckAccountAO checkAccountAO){

        if(additionalField != null){
            AdditionalFieldAO additionalFieldAO = activeObjects.create(AdditionalFieldAO.class);
            additionalFieldAO.setLabel(additionalField.getLabel());
            additionalFieldAO.setValue(additionalField.getValue());
            additionalFieldAO.setCheckAccount(checkAccountAO);
            additionalFieldAO.save();
            return additionalFieldAO;
        }else{
            // logs
        }
        return null;
    }

    @Override
    public List<AdditionalFieldAO> saveAll(List<AdditionalField> additionalFields,final CheckAccountAO checkAccountAO){

        List<AdditionalFieldAO> additionalFieldAOs = new ArrayList<>();
        additionalFields.forEach(additionalField -> additionalFieldAOs.add(this.save(additionalField, checkAccountAO)));
        return additionalFieldAOs;
    }

    @Override
    public List<AdditionalFieldAO> retrievesAllByCheckAccount(String checkAccountID) {

        return checkAccountID == null || checkAccountID.isEmpty() ?
                null :
                Arrays.asList(activeObjects.find(AdditionalFieldAO.class, "Check_Account_ID = ?", checkAccountID));
    }
}
