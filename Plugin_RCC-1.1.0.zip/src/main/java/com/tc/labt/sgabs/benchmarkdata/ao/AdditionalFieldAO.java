package com.tc.labt.sgabs.benchmarkdata.ao;

import net.java.ao.Entity;

public interface AdditionalFieldAO extends Entity {
	
	public String getLabel();
	public void setLabel(String label);

	public String getValue();
	public void setValue(String value);

	public CheckAccountAO getCheckAccount();
	public void setCheckAccount(CheckAccountAO checkAccount);
}
