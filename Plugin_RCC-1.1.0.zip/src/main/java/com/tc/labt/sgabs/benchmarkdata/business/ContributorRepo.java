package com.tc.labt.sgabs.benchmarkdata.business;

import com.tc.labt.sgabs.benchmarkdata.ao.ContributorAO;
import com.tc.labt.sgabs.benchmarkdata.dto.Contributor;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.plugin.spring.scanner.annotation.component.Scanned;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;

import javax.inject.Named;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Scanned
@Named
public class ContributorRepo implements IContributorRepo{

    @ComponentImport
    private ActiveObjects activeObjects;

    public  ContributorRepo(){
        super();
    }

    public ContributorRepo(ActiveObjects activeObjects) {
        this();
        this.activeObjects = activeObjects;
    }

    @Override
    public ContributorAO saveOrRetrieves(Contributor contributor) {

        if(contributor == null)
            return  null;

        ContributorAO[] contributorAOs = activeObjects.find(ContributorAO.class, "USERNAME = ?", contributor.getUsername());
        if(contributorAOs.length > 0)
            return contributorAOs[0];

        ContributorAO contributorAO = activeObjects.create(ContributorAO.class);
        contributorAO.setUsername(contributor.getUsername());
        contributorAO.setSubsidiary(contributor.getSubsidiary());
        contributorAO.setFullname(contributor.getFullname());
        contributorAO.save();
        return contributorAO;
    }

    @Override
    public List<ContributorAO> saveOrRetrievesAll(List<Contributor> contributors) {

        List<ContributorAO> contributorAOs = new ArrayList<>();
        contributors.parallelStream().forEach(contributor -> contributorAOs.add(saveOrRetrieves(contributor)));
        return contributorAOs;
    }

    @Override
    public List<ContributorAO> retrievesAll() {
        List<ContributorAO> contributorAOs = Arrays.asList(activeObjects.find(ContributorAO.class));
        return contributorAOs;
    }

    @Override
    public List<ContributorAO> retrievesAllByCheckControl(Integer checkControlID) {
        return null;
    }

    @Override
    public List<ContributorAO> retrievesAllBySubsidiary(String subsidiary) {
        List<ContributorAO> contributorAOs = Arrays.asList(activeObjects.find(ContributorAO.class, "SUBSIDIARY = ?", subsidiary));
        return contributorAOs;
    }

    @Override
    public List<ContributorAO> retrievesAllByIds(List<Integer> ids) {

        if(ids.size()<=0)
            return null;

        String contributors_ID_Parameters = Collections.nCopies(ids.size(), "?").stream().collect(Collectors.joining(","));
        List<ContributorAO> contributorAOs = Arrays.asList(activeObjects.find(ContributorAO.class, "ID IN ("+contributors_ID_Parameters+")", ids.toArray()));
        return contributorAOs;
    }
}
