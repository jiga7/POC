package com.tc.labt.sgabs.benchmarkdata.ao;

import net.java.ao.Entity;
import net.java.ao.OneToMany;

import java.util.Date;

public interface ContributorCAFKAO extends Entity{

    public ContributorAO getContributorAo();
    public void setContributorAo(ContributorAO contributor);

    public CheckAccountAO getCheckAccountAo();
    public void setCheckAccountAo(CheckAccountAO checkAccountAo);

    public Date getAddedAt();
    public void setAddedAt(Date addedAt);

    @OneToMany(reverse = "getContributorCAFKAO")
    public LogAuditAO[] getLogAudits();
}
