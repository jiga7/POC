package com.tc.labt.sgabs.benchmarkdata.dto;

import com.tc.labt.sgabs.benchmarkdata.ao.MethodControlAO;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlElement;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class MethodControl implements Serializable {

	private int id;

	@XmlElement
	private String code;
	@XmlElement
	private String method;
	@XmlElement
	private String subsidiary;
	@XmlElement
	private Date created;

	private boolean active;

	private CheckAccount[] checkAccounts;

	public MethodControl() {
	}
	public MethodControl(String code) {
		super();
		this.code = code;
	}

	public MethodControl(String code, String method, String subsidiary) {
		this(code);
		this.method = method;
		this.subsidiary = subsidiary;
	}

	public MethodControl(String code, String method, String subsidiary, Date created, boolean active) {
		this(code, method, subsidiary);
		this.created = created;
		this.active = active;
	}

	public int getId() { return id; }

	public void setId(int id) { this.id = id; }

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getMethod() {
		return method;
	}

	public void setMethod(String method) {
		this.method = method;
	}

	public String getSubsidiary() {
		return subsidiary;
	}

	public void setSubsidiary(String subsidiary) {
		this.subsidiary = subsidiary;
	}

	public Date getCreated() {
		return created;
	}

	public void setCreated(Date created) {
		this.created = created;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public CheckAccount[] getCheckAccounts() {
		return checkAccounts;
	}

	public void setCheckAccounts(CheckAccount[] checkAccounts) {
		this.checkAccounts = checkAccounts;
	}

	public static MethodControl retrievesAOToModel(final MethodControlAO methodControlAO){
		return methodControlAO == null? null : new MethodControl(methodControlAO.getCode(), methodControlAO.getMethod(), methodControlAO.getSubsidiary(), methodControlAO.getCreated(), methodControlAO.isActive());
	}

	public static List<MethodControl> retrievesAOsToModels(final MethodControlAO[] methodControlAOs) {
		return retrievesAOsToModels(Arrays.asList(methodControlAOs));
	}

	public static List<MethodControl> retrievesAOsToModels(final List<MethodControlAO> methodControlAOs){

		List<MethodControl> methodControls = new ArrayList<>(methodControlAOs.size());
		methodControlAOs.forEach(methodControlAO -> methodControls.add(retrievesAOToModel(methodControlAO)));
		return methodControls;
	}

	public static List<Option> retrievesListOption(final List<MethodControlAO> methodControlAOs){
		return methodControlAOs
				.stream().parallel()
				.map(methodControlAO -> new Option(methodControlAO.getCode(), methodControlAO.getMethod(), methodControlAO.getCode()))
				.collect(Collectors.toList());
	}
}