package com.tc.labt.sgabs.benchmarkdata.entity;

import com.tc.labt.sgabs.benchmarkdata.ao.CheckAccountAO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.Entity;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;
import java.util.Date;


/*
@Data
@NoArgsConstructor
@AllArgsConstructor*/
@Entity
@javax.persistence.Entity
@Table(name = "methodControlAO")
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class MethodControlAO implements Serializable {

	@Id
	private long id;
	private String code;
	private String method;
	private String subsidiary;
	private Date created;
	private boolean active;

	public MethodControlAO() { }

	public MethodControlAO(long id, String code, String method, String subsidiary, Date created, boolean active) {
		this.id = id;
		this.code = code;
		this.method = method;
		this.subsidiary = subsidiary;
		this.created = created;
		this.active = active;
	}

	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}

	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}

	public String getMethod() {
		return method;
	}
	public void setMethod(String method) {
		this.method = method;
	}

	public String getSubsidiary() {
		return subsidiary;
	}
	public void setSubsidiary(String subsidiary) {
		this.subsidiary = subsidiary;
	}

	public Date getCreated() {
		return created;
	}
	public void setCreated(Date created) {
		this.created = created;
	}

	public boolean isActive() {
		return active;
	}
	public void setActive(boolean active) {
		this.active = active;
	}
}