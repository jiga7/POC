package com.tc.labt.sgabs.benchmarkdata.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlElement;

import com.tc.labt.sgabs.benchmarkdata.ao.FileLoadedAuditAO;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class FileLoadedAudit implements Serializable {

	@XmlElement
	private Date received;
	@XmlElement
	private String subsidiary;
	@XmlElement
	private String path;
	@XmlElement
	private String filename;

	private List<LogAudit> logAudits;

	public FileLoadedAudit() {
		super();
	}

	public FileLoadedAudit(String subsidiary, String path, String filename) {
		this();
		this.subsidiary = subsidiary;
		this.path = path;
		this.filename = filename;
	}

	public FileLoadedAudit(Date received, String subsidiary, String path, String filename, List<LogAudit> logAudits) {
		this(subsidiary, path, filename);
		this.received = received;
		this.logAudits = logAudits;
	}

	public Date getReceived() {
		return received;
	}

	public void setReceived(Date received) {
		this.received = received;
	}

	public String getSubsidiary() {
		return subsidiary;
	}

	public void setSubsidiary(String subsidiary) {
		this.subsidiary = subsidiary;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public String getFilename() {
		return filename;
	}

	public void setFilename(String filename) {
		this.filename = filename;
	}

	public List<LogAudit> getLogAudits() {
		return logAudits;
	}

	public void setLogAudits(List<LogAudit> logAudits) {
		this.logAudits = logAudits;
	}

	public static FileLoadedAudit retrievesAOToModel(FileLoadedAuditAO fileLoadedAuditAO){
		return fileLoadedAuditAO.getID() == 0 ? null : new FileLoadedAudit(fileLoadedAuditAO.getReceived(), fileLoadedAuditAO.getSubsidiary(), fileLoadedAuditAO.getPath(), fileLoadedAuditAO.getFilename(), LogAudit.retrievesAOsToModels(fileLoadedAuditAO.getLogAudits()));
	}

	public static List<FileLoadedAudit> retrievesAOsToModels(FileLoadedAuditAO[]fileLoadedAuditAOs){
		return retrievesAOsToModels(Arrays.asList(fileLoadedAuditAOs));
	}

	public static List<FileLoadedAudit> retrievesAOsToModels(List<FileLoadedAuditAO> fileLoadedAuditAOs){
		List<FileLoadedAudit> fileLoadedAudits = new ArrayList<>();
		fileLoadedAuditAOs.forEach( fileLoadedAuditAO -> fileLoadedAudits.add(retrievesAOToModel(fileLoadedAuditAO)));
		return fileLoadedAudits;
	}
}