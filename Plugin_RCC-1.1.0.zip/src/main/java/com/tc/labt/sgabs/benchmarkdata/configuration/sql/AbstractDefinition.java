package com.tc.labt.sgabs.benchmarkdata.configuration.sql;

import com.tc.labt.sgabs.benchmarkdata.configuration.database.DatabaseType;
import com.tc.labt.sgabs.benchmarkdata.configuration.database.dto.DatabaseDTO;
import com.tc.labt.sgabs.benchmarkdata.utils.MessageError;

public abstract class AbstractDefinition implements Cloneable{

    private final String prefixUrl;

    private final DatabaseType databaseType;

    private final String driverClassName;

    public AbstractDefinition(String prefixUrl, DatabaseType databaseType, String driverClassName){
        this.prefixUrl = prefixUrl;
        this.databaseType = databaseType;
        this.driverClassName = driverClassName;
    }

    public String getPrefixUrl(){
        return this.prefixUrl;
    }

    public DatabaseType getDatabaseType(){
        return this.databaseType;
    }

    public String getDriverClassName(){
        return this.driverClassName;
    }

    public String buildUrlFromConfiguration(DatabaseDTO database){
        return getPrefixUrl() + database.getHost() + ":" + database.getPort() + "/" + database.getName();
    }

    public boolean hasSchemaSupport(){ return false; }

    public Object clone(){
        Object clone = null;
        try{
            clone = super.clone();
        }catch (CloneNotSupportedException e){
            MessageError.build(e.getMessage());
            e.printStackTrace();
        }
        return clone;
    }
}
