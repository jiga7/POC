package com.tc.labt.sgabs.benchmarkdata.business;

import com.tc.labt.sgabs.benchmarkdata.ao.CheckAccountAO;
import com.tc.labt.sgabs.benchmarkdata.dto.CheckAccount;

import com.atlassian.activeobjects.tx.Transactional;

import java.util.List;

@Transactional
public interface ICheckAccountRepo {

    CheckAccountAO savePCI(CheckAccount checkAccount);

    CheckAccountAO updateHorsPCI(CheckAccount checkAccount);

    List<CheckAccountAO> saveAll(List<CheckAccount> checkAccounts);

    CheckAccountAO retrievesByKey(String key);

    List<CheckAccountAO> retrievesEnabledBySubsidiary(String subsidiary);

    List<CheckAccountAO> retrievesAllBySubsidiary(String subsidiary);
}
