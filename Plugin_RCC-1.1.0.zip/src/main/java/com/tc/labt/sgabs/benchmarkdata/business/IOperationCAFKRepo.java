package com.tc.labt.sgabs.benchmarkdata.business;

import com.atlassian.activeobjects.tx.Transactional;
import com.tc.labt.sgabs.benchmarkdata.ao.CheckAccountAO;
import com.tc.labt.sgabs.benchmarkdata.ao.OperationAO;
import com.tc.labt.sgabs.benchmarkdata.ao.OperationCAFKAO;

import java.util.List;

@Transactional
public interface IOperationCAFKRepo {

    OperationCAFKAO save(OperationAO operationAO, CheckAccountAO checkAccountAO);

    List<OperationCAFKAO> save(List<OperationAO> operationAOs, CheckAccountAO checkAccountAO);

    List<OperationCAFKAO> saveAll(List<Integer> operation_IDs, CheckAccountAO checkAccountAO);

    List<OperationCAFKAO> retrieveByCheckAccountID(String checkAccountID);

    List<OperationCAFKAO> deleteAll(List<OperationCAFKAO> operationCAFKAOs);
}
