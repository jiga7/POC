package com.tc.labt.sgabs.benchmarkdata.configuration.database.repo;

import com.tc.labt.sgabs.benchmarkdata.configuration.database.dto.DatabaseDTO;

public interface IDatabaseDAO {

    DatabaseDTO getByDatasourceName(String name) throws Exception;
}
