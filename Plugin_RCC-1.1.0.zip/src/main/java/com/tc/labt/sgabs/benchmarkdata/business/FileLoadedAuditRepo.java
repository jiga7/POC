package com.tc.labt.sgabs.benchmarkdata.business;

import com.tc.labt.sgabs.benchmarkdata.ao.FileLoadedAuditAO;
import com.tc.labt.sgabs.benchmarkdata.dto.FileLoadedAudit;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

import net.java.ao.Query;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.plugin.spring.scanner.annotation.component.Scanned;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;

import javax.inject.Named;

@Scanned
@Named
public class FileLoadedAuditRepo implements IFileLoadedAuditRepo {

    @ComponentImport
    private ActiveObjects activeObjects;

    public FileLoadedAuditRepo() {
        super();
    }

    public FileLoadedAuditRepo(ActiveObjects activeObjects) {
        this();
        this.activeObjects = activeObjects;
    }

    @Override
    public FileLoadedAuditAO save(FileLoadedAudit fileLoadedAudit) {

        if(fileLoadedAudit != null){
            FileLoadedAuditAO fileLoadedAuditAO = activeObjects.create(FileLoadedAuditAO.class);
            fileLoadedAuditAO.setReceived(new Date());
            fileLoadedAuditAO.setFilename(fileLoadedAudit.getFilename());
            fileLoadedAuditAO.setPath(fileLoadedAudit.getPath());
            fileLoadedAuditAO.setSubsidiary(fileLoadedAudit.getSubsidiary());
            fileLoadedAuditAO.save();
            return fileLoadedAuditAO;
        }else{
            // logs
        }
        return null;
    }

    @Override
    public List<FileLoadedAuditAO> retrievesAll() {
        List<FileLoadedAuditAO> fileLoadedAuditAOs = Arrays.asList(activeObjects.find(FileLoadedAuditAO.class));
        return fileLoadedAuditAOs;
    }

    @Override
    public List<FileLoadedAuditAO> retrievesAll(int page, int size) {
        List<FileLoadedAuditAO> fileLoadedAuditAOs = Arrays.asList(activeObjects.find(FileLoadedAuditAO.class, Query.select().order("RECEIVED DESC").limit(size).offset(--page * size)));
        return fileLoadedAuditAOs;
    }

    @Override
    public List<FileLoadedAuditAO> retrievesBySubsidiary(String subsidiary) {
        List<FileLoadedAuditAO> fileLoadedAuditAOs = Arrays.asList(activeObjects.find(FileLoadedAuditAO.class, "SUBSIDIARY = ?", subsidiary));
        return fileLoadedAuditAOs;
    }

    @Override
    public List<FileLoadedAuditAO> retrievesBySubsidiary(String subsidiary, int page, int size) {
        List<FileLoadedAuditAO> fileLoadedAuditAOs = Arrays.asList(activeObjects.find(FileLoadedAuditAO.class, Query.select().where("SUBSIDIARY = ?", subsidiary).order("RECEIVED DESC").limit(size).offset(--page * size)));
        return fileLoadedAuditAOs;
    }
}
