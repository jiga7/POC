package com.tc.labt.sgabs.benchmarkdata.ao;

import net.java.ao.Entity;
import net.java.ao.OneToMany;

import java.util.Date;

public interface MethodControlAO extends Entity {

	public String getCode();
	public void setCode(String code);

	public String getMethod();
	public void setMethod(String method);

	public String getSubsidiary();
	public void setSubsidiary(String subsidiary);
	
	public Date getCreated();
	public void setCreated(Date created);

	public boolean isActive();
	public void setActive(boolean active);

	@OneToMany
	public CheckAccountAO[] getCheckAccounts();
}