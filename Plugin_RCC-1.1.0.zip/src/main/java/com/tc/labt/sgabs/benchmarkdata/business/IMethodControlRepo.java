package com.tc.labt.sgabs.benchmarkdata.business;

import com.tc.labt.sgabs.benchmarkdata.ao.MethodControlAO;

import com.atlassian.activeobjects.tx.Transactional;
import com.tc.labt.sgabs.benchmarkdata.dto.MethodControl;

import java.util.List;

@Transactional
public interface IMethodControlRepo {

    MethodControlAO save(MethodControl methodControl);

    com.tc.labt.sgabs.benchmarkdata.entity.MethodControlAO saveP(final MethodControl methodControl);

    MethodControlAO retrievesByCode(String code, String subsidiary);

    MethodControlAO enableOrDisable(MethodControl methodControl, boolean enable);

    List<MethodControlAO> retrievesBySubsidiary(String subsidiary);

    List<com.tc.labt.sgabs.benchmarkdata.entity.MethodControlAO> retrievesBySubsidiaryP(String subsidiary);

    List<MethodControlAO> retrievesEnabledBySubsidiary(String subsidiary);
}
