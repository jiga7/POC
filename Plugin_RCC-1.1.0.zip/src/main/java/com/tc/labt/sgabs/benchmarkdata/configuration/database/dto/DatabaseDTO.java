package com.tc.labt.sgabs.benchmarkdata.configuration.database.dto;

import com.google.common.base.Strings;
import com.tc.labt.sgabs.benchmarkdata.configuration.database.DatabaseType;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import java.io.Serializable;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class DatabaseDTO implements Serializable {

    private Integer id;
    private String name;
    private DatabaseType type;
    private String host;
    private String login;
    private String password;
    @XmlTransient
    private String passwordEncrypted;
    @XmlTransient
    private String secretKey;
    private String port;
    private String schema;
    private String service;

    private DatasourceDTO datasourceDTO;

    public DatabaseDTO() { }

    public DatabaseDTO(Integer id, String name, DatabaseType type, String host, String login, String password, String passwordEncrypted, String secretKey, String port, String schema, String service) {
        this.id = id;
        this.name = name;
        this.type = type;
        this.host = host;
        this.login = login;
        this.password = password;
        this.passwordEncrypted = passwordEncrypted;
        this.secretKey = secretKey;

        this.port = port;
        this.schema = schema;
        this.service = service;
    }

    public DatabaseDTO(Integer id, String name, DatabaseType type, String host, String login, String password, String passwordEncrypted, String secretKey, String port, String schema, String service, DatasourceDTO datasourceDTO) {
        this(id,name,type,host,login,password, passwordEncrypted, secretKey, port,schema,service);
        this.datasourceDTO = datasourceDTO;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public DatabaseType getType() {
        return type;
    }

    public void setType(DatabaseType type) {
        this.type = type;
    }

    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPasswordEncrypted() { return passwordEncrypted; }

    public void setPasswordEncrypted(String passwordEncrypted) {this.passwordEncrypted = passwordEncrypted;}

    public String getSecretKey() {return secretKey; }

    public void setSecretKey(String secretKey) {this.secretKey = secretKey;}

    public String getPort() {
        return port;
    }

    public void setPort(String port) {
        this.port = port;
    }

    public String getSchema() {
        return schema;
    }

    public void setSchema(String schema) {
        this.schema = schema;
    }

    public String getService() {
        return service;
    }

    public void setService(String service) {
        this.service = service;
    }

    public DatasourceDTO getDatasourceDTO() {
        return datasourceDTO;
    }

    public void setDatasourceDTO(DatasourceDTO datasourceDTO) {
        this.datasourceDTO = datasourceDTO;
    }

    public boolean isValid(){
        return !(Strings.isNullOrEmpty(host) || Strings.isNullOrEmpty(getName()) || Objects.isNull(getDatabaseType()));
    }

    public static List getDatabaseType(){
        return Arrays.asList(DatabaseType.MYSQL, DatabaseType.ORACLE, DatabaseType.SQLSERVER, DatabaseType.POSTGRESQL);
    }
}
