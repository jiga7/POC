package com.tc.labt.sgabs.benchmarkdata.configuration.sql;

import com.tc.labt.sgabs.benchmarkdata.configuration.database.DatabaseType;
import com.tc.labt.sgabs.benchmarkdata.configuration.database.dto.DatabaseDTO;

public class OracleDefinition extends AbstractDefinition{

    public OracleDefinition() {
        super("jdbc:oracle:thin:@", DatabaseType.ORACLE, "oracle.jdbc.driver.OracleDriver");
    }

    @Override
    public String buildUrlFromConfiguration(DatabaseDTO database) {
        return getPrefixUrl() + database.getHost() + ":" + database.getPort() + ":" + database.getService();
    }
}
