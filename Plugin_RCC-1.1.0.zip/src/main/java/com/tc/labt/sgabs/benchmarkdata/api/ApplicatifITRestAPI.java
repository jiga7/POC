package com.tc.labt.sgabs.benchmarkdata.api;

import javax.inject.Inject;

import com.atlassian.plugin.spring.scanner.annotation.component.Scanned;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.PathParam;
import javax.ws.rs.Path;
import javax.ws.rs.POST;
import javax.ws.rs.GET;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.MediaType;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.tc.labt.sgabs.benchmarkdata.ao.ApplicatifITAO;
import com.tc.labt.sgabs.benchmarkdata.dto.ApplicatifIT;
import com.tc.labt.sgabs.benchmarkdata.business.ApplicatifITRepo;
import com.tc.labt.sgabs.benchmarkdata.utils.MessageResponse;

import java.io.IOException;
import java.util.List;

@Path("/applicatifs")
@Scanned
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class ApplicatifITRestAPI {

    @ComponentImport
    private final ActiveObjects activeObjects;

    private final ApplicatifITRepo applicatifITRepo;

    @Inject
    public ApplicatifITRestAPI(ActiveObjects activeObjects){
        super();
        this.activeObjects = activeObjects;
        this.applicatifITRepo = new ApplicatifITRepo(activeObjects);
    }

    @POST
    @Path("/movement/add")
    public Response addApplicatifITMovement(final ApplicatifIT applicatifIT, @Context HttpServletRequest request) throws IOException{

        if(applicatifIT == null || applicatifIT.getCode().isEmpty() || applicatifIT.getSubsidiary().isEmpty())
            return Response.status(422).entity(MessageResponse._422).build();

        ApplicatifITAO applicatifITAO = applicatifITRepo.saveForMVT(applicatifIT);
        return applicatifITAO.getID() == 0 ? Response.status(500).entity(MessageResponse._500).build() : Response.ok(ApplicatifIT.retrievesAOToModel(applicatifITAO)).build();
    }

    @POST
    @Path("/control/add")
    public Response addApplicatifITControl(final ApplicatifIT applicatifIT, @Context HttpServletRequest request) throws IOException{

        if(applicatifIT == null || applicatifIT.getCode().isEmpty() || applicatifIT.getSubsidiary().isEmpty())
            return Response.status(422).entity(MessageResponse._422).build();

        ApplicatifITAO applicatifITAO = applicatifITRepo.saveForCNTL(applicatifIT);
        return applicatifITAO.getID() == 0 ? Response.status(500).entity(MessageResponse._500).build() : Response.ok(ApplicatifIT.retrievesAOToModel(applicatifITAO)).build();
    }

    @GET
    @Path("/views/{subsidiary}/movement")
    public Response getApplicatifITMovement(final @PathParam("subsidiary") String subsidiary, @Context HttpServletRequest request) throws IOException{

        if(subsidiary==null || subsidiary.isEmpty())
                return Response.status(422).entity(MessageResponse._422).build();

        List<ApplicatifIT> applicatifITs = ApplicatifIT.retrievesAOsToModels(applicatifITRepo.retrievesEnabledMVTBySubsidiary(subsidiary));
        return applicatifITs == null || applicatifITs.size() == 0 ? Response.status(204).entity(MessageResponse._204).build() : Response.ok(applicatifITs).build();
    }

    @GET
    @Path("/lists/movement/{subsidiary}")
    public Response getListMovements(final @PathParam("subsidiary") String subsidiary, @Context HttpServletRequest request){
        return Response.ok(ApplicatifIT.retrievesListOption(applicatifITRepo.retrievesAllMVTBySubsidiary(subsidiary))).build();
    }

    @GET
    @Path("/views/{subsidiary}/control")
    public Response getApplicatifITControl(final @PathParam("subsidiary") String subsidiary, @Context HttpServletRequest request) throws IOException{

        if(subsidiary==null || subsidiary.isEmpty())
            return Response.status(422).entity(MessageResponse._422).build();

        List<ApplicatifIT> applicatifITs = ApplicatifIT.retrievesAOsToModels(applicatifITRepo.retrievesEnabledCNTLBySubsidiary(subsidiary));
        return applicatifITs == null || applicatifITs.size() == 0 ? Response.status(204).entity(MessageResponse._204).build() : Response.ok(applicatifITs).build();
    }

    @GET
    @Path("/lists/control/{subsidiary}")
    public Response getListControls(final @PathParam("subsidiary") String subsidiary, @Context HttpServletRequest request){
        return Response.ok(ApplicatifIT.retrievesListOption(applicatifITRepo.retrievesAllCNTLBySubsidiary(subsidiary))).build();
    }
}
