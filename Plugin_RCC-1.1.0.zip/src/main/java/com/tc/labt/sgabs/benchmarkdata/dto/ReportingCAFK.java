package com.tc.labt.sgabs.benchmarkdata.dto;

import java.io.Serializable;

public class ReportingCAFK implements Serializable {

    public Reporting reporting;
    public CheckAccount checkAccount;
}
