package com.tc.labt.sgabs.benchmarkdata.ao;

import net.java.ao.Entity;
import net.java.ao.ManyToMany;

public interface ReportingAO extends Entity {

	public String getCode();
	public void setCode(String code);

	public String getLib();
	public void setLib(String lib);

	public String getSubsidiary();
	public void setSubsidiary(String subsidiary);

	public boolean isActive();
	public void setActive(boolean active);

	@ManyToMany(value = ReportingCAFKAO.class)
	public CheckAccountAO[] getCheckAccounts();
}