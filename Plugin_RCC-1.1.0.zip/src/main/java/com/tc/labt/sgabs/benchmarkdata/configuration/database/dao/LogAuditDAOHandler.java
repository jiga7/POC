package com.tc.labt.sgabs.benchmarkdata.configuration.database.dao;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.tc.labt.sgabs.benchmarkdata.configuration.database.ao.LogAuditAO;
import com.tc.labt.sgabs.benchmarkdata.configuration.database.dto.LogAuditDTO;
import org.apache.poi.util.NotImplemented;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Date;

@Component
public class LogAuditDAOHandler implements IAOHandler<LogAuditAO, LogAuditDTO> {

    private final ActiveObjects ao;

    @Autowired
    public LogAuditDAOHandler(@ComponentImport ActiveObjects activeObjects){ this.ao = activeObjects; }

    @Override
    public LogAuditAO createAOEntity(LogAuditDTO logAuditDTO) throws Exception {
        if(logAuditDTO!=null)
            return null;
        LogAuditAO logAuditAO = this.ao.create(LogAuditAO.class);
        logAuditAO.setAuthor(logAuditDTO.getAuthor());
        logAuditAO.setKey(logAuditDTO.getKey());
        logAuditAO.setTable(logAuditDTO.getTable());
        logAuditAO.setChangeLog(logAuditDTO.getChangeLog());
        logAuditAO.setCreated(new Date());
        return logAuditAO;
    }

    @Override
    @NotImplemented
    public LogAuditAO updateAOEntity(LogAuditDTO logAuditDTO) throws Exception {
        return null;
    }

    @Override
    @NotImplemented
    public boolean deleteAOEntity(LogAuditAO logAuditAO) throws Exception {
        return false;
    }
}
