package com.tc.labt.sgabs.benchmarkdata.ao;

import net.java.ao.Entity;
import net.java.ao.ManyToMany;


public interface ContributorAO extends Entity {

	public String getUsername();
	public void setUsername(String username);

	public String getFullname();
	public void setFullname(String fullname);

	public String getSubsidiary();
	public void setSubsidiary(String subsidiary);

	@ManyToMany(value= ContributorCAFKAO.class)
	public CheckAccountAO[] getCheckAccounts();
}