package com.tc.labt.sgabs.benchmarkdata.service;

import javax.inject.Named;
import javax.inject.Inject;

import com.atlassian.plugin.spring.scanner.annotation.component.Scanned;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.atlassian.activeobjects.external.ActiveObjects;
import com.tc.labt.sgabs.benchmarkdata.ao.CheckAccountAO;
import com.tc.labt.sgabs.benchmarkdata.configuration.service.DatasourceConfigurationService;
import com.tc.labt.sgabs.benchmarkdata.dto.CheckAccount;
import com.tc.labt.sgabs.benchmarkdata.business.CheckAccountRepo;
import com.tc.labt.sgabs.benchmarkdata.utils.FileLoadedResponse;

import com.tc.labt.sgabs.benchmarkdata.utils.ManageFile;
import com.tc.labt.sgabs.benchmarkdata.utils.Util;

import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Scanned
@Named
public class ManageDataPCI {

    public static String RCC_FILE_TYPE = "RCC";

    // INDEX FIELDS PCI
    public static int KEY_INDEX = 2;
    public static int CHAP_INDEX = 3;
    public static int LIB_CHAP_INDEX = 4;
    public static int NCP_INDEX = 5;
    public static int LIB_NCP_INDEX = 6;
    public static int DEV_INDEX = 7;
    public static int LIB_DEV_INDEX = 8;
    public static int AGE_INDEX = 9;
    public static int ACCOUNT_STATUS_INDEX = 10;
    public static int CRP_INDEX = 11;
    public static int SBI_INDEX = 12;
    public static int MAJ_BI_INDEX = 13;

    public static List<String> HEADERS = Arrays.asList("N°", "ID", "CHAP", "LIB_CHA", "NCP", "LIB_NCP",	"DEV", "SDEV", "AGE",
            "ETA", "CRP",	"SBI",	"MAJ_BI", "DT_MAJ",	"DESC",	"SSBL",	"OPE",	"DIR_PROP",
            "PROP",	"CTBTR","DEL_APU",	"TYP_MVT",	"APP_MVT",	"RISQ",	"CTRL",	"FQ_CTEL",	"RPRT");

    @ComponentImport
    private final ActiveObjects activeObjects;
    private final CheckAccountRepo checkAccountRepo;

    @Inject
    public ManageDataPCI(ActiveObjects activeObjects, DatasourceConfigurationService datasourceConfigurationService){
        super();
        this.activeObjects = activeObjects;
        checkAccountRepo = new CheckAccountRepo(activeObjects, datasourceConfigurationService);
    }

    public static String getValue(Row row, int index) {
        return row.getCell(index) !=null && !row.getCell(index).getStringCellValue().equals("?")
                ? row.getCell(index).getStringCellValue()
                : "";
    }

    public List<FileLoadedResponse> loadAllDataPCIToJira(){
        List<FileLoadedResponse> filesLoadedResponse = new ArrayList<>();
        List<File> allFilesGetted = ManageFile.retrieveFileIfExist(RCC_FILE_TYPE);
        if(allFilesGetted != null && allFilesGetted.size()>0)
            filesLoadedResponse = allFilesGetted.stream().parallel().map(file -> loadDataPCIToJira(file)).collect(Collectors.toList());
        return filesLoadedResponse;
    }

    public FileLoadedResponse loadDataPCIToJira(File rccFile){
        String subsidiary = "SGBS";//ManageFile.getSubsidiaryFromFilename(rccFile.getName());
        FileLoadedResponse fileLoadedResponse = new FileLoadedResponse(subsidiary);
        if(rccFile!= null && subsidiary != null) {
            // Open file && workbook
            FileInputStream inputStream = null;
            try {
                inputStream = new FileInputStream(rccFile);
                Workbook workbook = new XSSFWorkbook(inputStream);
                Sheet sheet = workbook.getSheetAt(0);

                sheet.forEach(row -> {
                    fileLoadedResponse.setCount(1);
                    CheckAccount checkAccount = null;
                    if(getValue(row, KEY_INDEX).length()>12)
                        checkAccount = new CheckAccount(getValue(row, KEY_INDEX),
                                getValue(row, CHAP_INDEX), getValue(row, LIB_CHAP_INDEX),
                                getValue(row, NCP_INDEX), getValue(row, LIB_NCP_INDEX),
                                getValue(row, DEV_INDEX), getValue(row, LIB_DEV_INDEX),
                                getValue(row, AGE_INDEX),
                                getValue(row, ACCOUNT_STATUS_INDEX), getValue(row, CRP_INDEX), getValue(row, SBI_INDEX),
                                subsidiary);
                    if(checkAccount!=null && (checkAccount.getAccountStatus()==null || checkAccount.getAccountStatus().isEmpty() || checkAccount.getAccountStatus().equals("F")))
                        fileLoadedResponse.setAccountClosed(1);
                    else if(checkAccount!=null && checkAccount.validPCI()){
                        //CheckAccountAO checkAccountAO = checkAccountRepo.savePCI(checkAccount);
                        System.err.println(checkAccount.getKey());
                        fileLoadedResponse.setAdded(1);
                    }else
                        fileLoadedResponse.setFailed(1);
                });
                // Close workbokk && file
                workbook.close();
                inputStream.close();
            } catch (FileNotFoundException e) {
                // log error
            } catch (IOException e) {
                // log error
            }
        }
        return fileLoadedResponse;
    }

    public boolean exportDataPCI(String subsidiary) throws IOException {

        XSSFWorkbook workbook = new XSSFWorkbook();
        XSSFSheet sheet = workbook.createSheet(subsidiary.toUpperCase());

        List<CheckAccountAO> checkAccounts =  checkAccountRepo.retrievesAllBySubsidiary(subsidiary.toUpperCase());

        if(checkAccounts.size()<1)
            return false;

        // HEADER
        Row header = sheet.createRow(0);
        Util.forEachWithIndex(HEADERS, (i, title) ->{
            header.createCell(i, CellType.STRING).setCellValue(title);
        });
        // BODY
        Util.forEachWithIndex(checkAccounts, (i, checkAccount) -> {
            Row row = sheet.createRow(i+1);
            int indexCell = 0;
            row.createCell(indexCell++).setCellValue(i+1);
            row.createCell(indexCell++).setCellValue(checkAccount.getKey());
            row.createCell(indexCell++).setCellValue(checkAccount.getChap());
            row.createCell(indexCell++).setCellValue(checkAccount.getLib_chap());
            row.createCell(indexCell++).setCellValue(checkAccount.getNcp());
            row.createCell(indexCell++).setCellValue(checkAccount.getInti());
            row.createCell(indexCell++).setCellValue(checkAccount.getDev());
            row.createCell(indexCell++).setCellValue(checkAccount.getLib_dev());
            row.createCell(indexCell++).setCellValue(checkAccount.getAge());
            row.createCell(indexCell++).setCellValue(checkAccount.getAccount_status());
            row.createCell(indexCell++).setCellValue(checkAccount.getSoul());
            row.createCell(indexCell++).setCellValue(checkAccount.getSbi());
            row.createCell(indexCell++).setCellValue("?");
            row.createCell(indexCell++).setCellValue(checkAccount.getDdmHorsPci()==null? "?" : checkAccount.getDdmHorsPci().toString());
            row.createCell(indexCell++).setCellValue(checkAccount.getDesc_chap_cpt()==null? "?" : checkAccount.getDesc_chap_cpt());
            row.createCell(indexCell++).setCellValue(checkAccount.getSensible()==null? "?" : checkAccount.getSensible());
            row.createCell(indexCell++).setCellValue("?");// liste opération
            row.createCell(indexCell++).setCellValue("?");
            row.createCell(indexCell++).setCellValue("?");
            row.createCell(indexCell++).setCellValue("?");
            row.createCell(indexCell++).setCellValue(checkAccount.getDelaiSuspens());
            row.createCell(indexCell++).setCellValue(checkAccount.getTypMvt()==null? "?" : checkAccount.getTypMvt());
            row.createCell(indexCell++).setCellValue("?"); // APP_MVT
            row.createCell(indexCell++).setCellValue(checkAccount.getRiskCompt()==null? "?" : checkAccount.getRiskCompt());
            row.createCell(indexCell++).setCellValue(checkAccount.getMethodControl()==null? "?" : checkAccount.getMethodControl().getCode()); // Methode de control
            row.createCell(indexCell++).setCellValue(checkAccount.getFrequency()==null || checkAccount.getFrequency().length()<1? "?" : checkAccount.getFrequency().substring(0, 1).toUpperCase());
            row.createCell(indexCell++).setCellValue("?"); // Liste des reportings
        });

        try(FileOutputStream fous = new FileOutputStream(ManageFile.getNameFileToExportByType("SEN", RCC_FILE_TYPE))){
            workbook.write(fous);
            return true;
        }catch (IOException e){
            return false;
        }
    }
}
