package com.tc.labt.sgabs.benchmarkdata.configuration.database;

public enum DatabaseType {

    POSTGRESQL("PostgreSQL"), MYSQL("MySQL"), ORACLE("Oracle"), SQLSERVER("Microsoft SQL Server");

    private final String value;

    DatabaseType (String value) {this.value = value;}

    public String getValue(){return this.value;}
}
