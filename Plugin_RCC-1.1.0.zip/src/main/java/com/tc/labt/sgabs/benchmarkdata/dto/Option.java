package com.tc.labt.sgabs.benchmarkdata.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlElement;

import java.io.Serializable;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class Option implements Serializable {

    @XmlElement
    private String label;
    @XmlElement
    private String value;

    public Option() {
        super();
    }

    public Option(String label, String value) {
        this();
        this.label = label;
        this.value = value;
    }

    public Option(int id, String label, String value) {
        this(label +" ("+value+")", String.valueOf(id));
    }

    public Option(String id, String label, String value) {
        this(label +" ("+value+")", value);
    }


    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
