package com.tc.labt.sgabs.benchmarkdata.business;

import com.tc.labt.sgabs.benchmarkdata.ao.FileLoadedAuditAO;
import com.tc.labt.sgabs.benchmarkdata.dto.FileLoadedAudit;


import com.atlassian.activeobjects.tx.Transactional;

import java.util.List;

@Transactional
public interface IFileLoadedAuditRepo {

    FileLoadedAuditAO save(FileLoadedAudit fileLoadedAudit);

    List<FileLoadedAuditAO> retrievesAll();

    List<FileLoadedAuditAO> retrievesAll(int page, int size);

    List<FileLoadedAuditAO> retrievesBySubsidiary(String subsidiary);

    List<FileLoadedAuditAO> retrievesBySubsidiary(String subsidiary, int page, int size);

}
