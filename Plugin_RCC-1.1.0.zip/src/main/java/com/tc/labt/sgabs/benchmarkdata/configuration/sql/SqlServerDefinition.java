package com.tc.labt.sgabs.benchmarkdata.configuration.sql;

import com.tc.labt.sgabs.benchmarkdata.configuration.database.DatabaseType;
import com.tc.labt.sgabs.benchmarkdata.configuration.database.dto.DatabaseDTO;

public class SqlServerDefinition extends AbstractDefinition{

    public SqlServerDefinition() {
        super("jdbc:sqlserver://", DatabaseType.SQLSERVER, "com.microsoft.sqlserver.jdbc.SQLServerDriver");
    }

    @Override
    public String buildUrlFromConfiguration(DatabaseDTO database) {
        return getPrefixUrl() + database.getHost() + ":" + database.getPort() + ";databaseName=" + database.getName();
    }

    @Override
    public boolean hasSchemaSupport() {
        return true;
    }
}
