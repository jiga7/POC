package com.tc.labt.sgabs.benchmarkdata.configuration.database.dao;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.tc.labt.sgabs.benchmarkdata.configuration.database.ao.DatasourceAO;
import com.tc.labt.sgabs.benchmarkdata.configuration.database.dto.DatasourceDTO;
import com.tc.labt.sgabs.benchmarkdata.configuration.database.dto.ErrorOrResult;
import com.tc.labt.sgabs.benchmarkdata.utils.MessageError;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Date;

@Component
public class DatasourceDAOHandler implements IAOHandler<DatasourceAO, DatasourceDTO> {

    private final ActiveObjects ao;

    @Autowired
    public DatasourceDAOHandler(@ComponentImport ActiveObjects activeObjects){ this.ao = activeObjects; }

    @Override
    public DatasourceAO createAOEntity(DatasourceDTO datasourceDTO) throws Exception {

        DatasourceAO[] datasourcesExists = this.ao.find(DatasourceAO.class, "NAME = ?", datasourceDTO.getName());
        if(datasourcesExists.length >= 1)
            if(datasourcesExists[0].getID() == datasourceDTO.getId())
                return this.updateAOEntity(datasourceDTO);
            else
               throw MessageError.build(MessageError.ALREADY_EXIST);
        DatasourceAO datasourceAO = this.ao.create(DatasourceAO.class);
        populateEntity(datasourceAO, datasourceDTO, true);
        datasourceAO.save();
        return datasourceAO;
    }

    @Override
    public DatasourceAO updateAOEntity(DatasourceDTO datasourceDTO) throws Exception {
        ErrorOrResult<DatasourceAO> result = this.ao.executeInTransaction(() -> {
           try {
               DatasourceAO datasourceAO = this.ao.get(DatasourceAO.class, datasourceDTO.getId());
               if(datasourceAO == null)
                   return ErrorOrResult.error(MessageError.build(MessageError.NOT_EXIST));
               populateEntity(datasourceAO, datasourceDTO, false);
               datasourceAO.save();
               return ErrorOrResult.ok(datasourceAO);
           }catch (Exception e){
               return ErrorOrResult.error(e);
           }
        });
        if (result.exception != null)
            throw result.exception;
        return result.result;
    }

    @Override
    public boolean deleteAOEntity(DatasourceAO datasourceAO) throws Exception {
        ErrorOrResult<DatasourceAO> result = this.ao.executeInTransaction(() -> {
            if(datasourceAO == null)
                return ErrorOrResult.error(MessageError.build(MessageError.NOT_EXIST));
            try {
                this.ao.delete(datasourceAO);
            }catch (Exception e) {
                return ErrorOrResult.error(e);
            }
            return ErrorOrResult.ok(datasourceAO);
        });
        if(result.exception!=null)
            throw result.exception;
        return false;
    }

    private void populateEntity(DatasourceAO datasourceAO, DatasourceDTO datasourceDTO, boolean created){
        datasourceAO.setName(datasourceDTO.getName());
        datasourceAO.setType(datasourceDTO.getType());
        if(created){
            datasourceAO.setCreated(new Date());
        }else{
            datasourceAO.setLastUpdated(new Date());
        }
    }
}
