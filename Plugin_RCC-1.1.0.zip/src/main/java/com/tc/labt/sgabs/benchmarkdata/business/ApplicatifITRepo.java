package com.tc.labt.sgabs.benchmarkdata.business;

import com.tc.labt.sgabs.benchmarkdata.ao.ApplicatifITAO;
import com.tc.labt.sgabs.benchmarkdata.dto.ApplicatifIT;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.plugin.spring.scanner.annotation.component.Scanned;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;

import javax.inject.Inject;
import javax.inject.Named;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Scanned
@Named
public class ApplicatifITRepo implements IApplicatifITRepo{

    @ComponentImport
    private ActiveObjects activeObjects;

    public ApplicatifITRepo(){
        super();
    }

    @Inject
    public ApplicatifITRepo(ActiveObjects activeObjects){
        this();
        this.activeObjects = activeObjects;
    }

    @Override
    public ApplicatifITAO saveForCNTL(ApplicatifIT applicatifIT) {

        if(applicatifIT == null)
            return null;
        applicatifIT.setTyp(ApplicatifIT.typCNTL);
        return save(applicatifIT);
    }

    @Override
    public ApplicatifITAO saveForMVT(ApplicatifIT applicatifIT) {

        if(applicatifIT == null)
            return null;
        applicatifIT.setTyp(ApplicatifIT.typMVT);
        return save(applicatifIT);
    }

    private ApplicatifITAO save(ApplicatifIT applicatifIT){

        if(activeObjects.find(ApplicatifITAO.class, "CODE = ? AND SUBSIDIARY = ? AND TYP = ?", applicatifIT.getCode(), applicatifIT.getSubsidiary(), applicatifIT.getTyp()).length==0){
            ApplicatifITAO applicatifITAO = activeObjects.create(ApplicatifITAO.class);
            applicatifITAO.setCode(applicatifIT.getCode());
            applicatifITAO.setLib(applicatifIT.getLib());
            applicatifITAO.setSubsidiary(applicatifIT.getSubsidiary());
            applicatifITAO.setTyp(applicatifIT.getTyp());
            applicatifITAO.setActive(Boolean.TRUE);
            applicatifITAO.save();
            return applicatifITAO;
        }else {
            // logs
        }
        return null;
    }

    @Override
    public List<ApplicatifITAO> retrievesAllCNTLBySubsidiary(String subsidiary) {
    List<ApplicatifITAO> applicatifITAOs = Arrays.asList(activeObjects.find(ApplicatifITAO.class, "TYP = ? AND SUBSIDIARY = ?", ApplicatifIT.typCNTL, subsidiary));
        return applicatifITAOs;
    }

    @Override
    public List<ApplicatifITAO> retrievesEnabledCNTLBySubsidiary(String subsidiary) {
        List<ApplicatifITAO> applicatifITAOs = Arrays.asList(activeObjects.find(ApplicatifITAO.class, "TYP = ? AND SUBSIDIARY = ? AND ACTIVE = ?", ApplicatifIT.typCNTL, subsidiary, Boolean.TRUE));
        return applicatifITAOs;
    }

    @Override
    public List<ApplicatifITAO> retrievesAllMVTBySubsidiary(String subsidiary) {
        List<ApplicatifITAO> applicatifITAOs = Arrays.asList(activeObjects.find(ApplicatifITAO.class, "TYP = ? AND SUBSIDIARY = ?", ApplicatifIT.typMVT, subsidiary));
        return applicatifITAOs;
    }

    @Override
    public List<ApplicatifITAO> retrievesEnabledMVTBySubsidiary(String subsidiary) {
        List<ApplicatifITAO> applicatifITAOs = Arrays.asList(activeObjects.find(ApplicatifITAO.class, "TYP = ? AND SUBSIDIARY = ? AND ACTIVE = ?", ApplicatifIT.typMVT, subsidiary, Boolean.TRUE));
        return applicatifITAOs;
    }

    @Override
    public ApplicatifITAO enableOrDisable(ApplicatifIT applicatifIT) {
        return null;
    }

    @Override
    public List<ApplicatifITAO> retrievesAllByIds(List<Integer> ids) {

        if(ids.size()<=0)
            return null;

        String applicatifs_ID_Parameters = Collections.nCopies(ids.size(), "?").stream().collect(Collectors.joining(","));
        List<ApplicatifITAO> applicatifITAOs = Arrays.asList(activeObjects.find(ApplicatifITAO.class, "ID IN ("+applicatifs_ID_Parameters+")", ids.toArray()));
        return applicatifITAOs;
    }
}
