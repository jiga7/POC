package com.tc.labt.sgabs.benchmarkdata.business;

import com.tc.labt.sgabs.benchmarkdata.ao.CheckAccountAO;
import com.tc.labt.sgabs.benchmarkdata.ao.ContributorAO;
import com.tc.labt.sgabs.benchmarkdata.ao.ContributorCAFKAO;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.plugin.spring.scanner.annotation.component.Scanned;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.tc.labt.sgabs.benchmarkdata.configuration.service.DatasourceConfigurationService;

import javax.inject.Inject;
import javax.inject.Named;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@Scanned
@Named
public class ContributorCAFKRepo implements IContributorCAFKRepo{

    @ComponentImport
    private ActiveObjects activeObjects;

    private final ContributorRepo contributorRepo;
    private final CheckAccountRepo checkAccountRepo;

    //public ContributorCAFKRepo() { super(); }

    @Inject
    public ContributorCAFKRepo(ActiveObjects activeObjects, DatasourceConfigurationService datasourceConfigurationService) {
        super(); // this();
        this.activeObjects = activeObjects;
        this.contributorRepo = new ContributorRepo(activeObjects);
        this.checkAccountRepo = new CheckAccountRepo(activeObjects, datasourceConfigurationService);
    }

    @Override
    public ContributorCAFKAO save(ContributorAO contributorAO, CheckAccountAO checkAccountAO) {

        if(contributorAO.getID() == 0 || checkAccountAO.getKey().isEmpty())
            return null;

        ContributorCAFKAO[] contributorCAFKAOs = activeObjects.find(ContributorCAFKAO.class, "CONTRIBUTOR_AO_ID = ? AND CHECK_ACCOUNT_AO_ID = ?", contributorAO.getID(), checkAccountAO.getKey());
        if(contributorCAFKAOs.length == 0){
            ContributorCAFKAO contributorCAFKAO = activeObjects.create(ContributorCAFKAO.class);
            contributorCAFKAO.setContributorAo(contributorAO);
            contributorCAFKAO.setCheckAccountAo(checkAccountAO);
            contributorCAFKAO.setAddedAt(new Date());
            contributorCAFKAO.save();
            return contributorCAFKAO;
        }else{
            return contributorCAFKAOs[0];
        }
    }

    @Override
    public List<ContributorCAFKAO> save(List<ContributorAO> contributorAOs, CheckAccountAO checkAccountAO) {

        if(contributorAOs.size() <= 0)
            return null;

        List<ContributorCAFKAO> contributorCAFKAOs = new ArrayList<>();
        contributorAOs.parallelStream().forEach(contributorAO -> contributorCAFKAOs.add(save(contributorAO, checkAccountAO)));
        return contributorCAFKAOs;
    }

    @Override
    public List<ContributorCAFKAO> saveAll(List<Integer> contributor_IDs, CheckAccountAO checkAccountAO) {

        List<ContributorCAFKAO> contributorCAFKAOs = retrieveByCheckAccountID(checkAccountAO.getKey())
                                    .stream().parallel()
                                    .filter(contributorCAFKAO -> !contributor_IDs.contains(contributorCAFKAO.getContributorAo().getID()))
                                    .collect(Collectors.toList());
        deleteAll(contributorCAFKAOs);
        return contributorCAFKAOs.size()<=0? null : this.save(contributorRepo.retrievesAllByIds(contributor_IDs), checkAccountAO);
    }

    @Override
    public List<ContributorCAFKAO> retrieveByCheckAccountID(String checkAccountID) {

        if(checkAccountID.isEmpty())
            return null;
        return Arrays.asList(activeObjects.find(ContributorCAFKAO.class, "CHECK_ACCOUNT_AO_ID = ?", checkAccountID));
    }

    @Override
    public List<ContributorCAFKAO> deleteAll(List<ContributorCAFKAO> contributorCAFKAOs) {
        contributorCAFKAOs.parallelStream().forEach( contributorCAFKAO -> activeObjects.delete(contributorCAFKAO));
        return contributorCAFKAOs;
    }
}
