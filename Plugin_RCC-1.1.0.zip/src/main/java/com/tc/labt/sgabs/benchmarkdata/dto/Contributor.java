package com.tc.labt.sgabs.benchmarkdata.dto;

import com.tc.labt.sgabs.benchmarkdata.ao.ContributorAO;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlElement;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class Contributor implements Serializable {

	private int id;
	@XmlElement
	private String username;
	@XmlElement
	private String fullname;
	@XmlElement
	private String subsidiary;

	private CheckAccount[] checkAccounts;

	public Contributor() {
		super();
	}

	public Contributor(String username, String fullname, String subsidiary) {
		this();
		this.username = username;
		this.fullname = fullname;
		this.subsidiary = subsidiary;
	}

	public Contributor(int id, String username, String fullname, String subsidiary, CheckAccount[] checkAccounts) {
		this(username, fullname, subsidiary);
		this.id = id;
		this.checkAccounts = checkAccounts;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getFullname() {
		return fullname;
	}

	public void setFullname(String fullname) {
		this.fullname = fullname;
	}

	public String getSubsidiary() {
		return subsidiary;
	}

	public void setSubsidiary(String subsidiary) {
		this.subsidiary = subsidiary;
	}

	public CheckAccount[] getCheckAccounts() {
		return checkAccounts;
	}

	public void setCheckAccounts(CheckAccount[] checkAccounts) {
		this.checkAccounts = checkAccounts;
	}

	public static Contributor retrievesAOToModel(ContributorAO contributorAO){
		return contributorAO == null || contributorAO.getID() == 0 ? null : new Contributor(contributorAO.getID(), contributorAO.getUsername(), contributorAO.getFullname(), contributorAO.getSubsidiary(), null /*checkAccounts*/);
	}

	public static List<Contributor> retrievesAOsToModels(ContributorAO[] contributorAOs){
		return retrievesAOsToModels(Arrays.asList(contributorAOs));
	}

	public static List<Contributor> retrievesAOsToModels(List<ContributorAO> contributorAOs){
		List<Contributor> contributors = new ArrayList<>();
		contributorAOs.forEach(contributorAO ->  contributors.add(retrievesAOToModel(contributorAO)));
		return contributors;
	}
}