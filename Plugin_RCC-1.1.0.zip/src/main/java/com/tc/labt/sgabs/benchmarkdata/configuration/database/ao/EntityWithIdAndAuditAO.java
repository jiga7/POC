package com.tc.labt.sgabs.benchmarkdata.configuration.database.ao;

import net.java.ao.Entity;
import net.java.ao.Polymorphic;

import java.util.Date;

@Polymorphic
public interface EntityWithIdAndAuditAO extends Entity {

    public String getCreator();
    public void setCreator(String creator);

    public String getUpdatedBy();
    public void setUpdatedBy(String updatedBy);

    public Date getCreated();
    public void setCreated(Date created);

    public Date getLastUpdated();
    public void setLastUpdated(Date updated);
}
