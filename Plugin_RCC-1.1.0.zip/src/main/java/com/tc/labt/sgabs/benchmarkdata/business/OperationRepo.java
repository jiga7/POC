package com.tc.labt.sgabs.benchmarkdata.business;

import com.tc.labt.sgabs.benchmarkdata.ao.OperationAO;
import com.tc.labt.sgabs.benchmarkdata.dto.Operation;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.plugin.spring.scanner.annotation.component.Scanned;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;

import javax.inject.Named;
import javax.inject.Inject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Scanned
@Named
public class OperationRepo implements IOperationRepo {

    @ComponentImport
    private ActiveObjects activeObjects;

    public OperationRepo(){
        super();
    }

    @Inject
    public OperationRepo(ActiveObjects activeObjects){
        super();
        this.activeObjects = activeObjects;
    }

    @Override
    public OperationAO save(final Operation operation) {

        if(operation == null)
            return null;

        OperationAO[] operationAOs = activeObjects.find(OperationAO.class, "OPE = ?", operation.getOpe());
        if(operationAOs.length > 0)
            return operationAOs[0];

        final OperationAO operationAO = activeObjects.create(OperationAO.class);
        operationAO.setOpe(operation.getOpe());
        operationAO.setLib(operation.getLib());
        operationAO.setSubsidiary(operation.getSubsidiary());
        operationAO.setActive(Boolean.TRUE);
        operationAO.save();
        return operationAO;
    }

    @Override
    public List<OperationAO> saveOrRetrievesAll(List<Operation> operations){

        List<OperationAO> operationAOs = new ArrayList<>();
        operations.parallelStream().forEach(operation -> operationAOs.add(save(operation)));
        return operationAOs;
    }

    @Override
    public OperationAO retrievesByCode(String code) {

        OperationAO[] operationAOs = activeObjects.find(OperationAO.class, "OPE = ?", code);
        return operationAOs.length==0? null : operationAOs[0];
    }

    @Override
    public List<OperationAO> retrievesAll() {
        List<OperationAO> operationAOs = Arrays.asList(activeObjects.find(OperationAO.class));
        return operationAOs;
    }

    @Override
    public List<OperationAO> retrievesEnabled() {
        List<OperationAO> operationAOs = Arrays.asList(activeObjects.find(OperationAO.class, "ACTIVE = ?", Boolean.TRUE));
        return operationAOs;
    }

    @Override
    public List<OperationAO> retrievesBySubsidiary(String subsidiary) {
        List<OperationAO> operationAOs = Arrays.asList(activeObjects.find(OperationAO.class, "SUBSIDIARY = ?", subsidiary));
        return operationAOs;
    }

    @Override
    public List<OperationAO> retrievesEnabledBySubsidiary(String subsidiary) {
        List<OperationAO> operationAOs = Arrays.asList(activeObjects.find(OperationAO.class, "SUBSIDIARY = ? AND ACTIVE = ?", subsidiary, Boolean.TRUE));
        return operationAOs;
    }

    @Override
    public List<OperationAO> retrievesAllByIds(List<Integer> ids) {

        if(ids.size() <= 0)
            return null;

        String operation_ID_Parameters = Collections.nCopies(ids.size(), "?").stream().collect(Collectors.joining(","));
        List<OperationAO> operationAOs = Arrays.asList(activeObjects.find(OperationAO.class, "ID IN ("+operation_ID_Parameters+")", ids.toArray()));
        return operationAOs;
    }
}
