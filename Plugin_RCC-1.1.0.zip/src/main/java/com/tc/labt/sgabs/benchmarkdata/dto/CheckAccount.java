package com.tc.labt.sgabs.benchmarkdata.dto;

import com.tc.labt.sgabs.benchmarkdata.ao.CheckAccountAO;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlElement;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class CheckAccount implements Serializable {
	@XmlElement
	private String key;
	@XmlElement
	private String chap;
	@XmlElement
	private String libChap;
	@XmlElement
	private String ncp;
	@XmlElement
	private String inti;
	@XmlElement
	private String dev;
	@XmlElement
	private String libDev;
	@XmlElement
	private String age;
	@XmlElement
	private String accountStatus;
	@XmlElement
	private String soul;
	@XmlElement
	private String sbi;
	@XmlElement
	private String descChapCpt;
	@XmlElement
	private String sensible;
	private String proprio;
	private String intiProprio;
	private int delaiSuspens;
	private String typMvt;
	private String riskCompt;
	private String entity;
	private String officer;
	private String officerFullname;
	private String officerBak;
	private String officerBakFullname;
	private int duration;
	private String validor1;
	private String validor1Fullname;
	private String validor1Bak;
	private String validor1BakFullname;
	private int durationValid1;
	private String validor2;
	private String validor2Fullname;
	private String validor2Bak;
	private String validor2BakFullname;
	private int durationValid2;
	private String orig;
	private String frequency;
	private Date ddmPci;
	private Date ddmHorsPci;
	private Date created;
	private String createdBy;
	private String updatedBy;
	private String subsidiary;
	private String status;

	private String flag;

	@XmlElement
	private MethodControl methodControl;

	private List<AdditionalField> additionalFields;
	private List<LogAudit> logAudits;
	private List<Operation> operations;
	private List<Contributor> contributors;
	private List<ApplicatifIT> applicatifIts;
	private List<Reporting> reportings;

	public CheckAccount() {
	}

	public CheckAccount(String key, String chap, String libChap, String ncp, String inti, String dev, String libDev, String age, String accountStatus, String soul, String sbi, String subsidiary) {
		this.key = key;
		this.chap = chap;
		this.libChap = libChap;
		this.ncp = ncp;
		this.inti = inti;
		this.dev = dev;
		this.libDev = libDev;
		this.age = age;
		this.accountStatus = accountStatus;
		this.soul = soul;
		this.sbi = sbi;
		this.subsidiary = subsidiary;
	}

	public CheckAccount(String key, String descChapCpt, String sensible, String proprio, String intiProprio, int delaiSuspens, String typMvt, String riskCompt, String entity, String officer, String officerFullname, String officerBak, String officerBakFullname, int duration, String validor1, String validor1Fullname, String validor1Bak, String validor1BakFullname, int durationValid1, String validor2, String validor2Fullname, String validor2Bak, String validor2BakFullname, int durationValid2, String orig, String frequency, Date ddmPci, Date ddmHorsPci, Date created, String createdBy, String updatedBy, String subsidiary, String status) {
		this.key = key;
		this.descChapCpt = descChapCpt;
		this.sensible = sensible;
		this.proprio = proprio;
		this.intiProprio = intiProprio;
		this.delaiSuspens = delaiSuspens;
		this.typMvt = typMvt;
		this.riskCompt = riskCompt;
		this.entity = entity;
		this.officer = officer;
		this.officerFullname = officerFullname;
		this.officerBak = officerBak;
		this.officerBakFullname = officerBakFullname;
		this.duration = duration;
		this.validor1 = validor1;
		this.validor1Fullname = validor1Fullname;
		this.validor1Bak = validor1Bak;
		this.validor1BakFullname = validor1BakFullname;
		this.durationValid1 = durationValid1;
		this.validor2 = validor2;
		this.validor2Fullname = validor2Fullname;
		this.validor2Bak = validor2Bak;
		this.validor2BakFullname = validor2BakFullname;
		this.durationValid2 = durationValid2;
		this.orig = orig;
		this.frequency = frequency;
		this.ddmPci = ddmPci;
		this.ddmHorsPci = ddmHorsPci;
		this.created = created;
		this.createdBy = createdBy;
		this.updatedBy = updatedBy;
		this.subsidiary = subsidiary;
		this.status = status;
	}

	public CheckAccount(String key, String chap, String libChap, String ncp, String inti,
						String dev, String libDev, String age, String accountStatus,
						String soul, String sbi, String descChapCpt, String sensible,
						String proprio, String intiProprio, int delaiSuspens, String typMvt,
						String riskCompt, String entity, String officer, String officerFullname,
						String officerBak, String officerBakFullname, int duration, String validor1,
						String validor1Fullname, String validor1Bak, String validor1BakFullname,
						int durationValid1, String validor2, String validor2Fullname, String validor2Bak,
						String validor2BakFullname, int durationValid2, String orig, String frequency,
						Date ddmPci, Date ddmHorsPci, Date created, String createdBy, String updatedBy,
						String subsidiary, String status, MethodControl methodControl,
						List<AdditionalField> additionalFields, List<Operation> operations,
						List<Contributor> contributors, List<ApplicatifIT> applicatifIts, List<Reporting> reportings) {

		this(key, chap, libChap, ncp, inti, dev, libDev, age, accountStatus, soul, sbi,subsidiary);
		this.descChapCpt = descChapCpt;
		this.sensible = sensible;
		this.proprio = proprio;
		this.intiProprio = intiProprio;
		this.delaiSuspens = delaiSuspens;
		this.typMvt = typMvt;
		this.riskCompt = riskCompt;
		this.entity = entity;
		this.officer = officer;
		this.officerFullname = officerFullname;
		this.officerBak = officerBak;
		this.officerBakFullname = officerBakFullname;
		this.duration = duration;
		this.validor1 = validor1;
		this.validor1Fullname = validor1Fullname;
		this.validor1Bak = validor1Bak;
		this.validor1BakFullname = validor1BakFullname;
		this.durationValid1 = durationValid1;
		this.validor2 = validor2;
		this.validor2Fullname = validor2Fullname;
		this.validor2Bak = validor2Bak;
		this.validor2BakFullname = validor2BakFullname;
		this.durationValid2 = durationValid2;
		this.orig = orig;
		this.frequency = frequency;
		this.ddmPci = ddmPci;
		this.ddmHorsPci = ddmHorsPci;
		this.created = created;
		this.createdBy = createdBy;
		this.updatedBy = updatedBy;
		this.subsidiary = subsidiary;
		this.status = status;
		this.methodControl = methodControl;
		this.additionalFields = additionalFields;
		this.operations = operations;
		this.contributors = contributors;
		this.applicatifIts = applicatifIts;
		this.reportings = reportings;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getChap() {
		return chap;
	}

	public void setChap(String chap) {
		this.chap = chap;
	}

	public String getLibChap() {
		return libChap;
	}

	public void setLibChap(String libChap) {
		this.libChap = libChap;
	}

	public String getNcp() {
		return ncp;
	}

	public void setNcp(String ncp) {
		this.ncp = ncp;
	}

	public String getInti() {
		return inti;
	}

	public void setInti(String inti) {
		this.inti = inti;
	}

	public String getDev() {
		return dev;
	}

	public void setDev(String dev) {
		this.dev = dev;
	}

	public String getLibDev() {
		return libDev;
	}

	public void setLibDev(String libDev) {
		this.libDev = libDev;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public String getAccountStatus() {
		return accountStatus;
	}

	public void setAccountStatus(String accountStatus) {
		this.accountStatus = accountStatus;
	}

	public String getSoul() {
		return soul;
	}

	public void setSoul(String soul) {
		this.soul = soul;
	}

	public String getSbi() {
		return sbi;
	}

	public void setSbi(String sbi) {
		this.sbi = sbi;
	}

	public String getDescChapCpt() {
		return descChapCpt;
	}

	public void setDescChapCpt(String descChapCpt) {
		this.descChapCpt = descChapCpt;
	}

	public String getSensible() {
		return sensible;
	}

	public void setSensible(String sensible) {
		this.sensible = sensible;
	}

	public String getProprio() {
		return proprio;
	}

	public void setProprio(String proprio) {
		this.proprio = proprio;
	}

	public String getIntiPrio() {
		return intiProprio;
	}

	public void setIntiProprio(String intiProprio) {
		this.intiProprio = intiProprio;
	}

	public int getDelaiSuspens() {
		return delaiSuspens;
	}

	public void setDelaiSuspens(int delaiSuspens) {
		this.delaiSuspens = delaiSuspens;
	}

	public String getTypMvt() {
		return typMvt;
	}

	public void setTypMvt(String typMvt) {
		this.typMvt = typMvt;
	}

	public String getRiskCompt() {
		return riskCompt;
	}

	public void setRiskCompt(String riskCompt) {
		this.riskCompt = riskCompt;
	}

	public String getEntity() {
		return entity;
	}

	public void setEntity(String entity) {
		this.entity = entity;
	}

	public String getOfficer() {
		return officer;
	}

	public void setOfficer(String officer) {
		this.officer = officer;
	}

	public String getOfficerFullname() {
		return officerFullname;
	}

	public void setOfficerFullname(String officerFullname) {
		this.officerFullname = officerFullname;
	}

	public String getOfficerBak() {
		return officerBak;
	}

	public void setOfficerBak(String officerBak) {
		this.officerBak = officerBak;
	}

	public String getOfficerBakFullname() {
		return officerBakFullname;
	}

	public void setOfficerBakFullname(String officerBakFullname) {
		this.officerBakFullname = officerBakFullname;
	}

	public int getDuration() {
		return duration;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}

	public String getValidor1() {
		return validor1;
	}

	public void setValidor1(String validor1) {
		this.validor1 = validor1;
	}

	public String getValidor1Fullname() {
		return validor1Fullname;
	}

	public void setValidor1Fullname(String validor1Fullname) {
		this.validor1Fullname = validor1Fullname;
	}

	public String getValidor1Bak() {
		return validor1Bak;
	}

	public void setValidor1Bak(String validor1Bak) {
		this.validor1Bak = validor1Bak;
	}

	public String getValidor1BakFullname() {
		return validor1BakFullname;
	}

	public void setValidor1BakFullname(String validor1BakFullname) {
		this.validor1BakFullname = validor1BakFullname;
	}

	public int getDurationValid1() {
		return durationValid1;
	}

	public void setDurationValid1(int durationValid1) {
		this.durationValid1 = durationValid1;
	}

	public String getValidor2() {
		return validor2;
	}

	public void setValidor2(String validor2) {
		this.validor2 = validor2;
	}

	public String getValidor2Fullname() {
		return validor2Fullname;
	}

	public void setValidor2Fullname(String validor2Fullname) {
		this.validor2Fullname = validor2Fullname;
	}

	public String getValidor2Bak() {
		return validor2Bak;
	}

	public void setValidor2Bak(String validor2Bak) {
		this.validor2Bak = validor2Bak;
	}

	public String getValidor2BakFullname() {
		return validor2BakFullname;
	}

	public void setValidor2BakFullname(String validor2BakFullname) {
		this.validor2BakFullname = validor2BakFullname;
	}

	public int getDurationValid2() {
		return durationValid2;
	}

	public void setDurationValid2(int durationValid2) {
		this.durationValid2 = durationValid2;
	}

	public String getOrig() {
		return orig;
	}

	public void setOrig(String orig) {
		this.orig = orig;
	}

	public String getFrequency() {
		return frequency;
	}

	public void setFrequency(String frequency) {
		this.frequency = frequency;
	}

	public Date getDdmPci() {
		return ddmPci;
	}

	public void setDdmPci(Date ddmPci) {
		this.ddmPci = ddmPci;
	}

	public Date getDdmHorsPci() {
		return ddmHorsPci;
	}

	public void setDdmHorsPci(Date ddmHorsPci) {
		this.ddmHorsPci = ddmHorsPci;
	}

	public Date getCreated() {
		return created;
	}

	public void setCreated(Date created) {
		this.created = created;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public String getSubsidiary() {
		return subsidiary;
	}

	public void setSubsidiary(String subsidiary) {
		this.subsidiary = subsidiary;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public MethodControl getMethodControl() {
		return methodControl;
	}

	public void setMethodControl(MethodControl methodControl) {
		this.methodControl = methodControl;
	}

	public List<AdditionalField> getAdditionalFields() {
		return additionalFields;
	}

	public void setAdditionalFields(List<AdditionalField> additionalFields) {
		this.additionalFields = additionalFields;
	}

	public String getFlag() {
		return flag;
	}

	public void setFlag(String flag) {
		this.flag = flag;
	}

	public List<LogAudit> getLogAudits() {
		return logAudits;
	}

	public void setLogAudits(List<LogAudit> logAudits) {
		this.logAudits = logAudits;
	}

	public List<Operation> getOperations() {
		return operations;
	}

	public void setOperations(List<Operation> operations) {
		this.operations = operations;
	}

	public List<Contributor> getContributors() {
		return contributors;
	}

	public void setContributors(List<Contributor> contributors) {
		this.contributors = contributors;
	}

	public List<ApplicatifIT> getApplicatifIts() {
		return applicatifIts;
	}

	public void setApplicatifIts(List<ApplicatifIT> applicatifIts) {
		this.applicatifIts = applicatifIts;
	}

	public List<Reporting> getReportings() {
		return reportings;
	}

	public void setReportings(List<Reporting> reportings) {
		this.reportings = reportings;
	}

	public static CheckAccount retrievesAOToModel(CheckAccountAO checkAccountAO){

		return checkAccountAO == null || checkAccountAO.getKey().isEmpty() ?
				null :
				new CheckAccount(checkAccountAO.getKey(), checkAccountAO.getChap(), checkAccountAO.getLib_chap(), checkAccountAO.getNcp(), checkAccountAO.getInti(), checkAccountAO.getDev(),
						checkAccountAO.getLib_dev(), checkAccountAO.getAge(), checkAccountAO.getAccount_status(), checkAccountAO.getSoul(), checkAccountAO.getSbi(), checkAccountAO.getDesc_chap_cpt(),
						checkAccountAO.getSensible(), checkAccountAO.getProprio(), checkAccountAO.getIntiProprio(), checkAccountAO.getDelaiSuspens(), checkAccountAO.getTypMvt(), checkAccountAO.getRiskCompt(),
						checkAccountAO.getEntity(), checkAccountAO.getOfficer(), checkAccountAO.getOfficerFullname(), checkAccountAO.getOfficerBak(), checkAccountAO.getOfficerBakFullname(), checkAccountAO.getDuration(),
						checkAccountAO.getValidor1(), checkAccountAO.getValidor1Fullname(), checkAccountAO.getValidor1Bak(), checkAccountAO.getValidor1BakFullname(), checkAccountAO.getDurationValid1(), checkAccountAO.getValidor2(),
						checkAccountAO.getValidor2Fullname(), checkAccountAO.getValidor2Bak(), checkAccountAO.getValidor2BakFullname(), checkAccountAO.getDurationValid2(), checkAccountAO.getOrig(), checkAccountAO.getFrequency(),
						checkAccountAO.getDdmPci(), checkAccountAO.getDdmHorsPci(), checkAccountAO.getCreated(), checkAccountAO.getCreatedBy(), checkAccountAO.getUpdatedBy(), checkAccountAO.getSubsidiary(), checkAccountAO.getStatus(),
						MethodControl.retrievesAOToModel(checkAccountAO.getMethodControl()), AdditionalField.retrievesAOsToModels(checkAccountAO.getAdditionalFields()), Operation.retrievesAOsToModels(checkAccountAO.getOperationAos()), Contributor.retrievesAOsToModels(checkAccountAO.getContributors()),
						ApplicatifIT.retrievesAOsToModels(checkAccountAO.getApplicatifIts()), Reporting.retrievesAOsToModels(checkAccountAO.getReportings()));
	}

	public static List<CheckAccount> retrievesAOsToModels(CheckAccountAO[] checkAccountAOs){
		return retrievesAOsToModels(Arrays.asList(checkAccountAOs));
	}
	public static List<CheckAccount> retrievesAOsToModels(List<CheckAccountAO> checkAccountAOs){
		return checkAccountAOs.stream().map(checkAccountAO -> retrievesAOToModel(checkAccountAO)).collect(Collectors.toList());
	}

	public CheckAccountAO updateDataHorsPCI(CheckAccountAO checkAccountAO){

		if(checkAccountAO.getDesc_chap_cpt()==null || !checkAccountAO.getDesc_chap_cpt().equals(getDescChapCpt())){
			checkAccountAO.setDesc_chap_cpt(getDescChapCpt());
		}

		if(checkAccountAO.getSensible()==null || !checkAccountAO.getSensible().equals(getSensible())){
			checkAccountAO.setSensible(getSensible());
		}

		if(checkAccountAO.getDelaiSuspens() != getDelaiSuspens()){
			checkAccountAO.setDelaiSuspens(getDelaiSuspens());
		}

		if(checkAccountAO.getTypMvt() == null || !checkAccountAO.getTypMvt().equals(getTypMvt())){
			checkAccountAO.setTypMvt(getTypMvt());
		}

		if(checkAccountAO.getRiskCompt() == null || !checkAccountAO.getRiskCompt().equals(getRiskCompt())){
			checkAccountAO.setRiskCompt(getRiskCompt());
		}

		if(checkAccountAO.getEntity() == null || !checkAccountAO.getEntity().equals(getEntity())){
			checkAccountAO.setEntity(getEntity());
		}

		if(checkAccountAO.getOfficer() == null || !checkAccountAO.getOfficer().equals(getOfficer())){
			checkAccountAO.setOfficer(getOfficer());
			checkAccountAO.setOfficerFullname(getOfficerFullname());
		}

		if(checkAccountAO.getOfficerBak() == null || !checkAccountAO.getOfficerBak().equals(getOfficerBak())){
			checkAccountAO.setOfficerBak(getOfficerBak());
			checkAccountAO.setOfficerBakFullname(getOfficerBakFullname());
		}

		if(checkAccountAO.getDuration() != getDuration()){
			checkAccountAO.setDuration(getDuration());
		}

		if(checkAccountAO.getValidor1() == null || !checkAccountAO.getValidor1().equals(getValidor1())){
			checkAccountAO.setValidor1(getValidor1());
			checkAccountAO.setValidor1Fullname(getValidor1Fullname());
		}

		if(checkAccountAO.getValidor1Bak() == null || !checkAccountAO.getValidor1Bak().equals(getValidor1Bak())){
			checkAccountAO.setValidor1Bak(getValidor1Bak());
			checkAccountAO.setValidor1BakFullname(getValidor1BakFullname());
		}

		if(checkAccountAO.getDurationValid1() != getDurationValid1()){
			checkAccountAO.setDurationValid1(getDurationValid1());
		}

		if(checkAccountAO.getValidor2() == null || !checkAccountAO.getValidor2().equals(getValidor2())){
			checkAccountAO.setValidor2(getValidor2());
			checkAccountAO.setValidor2Fullname(getValidor2Fullname());
		}

		if(checkAccountAO.getValidor2Bak() == null || !checkAccountAO.getValidor2Bak().equals(getValidor2Bak())){
			checkAccountAO.setValidor2Bak(getValidor2Bak());
			checkAccountAO.setValidor2BakFullname(getValidor2BakFullname());
		}

		if(checkAccountAO.getDurationValid2() != getDurationValid2()){
			checkAccountAO.setDurationValid2(getDurationValid2());
		}

		if(checkAccountAO.getOrig() == null || !checkAccountAO.getOrig().equals(getOrig())){
			checkAccountAO.setOrig(getOrig());
		}

		if(checkAccountAO.getFrequency() == null || !checkAccountAO.getFrequency().equals(getFrequency())){
			checkAccountAO.setFrequency(getFrequency());
		}

		return  checkAccountAO;
	}

	public boolean validPCI(){
		return true;
	}
}