package com.tc.labt.sgabs.benchmarkdata.service;

import javax.inject.Named;
import javax.inject.Inject;

import com.atlassian.plugin.spring.scanner.annotation.component.Scanned;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.atlassian.activeobjects.external.ActiveObjects;

import com.tc.labt.sgabs.benchmarkdata.ao.CheckAccountAO;
import com.tc.labt.sgabs.benchmarkdata.business.CheckAccountRepo;
import com.tc.labt.sgabs.benchmarkdata.configuration.service.DatasourceConfigurationService;
import com.tc.labt.sgabs.benchmarkdata.utils.Util;

import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.CellType;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

@Named
@Scanned
public class ManageDataHorsPCI{

    @ComponentImport
    private final ActiveObjects activeObjects;
    private final CheckAccountRepo checkAccountRepo;

    public static final List<String> HEADERS = Arrays.asList("N°", "Entité", "Identifiant", "Descriptif Chap", "Délai de suspens",
            "Type mouvement", "Risque comptable", "Contrôleur", "Délai de contrôle", "Réalisation du contrôle", "Applicatifs It mouvements",
            "Applicatif IT contrôles", "Fréquence du contrôle", "Sensible", "Méthode de contrôle", "Validateur 1N", "Délai validation 1N",
            "Validateur 2N", "Délai validation 2N", "Contributor", "Reporting", "Opérations");

    @Inject
    public ManageDataHorsPCI(ActiveObjects activeObjects, DatasourceConfigurationService datasourceConfigurationService){
        super();
        this.activeObjects = activeObjects;
        this.checkAccountRepo = new CheckAccountRepo(activeObjects, datasourceConfigurationService);
    }

    public static byte[] getByteContent(SXSSFWorkbook workbook){
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        try {
            workbook.write(baos);
        }catch (IOException io){
            //log error
            return null;
        }
        return baos.toByteArray();
    }

    public SXSSFWorkbook retrieveWorkbook(List<String> headers, List<List<String>> rows){

        if(headers==null || rows==null
                || headers.size()<1 || rows.size()!=headers.size()){
            return null;
        }
        SXSSFWorkbook workbook = new SXSSFWorkbook(100);
        Sheet sheet = workbook.createSheet();

        // HEADER
        Row header = sheet.createRow(0);
        Util.forEachWithIndex(headers, (i, title) ->{
            header.createCell(i, CellType.STRING).setCellValue(title);
        });
        // BODY
        Util.forEachWithIndex(rows, (i, row) -> {
            Row body = sheet.createRow(i+1);
            body.createCell(0).setCellValue(i+1);
            Util.forEachWithIndex(row, (ii, cellValue) -> {
                body.createCell(ii+1).setCellValue(cellValue);
            });
        });
        return workbook;
    }

    public static SXSSFWorkbook retrieveWorkbook(List<CheckAccountAO> checkAccounts){
        if(checkAccounts==null ||checkAccounts.size()<1)
            return null;

        // HEADERS
        SXSSFWorkbook workbook = new SXSSFWorkbook(100);
        Sheet sheet = workbook.createSheet();

        // HEADER
        Row header = sheet.createRow(0);
        Util.forEachWithIndex(HEADERS, (i, title) ->{
            header.createCell(i, CellType.STRING).setCellValue(title);
        });
        // BODY
        Util.forEachWithIndex(checkAccounts, (i, checkAccount) -> {
            Row body = sheet.createRow(i+1);
            int ii = 0;
            body.createCell(ii++).setCellValue(i+1);
            body.createCell(ii++).setCellValue(checkAccount.getSubsidiary());
            body.createCell(ii++).setCellValue(checkAccount.getKey());
            body.createCell(ii++).setCellValue(checkAccount.getDesc_chap_cpt());
            body.createCell(ii++).setCellValue(checkAccount.getDelaiSuspens());
            body.createCell(ii++).setCellValue(checkAccount.getTypMvt());
            body.createCell(ii++).setCellValue(checkAccount.getRiskCompt());
            body.createCell(ii++).setCellValue(checkAccount.getOfficer());
            body.createCell(ii++).setCellValue(checkAccount.getDuration());
            body.createCell(ii++).setCellValue(checkAccount.getOrig());
            body.createCell(ii++).setCellValue("applicatifs MVT");
            body.createCell(ii++).setCellValue("applicatifs Contrôles");
            body.createCell(ii++).setCellValue(checkAccount.getFrequency());
            body.createCell(ii++).setCellValue(checkAccount.getSensible());
            body.createCell(ii++).setCellValue(checkAccount.getMethodControl()!=null? checkAccount.getMethodControl().getCode() : "");
            body.createCell(ii++).setCellValue(checkAccount.getValidor1());
            body.createCell(ii++).setCellValue(checkAccount.getDurationValid1());
            body.createCell(ii++).setCellValue(checkAccount.getValidor2());
            body.createCell(ii++).setCellValue(checkAccount.getDurationValid2());
            body.createCell(ii++).setCellValue("contributor");
            body.createCell(ii++).setCellValue("reporting");
            body.createCell(ii++).setCellValue("operations");
        });
        return workbook;
    }
}
