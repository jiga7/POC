package com.tc.labt.sgabs.benchmarkdata.business;

import com.tc.labt.sgabs.benchmarkdata.ao.ApplicatifITAO;
import com.tc.labt.sgabs.benchmarkdata.dto.ApplicatifIT;

import com.atlassian.activeobjects.tx.Transactional;

import java.util.List;

@Transactional
public interface IApplicatifITRepo {

    ApplicatifITAO saveForCNTL(ApplicatifIT applicatifIT);

    ApplicatifITAO saveForMVT(ApplicatifIT applicatifIT);

    List<ApplicatifITAO> retrievesAllCNTLBySubsidiary(String subsidiary);

    List<ApplicatifITAO> retrievesEnabledCNTLBySubsidiary(String subsidiary);

    List<ApplicatifITAO> retrievesAllMVTBySubsidiary(String subsidiary);

    List<ApplicatifITAO> retrievesEnabledMVTBySubsidiary(String subsidiary);

    ApplicatifITAO enableOrDisable(ApplicatifIT applicatifIT);

    List<ApplicatifITAO> retrievesAllByIds(List<Integer> ids);
}
