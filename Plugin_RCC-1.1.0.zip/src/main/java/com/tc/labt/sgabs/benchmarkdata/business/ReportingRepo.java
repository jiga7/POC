package com.tc.labt.sgabs.benchmarkdata.business;

import com.tc.labt.sgabs.benchmarkdata.ao.ReportingAO;
import com.tc.labt.sgabs.benchmarkdata.dto.Reporting;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.plugin.spring.scanner.annotation.component.Scanned;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;

import javax.inject.Inject;
import javax.inject.Named;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Scanned
@Named
public class ReportingRepo implements IReportingRepo {

    @ComponentImport
    private ActiveObjects activeObjects;

    public ReportingRepo(){
        super();
    }

    @Inject
    public ReportingRepo(ActiveObjects activeObjects){
        this();
        this.activeObjects = activeObjects;
    }

    @Override
    public ReportingAO save(final Reporting reporting) {

        if(reporting == null)
            return null;

        ReportingAO[] reportingAOs = activeObjects.find(ReportingAO.class, "CODE = ?", reporting.getCode());
        if(reportingAOs.length > 0)
            return reportingAOs[0];

        ReportingAO reportingAO = activeObjects.create(ReportingAO.class);
        reportingAO.setCode(reporting.getCode());
        reportingAO.setLib(reporting.getLib());
        reportingAO.setSubsidiary(reporting.getSubsidiary());
        reportingAO.setActive(Boolean.TRUE);
        reportingAO.save();
        return reportingAO;
    }

    @Override
    public List<ReportingAO> saveOrRetrievesAll(List<Reporting> reportings){

        List<ReportingAO> reportingAOs = new ArrayList<>();
        reportings.parallelStream().forEach(reporting -> reportingAOs.add(save(reporting)));
        return reportingAOs;
    }

    @Override
    public ReportingAO retrievesByCode(String code) {
        ReportingAO[] reportingAOs = activeObjects.find(ReportingAO.class, "CODE = ?", code);
        return reportingAOs.length<=0 ? null : reportingAOs[0];
    }

    @Override
    public List<ReportingAO> retrievesBySubsidiary(String subsidiary) {
        List<ReportingAO> reportingAOs = Arrays.asList(activeObjects.find(ReportingAO.class, "SUBSIDIARY = ?", subsidiary));
        return reportingAOs;
    }

    @Override
    public List<ReportingAO> retrievesEnabledBySubsidiary(String subsidiary) {
        List<ReportingAO> reportingAOs = Arrays.asList(activeObjects.find(ReportingAO.class, "SUBSIDIARY = ? AND ACTIVE = ?", subsidiary, Boolean.TRUE));
        return reportingAOs;
    }

    @Override
    public List<ReportingAO> retrievesAllByIds(List<Integer> ids) {

        if(ids.size() <= 0)
            return null;

        String reporting_ID_Parameters = Collections.nCopies(ids.size(), "?").stream().collect(Collectors.joining(","));
        List<ReportingAO> reportingAOs = Arrays.asList(activeObjects.find(ReportingAO.class, "ID IN ("+reporting_ID_Parameters+")", ids.toArray()));
        return reportingAOs;
    }
}
