package com.tc.labt.sgabs.benchmarkdata.configuration.database.dao;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.tc.labt.sgabs.benchmarkdata.configuration.crypto.Encryption;
import com.tc.labt.sgabs.benchmarkdata.configuration.database.ao.DatabaseAO;
import com.tc.labt.sgabs.benchmarkdata.configuration.database.dto.DatabaseDTO;
import com.tc.labt.sgabs.benchmarkdata.configuration.database.dto.ErrorOrResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.security.GeneralSecurityException;
import java.util.Date;
import java.util.Map;

@Component
public class DatabaseDAOHandler implements IAOHandler<DatabaseAO, DatabaseDTO> {

    private final ActiveObjects ao;
    private final DatasourceDAOHandler daoHandler;

    @Autowired
    public DatabaseDAOHandler(@ComponentImport ActiveObjects activeObjects, DatasourceDAOHandler datasourceDAOHandler){ this.ao = activeObjects; this.daoHandler = datasourceDAOHandler; }

    @Override
    public DatabaseAO createAOEntity(DatabaseDTO databaseDTO) throws Exception {
        ErrorOrResult<DatabaseAO> result = this.ao.executeInTransaction(() -> {
            try {
                DatabaseAO databaseAO = this.ao.get(DatabaseAO.class, databaseDTO.getId());
                if(databaseAO!=null)
                    return this.updateAOEntity(databaseAO, databaseDTO);
                databaseAO = this.ao.create(DatabaseAO.class);
                databaseAO.setDatasourceAO(daoHandler.createAOEntity(databaseDTO.getDatasourceDTO()));
                populateEntity(databaseAO, databaseDTO, true);
                databaseAO.save();
                return ErrorOrResult.ok(databaseAO);
            }catch (Exception e){
                return ErrorOrResult.error(e);
            }
        });
        if(result.exception != null)
            throw result.exception;
        return result.result;
    }

    @Override
    public DatabaseAO updateAOEntity(DatabaseDTO databaseDTO) throws Exception {
        return this.createAOEntity(databaseDTO);
    }

    @Override
    public boolean deleteAOEntity(DatabaseAO databaseAO) throws Exception {
        ErrorOrResult<DatabaseAO> result = this.ao.executeInTransaction(() -> {
            try {
                this.ao.delete(databaseAO);
            }catch (Exception e){
                return ErrorOrResult.error(e);
            }
            return ErrorOrResult.ok(databaseAO);
        });
        if(result.exception != null)
            throw result.exception;
        return false;
    }

    private ErrorOrResult<DatabaseAO> updateAOEntity(DatabaseAO databaseAO, DatabaseDTO databaseDTO){
        return this.ao.executeInTransaction(() -> {
            try {
                populateEntity(databaseAO, databaseDTO, false);
            } catch (GeneralSecurityException e) {
                return ErrorOrResult.error(e);
            }
            databaseAO.save();
            return ErrorOrResult.ok(databaseAO);
        });
    }

    private void populateEntity(DatabaseAO databaseAO, DatabaseDTO databaseDTO, boolean created) throws GeneralSecurityException {
        databaseAO.setName(databaseDTO.getName());
        databaseAO.setType(databaseDTO.getType());
        databaseAO.setHost(databaseDTO.getHost());
        databaseAO.setPort(databaseDTO.getPort());
        databaseAO.setSchema(databaseDTO.getSchema());
        databaseAO.setService(databaseDTO.getService());
        databaseAO.setLogin(databaseDTO.getLogin());
        if(created){
            databaseAO.setCreated(new Date());
        }else{
            databaseAO.setLastUpdated(new Date());
        }
        if(databaseDTO.getPassword()!=null){
            Map<String, String> crypt = Encryption.encrypt(databaseDTO.getPassword());
            databaseAO.setSecretKey(crypt.get(Encryption.IV));
            databaseAO.setPasswordEncrypted(crypt.get(Encryption.CRYPT));
            databaseAO.setPassword(null);
        }
    }
}
