package com.tc.labt.sgabs.benchmarkdata.ao;

import net.java.ao.Entity;

import java.util.Date;

public interface LogAuditAO extends Entity {

	public String getAuthor();
	public void setAuthor(String author);
	
	public String getDescription();
	public void setDescription(String description);
	
	public Integer getIndex();
	public void setIndex(Integer index);
	
	public Date getCreated();
	public void setCreated(Date created);

	public CheckAccountAO getCheckAccount();
	public void setCheckAccount(CheckAccountAO checkAccount);

	public FileLoadedAuditAO getFileLoadedAudit();
	public void setFileLoadedAudit(FileLoadedAuditAO fileLoadedAudit);

	/* Normally not needed */
	public OperationCAFKAO getOperationCAFKAO();
	public void setOperationCAFKAO(OperationCAFKAO operationCAFKAO);

	public ReportingCAFKAO getReportingCAFKAO();
	public void setReportingCAFKAO(ReportingCAFKAO reportingCAFKAO);

	public ApplicatifITCAFKAO getApplicatifITCAFKAO();
	public void setApplicatifITCAFKAO(ApplicatifITCAFKAO applicatifITCAFKAO);

	public ContributorCAFKAO getContributorCAFKAO();
	public void setContributorCAFKAO(ContributorCAFKAO contributorCAFKAO);
}