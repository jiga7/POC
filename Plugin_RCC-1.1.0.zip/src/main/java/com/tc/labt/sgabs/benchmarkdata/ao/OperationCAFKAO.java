package com.tc.labt.sgabs.benchmarkdata.ao;

import net.java.ao.Entity;
import net.java.ao.OneToMany;

import java.util.Date;

public interface OperationCAFKAO extends Entity{

    public OperationAO getOperation();
    public void setOperation(OperationAO operationAO);

    public CheckAccountAO getCheckAccount();
    public void setCheckAccount(CheckAccountAO checkAccountAO);

    public Date getAddedAt();
    public void setAddedAt(Date addedAt);

    @OneToMany(reverse="getOperationCAFKAO")
    public LogAuditAO[] getLogAudits();
}
