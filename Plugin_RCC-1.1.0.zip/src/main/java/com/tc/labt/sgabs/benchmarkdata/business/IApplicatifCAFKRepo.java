package com.tc.labt.sgabs.benchmarkdata.business;

import com.tc.labt.sgabs.benchmarkdata.ao.ApplicatifITAO;
import com.tc.labt.sgabs.benchmarkdata.ao.ApplicatifITCAFKAO;
import com.tc.labt.sgabs.benchmarkdata.ao.CheckAccountAO;

import java.util.List;

import com.atlassian.activeobjects.tx.Transactional;

@Transactional
public interface IApplicatifCAFKRepo {

    ApplicatifITCAFKAO save(ApplicatifITAO applicatifITAO, CheckAccountAO checkAccountAO);

    List<ApplicatifITCAFKAO> save(List<ApplicatifITAO> applicatifITAOs, CheckAccountAO checkAccountAO);

    List<ApplicatifITCAFKAO> saveAll(List<Integer> applicatifIT_IDs, CheckAccountAO checkAccountAO);

    List<ApplicatifITCAFKAO> retrieveByCheckAccountID(String checkAccountID);

    List<ApplicatifITCAFKAO> deleteAll(List<ApplicatifITCAFKAO> applicatifITCAFKAOs);
}
