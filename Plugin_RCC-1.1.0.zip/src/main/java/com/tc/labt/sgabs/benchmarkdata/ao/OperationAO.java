package com.tc.labt.sgabs.benchmarkdata.ao;

import net.java.ao.Entity;
import net.java.ao.ManyToMany;

public interface OperationAO extends Entity{

	public String getOpe();
	public void setOpe(String ope);
	
	public String getLib();
	public void setLib(String lib);
	
	public String getSubsidiary();
	public void setSubsidiary(String subsidiary);
	
	public boolean isActive();
	public void setActive(boolean active);

	@ManyToMany(value = OperationCAFKAO.class)
	public CheckAccountAO[] getCheckAccounts();
}