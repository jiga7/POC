package com.tc.labt.sgabs.benchmarkdata.configuration.database.ao;

import com.tc.labt.sgabs.benchmarkdata.configuration.database.DatasourceType;
import net.java.ao.OneToMany;
import net.java.ao.schema.Table;

@Table("datasource")
public interface DatasourceAO extends EntityWithIdAndAuditAO {

    public DatasourceType getType();
    public void setType(DatasourceType type);

    public String getName();
    public void setName(String name);

    @OneToMany
    public DatabaseAO getDatabaseAO();
}
