package com.tc.labt.sgabs.benchmarkdata.configuration.sql;

import com.tc.labt.sgabs.benchmarkdata.configuration.database.DatabaseType;

public class MysqlDefinition extends AbstractDefinition{

    public MysqlDefinition() {
        super("jdbc:mysql://", DatabaseType.MYSQL, "com.mysql.jdbc.Driver");
    }
}
