package com.tc.labt.sgabs.benchmarkdata.business;

import com.tc.labt.sgabs.benchmarkdata.ao.ReportingAO;
import com.tc.labt.sgabs.benchmarkdata.dto.Reporting;

import com.atlassian.activeobjects.tx.Transactional;

import java.util.List;

@Transactional
public interface IReportingRepo {

    ReportingAO save(Reporting reporting);

    List<ReportingAO> saveOrRetrievesAll(List<Reporting> reportings);

    ReportingAO retrievesByCode(String code);

    List<ReportingAO> retrievesBySubsidiary(String subsidiary);

    List<ReportingAO> retrievesEnabledBySubsidiary(String subsidiary);

    List<ReportingAO> retrievesAllByIds(List<Integer> ids);

}
