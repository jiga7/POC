package com.tc.labt.sgabs.benchmarkdata.utils;

public class MessageResponse {

    public static final String _422 = "L'entité fournie avec la requête est incompléte.";

    public static final String _500 = "Une erreur interne s'est produite sur le serveur.";

    public static final String _204 = "Résultat vide (0).";
}
