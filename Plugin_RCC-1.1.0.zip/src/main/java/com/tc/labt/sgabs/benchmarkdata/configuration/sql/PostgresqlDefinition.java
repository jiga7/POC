package com.tc.labt.sgabs.benchmarkdata.configuration.sql;

import com.tc.labt.sgabs.benchmarkdata.configuration.database.DatabaseType;

public class PostgresqlDefinition extends AbstractDefinition {

    public PostgresqlDefinition() {
        super("jdbc:postgresql://", DatabaseType.POSTGRESQL, "org.postgresql.Driver");
    }

    @Override
    public boolean hasSchemaSupport() {
        return true;
    }
}
