package com.tc.labt.sgabs.benchmarkdata.ao;

import net.java.ao.RawEntity;
import net.java.ao.OneToMany;
import net.java.ao.ManyToMany;
import net.java.ao.schema.PrimaryKey;

import java.util.Date;

public interface CheckAccountAO extends RawEntity<String> {

	@PrimaryKey("KEY")
	public String getKey();
	public void setKey(String key);

	public String getChap();
	public void setChap(String chap);

	public String getLib_chap();
	public void setLib_chap(String lib_chap);

	public String getNcp();
	public void setNcp(String ncp);

	public String getInti();
	public void setInti(String inti);

	public String getDev();
	public void setDev(String dev);

	public String getLib_dev();
	public void setLib_dev(String lib_dev);

	public String getAge();
	public void setAge(String age);

	public String getAccount_status();
	public void setAccount_status(String account_status);

	public String getSoul();
	public void setSoul(String soul);

	public String getSbi();
	public void setSbi(String sbi);

	public String getDesc_chap_cpt();
	public void setDesc_chap_cpt(String desc_chap_cpt);

	public String getSensible();
	public void setSensible(String sensible);

	public String getProprio();
	public void setProprio(String proprio);

	public String getIntiProprio();
	public void setIntiProprio(String intiSroprio);

	public int getDelaiSuspens();
	public void setDelaiSuspens(int delaiSuspens);

	public String getTypMvt();
	public void setTypMvt(String typMvt);

	public String getRiskCompt();
	public void setRiskCompt(String riskCompt);

	public String getEntity();
	public void setEntity(String entity);

	public String getOfficer();
	public void setOfficer(String officer);

	public String getOfficerFullname();
	public void setOfficerFullname(String officerFullname);

	public String getOfficerBak();
	public void setOfficerBak(String officerBak);

	public String getOfficerBakFullname();
	public void setOfficerBakFullname(String officerBakFullname);

	public int getDuration();
	public void setDuration(int duration);

	public String getValidor1();
	public void setValidor1(String validor1);

	public String getValidor1Fullname();
	public void setValidor1Fullname(String validor1Fullname);

	public String getValidor1Bak();
	public void setValidor1Bak(String validor1Bak);

	public String getValidor1BakFullname();
	public void setValidor1BakFullname(String validor1Fullname);

	public int getDurationValid1();
	public void setDurationValid1(int durationValid1);

	public String getValidor2();
	public void setValidor2(String validor2);

	public String getValidor2Fullname();
	public void setValidor2Fullname(String validor2Fullname);

	public String getValidor2Bak();
	public void setValidor2Bak(String validor2Bak);

	public String getValidor2BakFullname();
	public void setValidor2BakFullname(String validor2BakFullname);

	public int getDurationValid2();
	public void setDurationValid2(int durationValid2);

	public String getOrig();
	public void setOrig(String orig);

	public String getFrequency();
	public void setFrequency(String frequency);

	public Date getDdmPci();
	public void setDdmPci(Date ddmPci);

	public Date getDdmHorsPci();
	public void setDdmHorsPci(Date ddmHorsPci);

	public Date getCreated();
	public void setCreated(Date created);

	public String getCreatedBy();
	public void setCreatedBy(String createdBy);

	public String getUpdatedBy();
	public void setUpdatedBy(String updatedBy);

	public String getSubsidiary();
	public void setSubsidiary(String subsidiary);

	public String getStatus();
	public void setStatus(String status);

	public MethodControlAO getMethodControl();
	public void setMethodControl(MethodControlAO methodControl);

	@OneToMany(reverse="getCheckAccount")
 	public AdditionalFieldAO[] getAdditionalFields();

	@OneToMany(reverse="getCheckAccount")
	public LogAuditAO[] getLogAudits();

	@ManyToMany(value = OperationCAFKAO.class)
	public OperationAO[] getOperationAos();

	@ManyToMany(value = ContributorCAFKAO.class)
	public ContributorAO[] getContributors();

	@ManyToMany(value = ApplicatifITCAFKAO.class)
	public ApplicatifITAO[] getApplicatifIts();

	@ManyToMany(value = ReportingCAFKAO.class)
	public ReportingAO[] getReportings();
}
