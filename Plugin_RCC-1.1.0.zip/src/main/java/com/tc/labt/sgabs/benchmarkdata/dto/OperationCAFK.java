package com.tc.labt.sgabs.benchmarkdata.dto;

import java.io.Serializable;
import java.util.Date;

public class OperationCAFK implements Serializable {

    private Operation operation;
    private CheckAccount checkAccount;
    private Date addedAt;

    public OperationCAFK() {
        super();
    }

    public OperationCAFK(Operation operation, CheckAccount checkAccount, Date addedAt) {
        this();
        this.operation = operation;
        this.checkAccount = checkAccount;
        this.addedAt = addedAt;
    }

    public Operation getOperation() {
        return operation;
    }

    public void setOperation(Operation operation) {
        this.operation = operation;
    }

    public CheckAccount getCheckAccount() {
        return checkAccount;
    }

    public void setCheckAccount(CheckAccount checkAccount) {
        this.checkAccount = checkAccount;
    }

    public Date getAddedAt() {
        return addedAt;
    }

    public void setAddedAt(Date addedAt) {
        this.addedAt = addedAt;
    }
}
