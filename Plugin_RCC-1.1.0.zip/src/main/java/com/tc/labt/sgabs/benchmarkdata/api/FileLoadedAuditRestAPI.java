package com.tc.labt.sgabs.benchmarkdata.api;

import com.tc.labt.sgabs.benchmarkdata.business.FileLoadedAuditRepo;
import com.tc.labt.sgabs.benchmarkdata.ao.FileLoadedAuditAO;
import com.tc.labt.sgabs.benchmarkdata.dto.FileLoadedAudit;
import com.tc.labt.sgabs.benchmarkdata.utils.MessageResponse;

import javax.inject.Inject;

import com.atlassian.plugin.spring.scanner.annotation.component.Scanned;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.atlassian.activeobjects.external.ActiveObjects;

import com.atlassian.plugins.rest.common.multipart.FilePart;
import com.atlassian.plugins.rest.common.multipart.MultipartFormParam;
import com.atlassian.plugins.rest.common.security.AnonymousAllowed;

import javax.servlet.http.HttpServletRequest;

import javax.ws.rs.*;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.MediaType;

import java.io.IOException;
import java.util.List;

@Path("/log/fileloaded")
@Scanned
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class FileLoadedAuditRestAPI {

    @ComponentImport
    private final ActiveObjects activeObjects;

    private final FileLoadedAuditRepo fileLoadedAuditRepo;

    @Inject
    public FileLoadedAuditRestAPI(ActiveObjects activeObjects){
        super();
        this.activeObjects = activeObjects;
        fileLoadedAuditRepo = new FileLoadedAuditRepo(this.activeObjects);
    }

    @POST
    @Path("/add")
    public Response logFileLoaded(final FileLoadedAudit fileLoadedAudit, @Context HttpServletRequest request) throws IOException{

        if(fileLoadedAudit == null || fileLoadedAudit.getFilename().isEmpty() || fileLoadedAudit.getPath().isEmpty())
            return Response.status(422).entity(MessageResponse._422).build();

        FileLoadedAuditAO fileLoadedAuditAO = fileLoadedAuditRepo.save(fileLoadedAudit);
        return fileLoadedAuditAO.getID() == 0 ? Response.status(500).entity(MessageResponse._500).build() : Response.ok(FileLoadedAudit.retrievesAOToModel(fileLoadedAuditAO)).build();
    }

    @GET
    @Path("/views/all")
    public Response getAllLogs(@Context HttpServletRequest request) throws  IOException{

        List<FileLoadedAudit> fileLoadedAudits = FileLoadedAudit.retrievesAOsToModels(fileLoadedAuditRepo.retrievesAll());
        return fileLoadedAudits==null || fileLoadedAudits.size() == 0 ? Response.status(204).entity(MessageResponse._204).build() : Response.ok(fileLoadedAudits).build();
    }

    @POST
    @Path("/upload-file")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.WILDCARD)
    @AnonymousAllowed
    public Response upload(@MultipartFormParam("file") FilePart filePart){
        System.err.println("Filename " +  filePart.getName());
       // System.err.println("Path " + path);
        return Response.ok().build();
    }
}
