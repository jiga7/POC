package com.tc.labt.sgabs.benchmarkdata.api;

import javax.inject.Inject;

import com.atlassian.plugin.spring.scanner.annotation.component.Scanned;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.atlassian.activeobjects.external.ActiveObjects;
import com.tc.labt.sgabs.benchmarkdata.ao.LogAuditAO;
import com.tc.labt.sgabs.benchmarkdata.dto.LogAudit;
import com.tc.labt.sgabs.benchmarkdata.dto.Pagination;
import com.tc.labt.sgabs.benchmarkdata.business.LogAuditRepo;
import com.tc.labt.sgabs.benchmarkdata.utils.MessageResponse;

import javax.servlet.http.HttpServletRequest;

import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.PathParam;
import javax.ws.rs.Path;
import javax.ws.rs.POST;
import javax.ws.rs.GET;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.MediaType;
import java.io.IOException;
import java.util.List;

@Path("/logs/audit")
@Scanned
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class LogAuditRestAPI {

    @ComponentImport
    private final ActiveObjects activeObjects;

    private final LogAuditRepo logAuditRepo;

    @Inject
    public LogAuditRestAPI(ActiveObjects activeObjects){
        super();
        this.activeObjects = activeObjects;
        logAuditRepo = new LogAuditRepo(activeObjects);
    }

    @POST
    @Path("/add")
    public Response logAudit(final LogAudit logAudit, @Context HttpServletRequest request) throws IOException {

        if(logAudit == null || logAudit.getDescription().isEmpty() || logAudit.getAuthor().isEmpty())
            return Response.status(422).entity(MessageResponse._422).build();

        LogAuditAO logAuditAO = logAuditRepo.save(logAudit);
        return logAuditAO.getID() == 0 ? Response.status(500).entity(MessageResponse._500).build() : Response.ok(logAudit).build();
    }

    @GET
    @Path("/views/all")
    public Response getAllLogs(@Context HttpServletRequest request) throws IOException{

        List<LogAudit> logAudits = LogAudit.retrievesAOsToModels(logAuditRepo.retrievesAll());
        return logAudits == null || logAudits.size() == 0 ? Response.status(204).entity(MessageResponse._204).build() : Response.ok(logAudits).build();
    }

    @GET
    @Path("/views")
    public Response getLogsPagination(@Context HttpServletRequest request) throws IOException{

        int page = request.getParameter("page").isEmpty() ? 0 : Integer.parseInt(request.getParameter("page"));
        int size = request.getParameter("size").isEmpty() ? -1 : Integer.parseInt(request.getParameter("size"));

        return size > 0 ?
                Response.status(204).entity(MessageResponse._204).build() :
                Response.ok(new Pagination<LogAudit>(page, LogAudit.retrievesAOsToModels(logAuditRepo.retrievesAll(page, size)))).build();
    }

    @GET
    @Path("/views/project/{subsidiary}/all")
    public Response getSubsidiaryLogs(final @PathParam("subsidiary") String subsidiary, @Context HttpServletRequest request) throws IOException{

        if(subsidiary == null || subsidiary.isEmpty())
            return Response.status(422).entity(MessageResponse._422).build();

        List<LogAudit> logAudits = LogAudit.retrievesAOsToModels(logAuditRepo.retrievesBySubsidiary(subsidiary));
        return logAudits == null || logAudits.size() == 0 ? Response.status(204).entity(MessageResponse._204).build() : Response.ok(logAudits).build();
    }

    @GET
    @Path("/views/project/{subsidiary}")
    public Response getSubsidiaryLogsPagination(final @PathParam("subsidiary") String subsidiary, @Context HttpServletRequest request) throws IOException{

        int page = request.getParameter("page").isEmpty() ? 0 : Integer.parseInt(request.getParameter("page"));
        int size = request.getParameter("size").isEmpty() ? -1 : Integer.parseInt(request.getParameter("size"));


        return subsidiary == null || subsidiary.isEmpty() || size > 0 ?
                Response.status(204).entity(MessageResponse._204).build() :
                Response.ok(new Pagination<LogAudit>(page, LogAudit.retrievesAOsToModels(logAuditRepo.retrievesBySubsidiary(subsidiary, page, size)))).build();
    }

    @GET
    @Path("/views/user/{author}/all")
    public Response getAuthorLogs(final @PathParam("author") String author, @Context HttpServletRequest request) throws IOException{

        if(author == null || author.isEmpty())
            return Response.status(422).entity(MessageResponse._422).build();

        List<LogAudit> logAudits = LogAudit.retrievesAOsToModels(logAuditRepo.retrievesBySubsidiary(author));
        return logAudits == null || logAudits.size() == 0 ?
                Response.status(204).entity(MessageResponse._204).build() :
                Response.ok(logAudits).build();
    }

    @GET
    @Path("/views/user/{author}")
    public Response getAuthorLogsPagination(final @PathParam("author") String author, @Context HttpServletRequest request) throws IOException{

        int page = request.getParameter("page").isEmpty() ? 0 : Integer.parseInt(request.getParameter("page"));
        int size = request.getParameter("size").isEmpty() ? -1 : Integer.parseInt(request.getParameter("size"));


        return author == null || author.isEmpty() || size > 0 ?
                Response.status(204).entity(MessageResponse._204).build() :
                Response.ok(new Pagination<LogAudit>(page, LogAudit.retrievesAOsToModels(logAuditRepo.retrievesByAuthor(author, page, size)))).build();
    }
}
