package com.tc.labt.sgabs.benchmarkdata.business;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.plugin.spring.scanner.annotation.component.Scanned;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.tc.labt.sgabs.benchmarkdata.ao.CheckAccountAO;
import com.tc.labt.sgabs.benchmarkdata.configuration.service.DatasourceConfigurationService;
import com.tc.labt.sgabs.benchmarkdata.dto.ApplicatifIT;
import com.tc.labt.sgabs.benchmarkdata.dto.CheckAccount;

import javax.inject.Inject;
import javax.inject.Named;

import com.tc.labt.sgabs.benchmarkdata.dto.Operation;
import com.tc.labt.sgabs.benchmarkdata.dto.Reporting;
import net.java.ao.DBParam;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@Scanned
@Named
public class CheckAccountRepo implements ICheckAccountRepo{

    @ComponentImport
    private ActiveObjects activeObjects;

    private MethodControlRepo methodControlRepo;
    private ApplicatifCAFKRepo applicatifCAFKRepo;
    private ReportingCAFKRepo reportingCAFKRepo;
    private OperationCAFKRepo operationCAFKRepo;

    public CheckAccountRepo() { super(); }

    @Inject
    public CheckAccountRepo(ActiveObjects activeObjects, DatasourceConfigurationService datasourceConfigurationService){
        this();
        this.activeObjects = activeObjects;
        this.methodControlRepo =  new MethodControlRepo(datasourceConfigurationService);
        this.applicatifCAFKRepo = new ApplicatifCAFKRepo(activeObjects);
        this.reportingCAFKRepo = new ReportingCAFKRepo(activeObjects);
        this.operationCAFKRepo = new OperationCAFKRepo(activeObjects);
    }

    @Override
    public CheckAccountAO savePCI(CheckAccount checkAccount) {

        if(checkAccount == null || checkAccount.getKey().isEmpty())
            return null;
        CheckAccountAO checkAccountAO = retrievesByKey(checkAccount.getKey());
       if(checkAccountAO == null || checkAccountAO.getKey()==null || checkAccountAO.getKey().isEmpty()){
            checkAccountAO = activeObjects.create(CheckAccountAO.class,
                    new DBParam("KEY", checkAccount.getKey()));
            checkAccountAO.setKey(checkAccount.getKey());
            checkAccountAO.setCreated(new Date());
            checkAccountAO.setCreatedBy("AUTO_BI");
            checkAccountAO.setStatus("A COMPLETER");
       }else
            checkAccountAO.setDdmPci(new Date());

        checkAccountAO.setChap(checkAccount.getChap());
        checkAccountAO.setLib_chap(checkAccount.getLibChap());
        checkAccountAO.setNcp(checkAccount.getNcp());
        checkAccountAO.setInti(checkAccount.getInti());
        checkAccountAO.setDev(checkAccount.getDev());
        checkAccountAO.setLib_dev(checkAccount.getLibDev());
        checkAccountAO.setAge(checkAccount.getAge());
        checkAccountAO.setAccount_status(checkAccount.getAccountStatus());
        checkAccountAO.setSoul(checkAccount.getSoul());
        checkAccountAO.setSbi(checkAccount.getSbi());
        checkAccountAO.setSubsidiary(checkAccount.getSubsidiary());
        checkAccountAO.save();
        return checkAccountAO;
    }

    @Override
    public CheckAccountAO updateHorsPCI(CheckAccount checkAccount){
        if(checkAccount == null || checkAccount.getKey().isEmpty())
            return null;

        CheckAccountAO checkAccountAO = retrievesByKey(checkAccount.getKey());
         if(checkAccountAO == null || checkAccountAO.getKey() == null || checkAccountAO.getKey().isEmpty())
            return null;
        checkAccountAO = checkAccount.updateDataHorsPCI(checkAccountAO);
        checkAccountAO.setDdmHorsPci(new Date());
        checkAccountAO.setUpdatedBy(checkAccount.getUpdatedBy());

        // Put method of control
        if(checkAccount.getMethodControl() != null && checkAccount.getMethodControl().getCode()!=null && !checkAccount.getMethodControl().getCode().isEmpty())
            checkAccountAO.setMethodControl(methodControlRepo.retrievesByCode(checkAccount.getMethodControl().getCode(), checkAccount.getSubsidiary()));

        checkAccountAO.save();

        // Put applicatifs IT
        if(checkAccount.getApplicatifIts()!=null && checkAccount.getApplicatifIts().size()>0) {
            applicatifCAFKRepo.saveAll(
                    checkAccount.getApplicatifIts()
                            .stream().parallel()
                            .map(ApplicatifIT::getId)
                            .collect(Collectors.toList()), checkAccountAO
                    );
        }

        // Put Reportings
        if(checkAccount.getReportings()!=null && checkAccount.getReportings().size()>0){
            reportingCAFKRepo.saveAll(
                    checkAccount.getReportings()
                            .stream().parallel()
                            .map(Reporting::getId)
                            .collect(Collectors.toList()), checkAccountAO
                    );
        }

        // Put Operations
        if(checkAccount.getOperations()!=null && checkAccount.getOperations().size()>0){
            operationCAFKRepo.saveAll(
                    checkAccount.getOperations()
                            .stream().parallel()
                            .map(Operation::getId)
                            .collect(Collectors.toList()), checkAccountAO
            );
        }

        // Put contributors

        return checkAccountAO;
    }

    @Override
    public List<CheckAccountAO> saveAll(List<CheckAccount> checkAccounts) {

        return checkAccounts.size() > 0 ? checkAccounts.stream().parallel()
                .map(checkAccount -> savePCI(checkAccount)).collect(Collectors.toList()) : null;
    }

    @Override
    public CheckAccountAO retrievesByKey(String key) {

        CheckAccountAO[] checkAccountAOs = activeObjects.find(CheckAccountAO.class, "KEY = ?", key);
        return checkAccountAOs.length == 1 ? checkAccountAOs[0] : null;
    }

    @Override
    public List<CheckAccountAO> retrievesEnabledBySubsidiary(String subsidiary) {

        List<CheckAccountAO> checkAccountAOs = Arrays.asList(activeObjects.find(CheckAccountAO.class, "SUBSIDIARY = ? AND ACTIVE = ?", subsidiary, Boolean.TRUE));
        return checkAccountAOs;
    }

    @Override
    public List<CheckAccountAO> retrievesAllBySubsidiary(String subsidiary){

        List<CheckAccountAO> checkAccountAOs = Arrays.asList(activeObjects.find(CheckAccountAO.class, "SUBSIDIARY = ?", subsidiary));
        return checkAccountAOs;
    }
}
