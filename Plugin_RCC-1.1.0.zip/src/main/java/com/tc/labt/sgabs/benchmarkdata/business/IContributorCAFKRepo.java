package com.tc.labt.sgabs.benchmarkdata.business;

import com.tc.labt.sgabs.benchmarkdata.ao.CheckAccountAO;
import com.tc.labt.sgabs.benchmarkdata.ao.ContributorAO;
import com.tc.labt.sgabs.benchmarkdata.ao.ContributorCAFKAO;

import java.util.List;

public interface IContributorCAFKRepo {

    ContributorCAFKAO save(ContributorAO contributorAO, CheckAccountAO checkAccountAO);

    List<ContributorCAFKAO> save(List<ContributorAO> contributorAOs, CheckAccountAO checkAccountAO);

    List<ContributorCAFKAO> saveAll(List<Integer> contributor_IDs, CheckAccountAO checkAccountAO);

    List<ContributorCAFKAO> retrieveByCheckAccountID(String checkAccountID);

    List<ContributorCAFKAO> deleteAll(List<ContributorCAFKAO> contributorCAFKAOs);
}
