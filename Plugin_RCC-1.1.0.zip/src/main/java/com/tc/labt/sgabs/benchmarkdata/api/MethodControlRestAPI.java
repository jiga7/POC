package com.tc.labt.sgabs.benchmarkdata.api;

import javax.inject.Inject;

import com.tc.labt.sgabs.benchmarkdata.ao.MethodControlAO;
import com.tc.labt.sgabs.benchmarkdata.dto.MethodControl;
import com.tc.labt.sgabs.benchmarkdata.business.IMethodControlRepo;
import com.tc.labt.sgabs.benchmarkdata.business.MethodControlRepo;

import com.atlassian.plugin.spring.scanner.annotation.component.Scanned;
import com.tc.labt.sgabs.benchmarkdata.utils.MessageResponse;

import javax.servlet.http.HttpServletRequest;

import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.PathParam;
import javax.ws.rs.Path;
import javax.ws.rs.POST;
import javax.ws.rs.GET;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.MediaType;
import java.io.IOException;

@Path("/methods")
@Scanned
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class MethodControlRestAPI {

    private final IMethodControlRepo methodControlRepo;

    @Inject
    public MethodControlRestAPI(MethodControlRepo methodControlRepo){
        super();
        this.methodControlRepo = methodControlRepo;
    }

    @POST
    @Path("/add")
    public Response addMethodControl(final MethodControl methodControl, @Context HttpServletRequest request) throws IOException {

        if(methodControl == null || methodControl.getCode().isEmpty())
            return Response.status(422).entity(MessageResponse._422).build();

        /*MethodControlAO methodControlAO = methodControlRepo.save(methodControl);
        return methodControlAO.getID() == 0 ?
                Response.status(500).entity(MessageResponse._500).build() :
                Response.ok(MethodControl.retrievesAOToModel(methodControlAO)).build();*/
        return Response.ok(methodControlRepo.saveP(methodControl)).build();
    }

    @GET
    @Path("/views/{subsidiary}/all")
    public Response getAllMethodControls(final @PathParam("subsidiary") String subsidiary, @Context HttpServletRequest request) throws IOException{

        if(subsidiary == null || subsidiary.isEmpty())
            return Response.status(422).entity(MessageResponse._422).build();
        //List<MethodControl> methodControls = MethodControl.retrievesAOsToModels(methodControlRepo.retrievesBySubsidiary(subsidiary));
       // return methodControls == null || methodControls.size() == 0 ? Response.status(204).entity(MessageResponse._204).build() : Response.ok(methodControls).build();
        return Response.ok(methodControlRepo.retrievesBySubsidiaryP(subsidiary)).build();
    }

    @GET
    @Path("/lists/{subsidiary}")
    public Response getListMethods(final @PathParam("subsidiary") String subsidiary, @Context HttpServletRequest request) throws IOException{
        return Response.ok(MethodControl.retrievesListOption(methodControlRepo.retrievesEnabledBySubsidiary(subsidiary))).build();
    }
}
