package com.tc.labt.sgabs.benchmarkdata.configuration.database.dto;

import java.io.Serializable;
import java.util.Date;

public class LogAuditDTO implements Serializable {

    private int id;
    private String author;
    private Date created;
    private String key;
    private String table;
    private String changeLog;

    public LogAuditDTO() {
    }

    public LogAuditDTO(int id, String author, Date created, String key, String table, String changeLog) {
        this.id = id;
        this.author = author;
        this.created = created;
        this.key = key;
        this.table = table;
        this.changeLog = changeLog;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getTable() {
        return table;
    }

    public void setTable(String table) {
        this.table = table;
    }

    public String getChangeLog() {
        return changeLog;
    }

    public void setChangeLog(String changeLog) {
        this.changeLog = changeLog;
    }
}
