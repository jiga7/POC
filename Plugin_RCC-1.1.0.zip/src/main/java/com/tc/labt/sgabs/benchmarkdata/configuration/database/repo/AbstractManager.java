package com.tc.labt.sgabs.benchmarkdata.configuration.database.repo;

import java.util.Collection;
import java.util.List;

public abstract class AbstractManager<T, D, ID> {

    public abstract Collection<T> getAll() throws Exception;

    public abstract T get(ID id);

    public abstract D create(D param) throws Exception;

    public abstract D update(D param) throws Exception;

    public abstract boolean delete(ID id) throws Exception;
}
