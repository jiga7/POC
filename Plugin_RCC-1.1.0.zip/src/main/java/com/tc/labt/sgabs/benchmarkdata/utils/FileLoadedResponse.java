package com.tc.labt.sgabs.benchmarkdata.utils;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlElement;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class FileLoadedResponse implements Serializable {

    @XmlElement
    private String subsidiary;
    private int count;
    private int added;
    private int failed;
    private int accountClosed;

    public FileLoadedResponse() {
        this.added = 0;
        this.count = 0;
        this.failed = 0;
        this.accountClosed = 0;
    }

    public FileLoadedResponse(String subsidiary) {
        this();
        this.subsidiary = subsidiary;
    }

    public String getSubsidiary() {
        return subsidiary;
    }

    public void setSubsidiary(String subsidiary) {
        this.subsidiary = subsidiary;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count += count;
    }

    public int getAdded() {
        return added;
    }

    public void setAdded(int added) {
        this.added += added;
    }

    public int getFailed() {
        return failed;
    }

    public void setFailed(int failed) {
        this.failed += failed;
    }

    public int getAccountClosed() {
        return accountClosed;
    }

    public void setAccountClosed(int accountClosed) {
        this.accountClosed += accountClosed;
    }
}
