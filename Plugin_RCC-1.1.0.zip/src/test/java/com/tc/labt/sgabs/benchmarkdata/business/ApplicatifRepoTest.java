package com.tc.labt.sgabs.benchmarkdata.business;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.activeobjects.test.TestActiveObjects;

import net.java.ao.test.junit.ActiveObjectsJUnitRunner;
import net.java.ao.EntityManager;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import static org.junit.Assert.*;

@RunWith(ActiveObjectsJUnitRunner.class)
public class ApplicatifRepoTest {

    private EntityManager entityManager;

    private ApplicatifITRepo applicatifITRepo;

    private ActiveObjects activeObjects;

    @Before
    public void setUp() throws Exception{
        assertNotNull(entityManager);
        activeObjects = new TestActiveObjects(entityManager);
        //applicatifITRepo = new ApplicatifITRepo(activeObjects);
    }

    final String codeCNTL = "SP";
    final String libCNTL = "Workflow SP";
    final String subsidiaryCNTL = "SGCB";

    final String codeMVT = "FLUX";
    final String libMVT = "Workflow SP";
    final String subsidiaryMVT = "SGCB";

    @After
    public void tearDown() throws Exception{

    }

    @Test
    public void saveTest() throws Exception{
        /*
        activeObjects.migrate(ApplicatifITAO.class);

        assertEquals(0, activeObjects.find(ApplicatifITAO.class).length);

        final ApplicatifITAO addedCNTLAO = applicatifITRepo.saveForCNTL(new ApplicatifIT(codeCNTL, libCNTL, subsidiaryCNTL));
        assertFalse(addedCNTLAO.getID()==0);

        final ApplicatifITAO addedMVTAO = applicatifITRepo.saveForMVT(new ApplicatifIT(codeMVT, libMVT, subsidiaryMVT));
        assertFalse(addedMVTAO.getID()==1);

        activeObjects.flushAll();

        final ApplicatifITAO[] applicatifITAOs = activeObjects.find(ApplicatifITAO.class);
        assertEquals(2, applicatifITAOs.length);
        assertEquals(codeCNTL, applicatifITAOs[0].getCode());
        assertEquals(codeMVT, applicatifITAOs[1].getCode());
        assertEquals(libCNTL, applicatifITAOs[0].getLib());
        assertEquals(libMVT, applicatifITAOs[1].getLib());
        assertEquals(subsidiaryCNTL, applicatifITAOs[0].getSubsidiary());
        assertEquals(subsidiaryMVT, applicatifITAOs[1].getSubsidiary());
        assertEquals(true, applicatifITAOs[0].isActive());*/
    }

    @Test
    public void retrieveAllTest(){
        /*
        activeObjects.migrate(ApplicatifITAO.class);
        assertTrue(applicatifITRepo.retrievesAllCNTLBySubsidiary(subsidiaryCNTL).isEmpty());
        assertTrue(applicatifITRepo.retrievesEnabledMVTBySubsidiary(subsidiaryMVT).isEmpty());

        final ApplicatifITAO applicatifITCNTLAO = activeObjects.create(ApplicatifITAO.class);
        applicatifITCNTLAO.setCode(codeCNTL);
        applicatifITCNTLAO.setLib(libCNTL);
        applicatifITCNTLAO.setTyp(ApplicatifIT.typCNTL);
        applicatifITCNTLAO.setSubsidiary(subsidiaryCNTL);
        applicatifITCNTLAO.setActive(true);
        applicatifITCNTLAO.save();

        final ApplicatifITAO applicatifITMVTAO = activeObjects.create(ApplicatifITAO.class);
        applicatifITMVTAO.setCode(codeMVT);
        applicatifITMVTAO.setLib(libMVT);
        applicatifITMVTAO.setTyp(ApplicatifIT.typMVT);
        applicatifITMVTAO.setSubsidiary(subsidiaryMVT);
        applicatifITMVTAO.setActive(true);
        applicatifITMVTAO.save();

        activeObjects.flushAll();

        final List<ApplicatifITAO> applicatifITCNTLAOs = applicatifITRepo.retrievesAllCNTLBySubsidiary(subsidiaryCNTL);
        assertEquals(1, applicatifITCNTLAOs.size());
        assertEquals(applicatifITCNTLAO.getCode(), applicatifITCNTLAOs.get(0).getCode());
        final List<ApplicatifITAO> applicatifITMVTAOs = applicatifITRepo.retrievesAllMVTBySubsidiary(subsidiaryMVT);
        assertEquals(1, applicatifITMVTAOs.size());
        assertEquals(applicatifITMVTAO.getCode(), applicatifITMVTAOs.get(0).getCode());*/
    }
}
