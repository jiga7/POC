package com.tc.labt.sgabs.benchmarkdata.business;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.activeobjects.test.TestActiveObjects;

import net.java.ao.test.junit.ActiveObjectsJUnitRunner;
import net.java.ao.EntityManager;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.Date;

import static org.junit.Assert.*;

@RunWith(ActiveObjectsJUnitRunner.class)
public class MethodControlRepoTest {

    private EntityManager entityManager;

    private MethodControlRepo methodControlRepo;

    private ActiveObjects activeObjects;

    @Before
    public void setUp() throws Exception{
        assertNotNull(entityManager);
        activeObjects = new TestActiveObjects(entityManager);
        //methodControlRepo = new MethodControlRepo(activeObjects);
    }

    @After
    public void tearDown() throws Exception{ }

    final String code = "COHE";
    final String method = "Cohérences des comptes";
    final String subsidiary = "SGBS";
    final Date created = new Date();
    final boolean active = true;

    @Test
    public void saveTest() throws Exception
    {
        /*activeObjects.migrate(MethodControlAO.class);

        assertEquals(0, activeObjects.find(MethodControlAO.class).length);

        final MethodControlAO addedAO = methodControlRepo.save(new MethodControl(code, method, subsidiary, created, active));
        assertFalse(addedAO.getID() == 0);

        activeObjects.flushAll();

        final MethodControlAO[] methodControlAOs = activeObjects.find(MethodControlAO.class);
        assertEquals(1, methodControlAOs.length);
        assertEquals(code, methodControlAOs[0].getCode());
        assertEquals(method, methodControlAOs[0].getMethod());
        assertEquals(active, methodControlAOs[0].isActive());*/
    }

    @Test
    public void enableOrDisableTest() throws Exception{

    }

    @Test
    public void retrievesAll() throws Exception{
        /*activeObjects.migrate(MethodControlAO.class);

        assertTrue(methodControlRepo.retrievesBySubsidiary(subsidiary).isEmpty());

        final MethodControlAO methodControlAO = activeObjects.create(MethodControlAO.class);
        methodControlAO.setCode(code);
        methodControlAO.setMethod(method);
        methodControlAO.setSubsidiary(subsidiary);
        methodControlAO.setCreated(created);
        methodControlAO.setActive(active);
        methodControlAO.save();

        activeObjects.flushAll();

        final List<MethodControlAO> methodControlAOs = methodControlRepo.retrievesBySubsidiary(subsidiary);
        assertEquals(1, methodControlAOs.size());
        assertEquals(methodControlAO.getID(), methodControlAOs.get(0).getID());*/
    }

    @Test
    public void retrievesEnabled() throws Exception{

    }
}
