package com.tc.labt.sgabs.benchmarkdata.business;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.activeobjects.test.TestActiveObjects;


import net.java.ao.test.junit.ActiveObjectsJUnitRunner;
import net.java.ao.EntityManager;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import static org.junit.Assert.*;

@RunWith(ActiveObjectsJUnitRunner.class)
public class LogAuditRepoTest {

    private EntityManager entityManager;

    private LogAuditRepo logAuditRepo;

    private ActiveObjects activeObjects;

    @Before
    public void setUp() throws Exception {
        assertNotNull(entityManager);
        activeObjects = new TestActiveObjects(entityManager);
        //logAuditRepo = new LogAuditRepo(activeObjects);
    }

    @After
    public void tearDown() throws Exception{
    }

    @Test
    public void saveTest() throws Exception{

    }

    @Test
    public void retrievesAll() throws Exception{

    }
}
