package com.tc.labt.sgabs.benchmarkdata.business;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.activeobjects.test.TestActiveObjects;

import net.java.ao.test.junit.ActiveObjectsJUnitRunner;
import net.java.ao.EntityManager;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import static org.junit.Assert.*;

@RunWith(ActiveObjectsJUnitRunner.class)
public class FileLoadedAuditRepoTest {

    private EntityManager entityManager;

    private FileLoadedAuditRepo fileLoadedAuditRepo;

    private ActiveObjects activeObjects;

    @Before
    public void setUp() throws Exception{
        assertNotNull(entityManager);
        activeObjects = new TestActiveObjects(entityManager);
        //fileLoadedAuditRepo = new FileLoadedAuditRepo(activeObjects);
    }

    @After
    public void tearDown() throws Exception{
    }

    final String subsidiary = "SGBS";
    final String path = "C://Folder";
    final String filename = "recalcitrant.txt";

    @Test
    public void saveTest() throws Exception{
        /*activeObjects.migrate(FileLoadedAuditAO.class);

        assertEquals(0, activeObjects.find(FileLoadedAuditAO.class).length);

        final FileLoadedAuditAO addedAO = fileLoadedAuditRepo.save(new FileLoadedAudit(subsidiary, path, filename));
        assertFalse(addedAO.getID() == 0);

        activeObjects.flushAll();

        final FileLoadedAuditAO[] fileLoadedAuditAOs = activeObjects.find(FileLoadedAuditAO.class);
        assertEquals(1, fileLoadedAuditAOs.length);
        assertEquals(subsidiary, fileLoadedAuditAOs[0].getSubsidiary());
        assertEquals(path, fileLoadedAuditAOs[0].getPath());
        assertEquals(filename, fileLoadedAuditAOs[0].getFilename());*/
    }

    @Test
    public void retrievesAll() throws Exception{
        /*activeObjects.migrate(FileLoadedAuditAO.class);

        assertTrue(fileLoadedAuditRepo.retrievesAll().isEmpty());

        final FileLoadedAuditAO fileLoadedAuditAO = activeObjects.create(FileLoadedAuditAO.class);
        fileLoadedAuditAO.setFilename(filename);
        fileLoadedAuditAO.setSubsidiary(subsidiary);
        fileLoadedAuditAO.setPath(path);
        fileLoadedAuditAO.setReceived(new Date());
        fileLoadedAuditAO.save();

        activeObjects.flushAll();

        final List<FileLoadedAuditAO> fileLoadedAuditAOs = fileLoadedAuditRepo.retrievesBySubsidiary(subsidiary, 1 , 10);
        assertEquals(1, fileLoadedAuditAOs.size());
        assertEquals(fileLoadedAuditAO.getFilename(), fileLoadedAuditAOs.get(0).getFilename());*/
    }
}
