package com.tc.labt.sgabs.benchmarkdata.business;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.activeobjects.test.TestActiveObjects;

import net.java.ao.test.junit.ActiveObjectsJUnitRunner;
import net.java.ao.EntityManager;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import static org.junit.Assert.*;

@RunWith(ActiveObjectsJUnitRunner.class)
public class OperationRepoTest {

    private EntityManager entityManager;

    private OperationRepo operationRepo;

    private ActiveObjects activeObjects;

    @Before
    public void setUp() throws Exception{
        assertNotNull(entityManager);
        activeObjects = new TestActiveObjects(entityManager);
        //operationRepo = new OperationRepo(activeObjects);
    }

    @After
    public void tearDown() throws Exception{

    }

    private final String ope = "Debt";
    private final String lib = "Débit";
    private final String subsidiary = "SGCB";

    @Test
    public void saveTest() throws Exception{

        /*activeObjects.migrate(OperationAO.class);
        assertEquals(0, activeObjects.find(OperationAO.class).length);

        final OperationAO addedAO = operationRepo.save(new Operation(ope, lib, subsidiary));
        assertFalse(addedAO.getID() == 0);

        activeObjects.flushAll();

        final OperationAO[] operationAOs = activeObjects.find(OperationAO.class);
        assertEquals(1, operationAOs.length);
        assertEquals(ope, operationAOs[0].getOpe());
        assertEquals(lib, operationAOs[0].getLib());
        assertEquals(subsidiary, operationAOs[0].getSubsidiary());
        assertEquals(true, operationAOs[0].isActive());*/
    }

    @Test
    public void retrievesEnabledTest() throws Exception{
        /*activeObjects.migrate(OperationAO.class);

        assertTrue(operationRepo.retrievesAll().isEmpty());

        final OperationAO operationAO = activeObjects.create(OperationAO.class);
        operationAO.setOpe(ope);
        operationAO.setLib(lib);
        operationAO.setSubsidiary(subsidiary);
        operationAO.setActive(false);
        operationAO.save();

        activeObjects.flushAll();

        final List<OperationAO> operationAOsEnabled = operationRepo.retrievesEnabled();
        assertEquals(0, operationAOsEnabled.size());

        final List<OperationAO> operationAOs = operationRepo.retrievesAll();
        assertEquals(1, operationAOs.size());
        assertEquals(operationAO.getID(), operationAOs.get(0).getID());*/
    }
}
