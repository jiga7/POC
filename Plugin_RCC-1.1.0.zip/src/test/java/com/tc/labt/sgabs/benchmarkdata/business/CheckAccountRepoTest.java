package com.tc.labt.sgabs.benchmarkdata.business;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.activeobjects.test.TestActiveObjects;

import net.java.ao.EntityManager;
import net.java.ao.test.junit.ActiveObjectsJUnitRunner;
import org.junit.Before;
import org.junit.After;
import org.junit.Test;
import org.junit.runner.RunWith;

import static org.junit.Assert.*;

@RunWith(ActiveObjectsJUnitRunner.class)
public class CheckAccountRepoTest {

    private EntityManager entityManager;

    private CheckAccountRepo checkAccountRepo;

    private ActiveObjects activeObjects;

    @Before
    public void setUp() throws Exception{
        assertNotNull(entityManager);
        activeObjects = new TestActiveObjects(entityManager);
        //checkAccountRepo= new CheckAccountRepo(activeObjects);
    }

    @After
    public void tearDown() throws Exception{

    }

    final String subsidiary= "SGBS";

    @Test
    public void savePCITest() throws Exception
    {
        /*activeObjects.migrate(CheckAccountAO.class);
      //  assertEquals(0, activeObjects.find(CheckAccountAO.class).length);
        final CheckAccountAO checkAccountAO = checkAccountRepo.savePCI(new CheckAccount("0150109921324340", "20221", "Epargne particulier", "0129328942", "Epargne particulier XOF - 012", "099", "XOF", "01501", "OUV", "O", "C", "SGBS"));
        assertTrue(checkAccountAO.getKey().equals("0150109921324340"));

        activeObjects.flushAll();

        final CheckAccountAO[] checkAccountAOs = activeObjects.find(CheckAccountAO.class);
        assertEquals("20221", checkAccountAOs[0].getChap());
        assertEquals("Epargne particulier", checkAccountAOs[0].getLib_chap());
        assertEquals("XOF", checkAccountAOs[0].getLib_dev());
        assertEquals("099", checkAccountAOs[0].getDev());
        assertEquals("C", checkAccountAOs[0].getSbi());*/
    }

    @Test
    public void updateHorsPCITest() throws Exception{
        /*activeObjects.migrate(CheckAccountAO.class);
       // assertTrue(checkAccountRepo.retrievesAllBySubsidiary(subsidiary).isEmpty());

        CheckAccount checkAccount = new CheckAccount("0150109921324340", "20221", "Epargne particulier", "0129328942", "Epargne particulier XOF - 012", "099", "XOF", "01501", "OUV", "O", "C", "SGBS");
        checkAccountRepo.savePCI(checkAccount);

        checkAccount.setOfficer("djiga@talentsconsult.org");
        checkAccount.setOfficerFullname("El Hadj Farba Touré");
        checkAccount.setDuration(10);
        checkAccount.setValidor1("farba@talentsconsult.com");
        checkAccount.setValidor1Fullname("El Hadji Farba Touré");
        checkAccount.setDurationValid1(5);
        checkAccount.setValidor2("hamacire@talentsconsult.org");
        checkAccount.setValidor2Fullname("Hamacire El Hadj Kalil");
        checkAccount.setDurationValid2(7);

        final CheckAccountAO checkAccountAO = checkAccountRepo.updateHorsPCI(checkAccount);
        assertTrue(checkAccountAO.getKey().equals("0150109921324340"));

        activeObjects.flushAll();

        final CheckAccountAO[] checkAccountAOs = activeObjects.find(CheckAccountAO.class);
        assertEquals("20221", checkAccountAOs[0].getChap());
        assertEquals("Epargne particulier", checkAccountAOs[0].getLib_chap());
        assertEquals("XOF", checkAccountAOs[0].getLib_dev());
        assertEquals("099", checkAccountAOs[0].getDev());
        assertEquals("C", checkAccountAOs[0].getSbi());

       // assertEquals("User who update", checkAccountAOs[0].getUpdatedBy());

        assertEquals("farba@talentsconsult.com", checkAccountAOs[0].getValidor1());
        assertEquals("djiga@talentsconsult.org", checkAccountAOs[0].getOfficer());
        assertEquals("hamacire@talentsconsult.org", checkAccountAOs[0].getValidor2());
        assertTrue(5 == checkAccountAOs[0].getDurationValid1());
        assertTrue(7 == checkAccountAOs[0].getDurationValid2());*/
    }
}
