package com.tc.labt.sgabs.benchmarkdata.configuration;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.activeobjects.test.TestActiveObjects;
import com.tc.labt.sgabs.benchmarkdata.configuration.database.DatabaseType;
import com.tc.labt.sgabs.benchmarkdata.configuration.database.DatasourceType;
import com.tc.labt.sgabs.benchmarkdata.configuration.database.ao.DatabaseAO;
import com.tc.labt.sgabs.benchmarkdata.configuration.database.ao.DatasourceAO;
import com.tc.labt.sgabs.benchmarkdata.configuration.database.dao.DatabaseDAOHandler;
import com.tc.labt.sgabs.benchmarkdata.configuration.database.dao.DatasourceDAOHandler;
import com.tc.labt.sgabs.benchmarkdata.configuration.database.dto.DatabaseDTO;
import com.tc.labt.sgabs.benchmarkdata.configuration.database.dto.DatasourceDTO;
import com.tc.labt.sgabs.benchmarkdata.configuration.database.repo.DatabaseManagerRepo;
import net.java.ao.EntityManager;
import net.java.ao.test.jdbc.NonTransactional;
import net.java.ao.test.junit.ActiveObjectsJUnitRunner;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.List;
import java.util.stream.Collectors;

@RunWith(ActiveObjectsJUnitRunner.class)
public class DatabaseRepoTest {

    private EntityManager entityManager;
    private ActiveObjects activeObjects;
    private DatabaseDAOHandler daoHandler;
    private DatabaseManagerRepo databaseManagerRepo;

    private static final String databaseHost = "localhost";
    private static final String databasePort = "5433";
    private static final String databaseName = "postgres";
    private static final String databaseLogin = "postgres";
    private static final String databasePassword = "123";
    private static final String databaseSchema = "public";
    private static final String databaseService = null;

    private static final String datasourceName= "SGBS";

    @Before
    public void setUp() throws Exception{
        Assert.assertNotNull(entityManager);
        this.activeObjects = new TestActiveObjects(entityManager);
        this.daoHandler = new DatabaseDAOHandler(activeObjects, new DatasourceDAOHandler(activeObjects));
        this.databaseManagerRepo = new DatabaseManagerRepo(activeObjects, daoHandler);
    }

    @After
    public void tearDown() throws Exception{ }

    @Test
    @NonTransactional
    public void saveDatabase() throws Exception {
        this.activeObjects.migrate(DatabaseAO.class);

        Assert.assertEquals(0, this.activeObjects.find(DatabaseAO.class).length);

        DatabaseDTO databaseDTO = this.databaseManagerRepo.create(new DatabaseDTO(null, databaseName, DatabaseType.POSTGRESQL, databaseHost,databaseLogin,databasePassword,null, null, databasePort,databaseSchema,databaseService, new DatasourceDTO(null, DatasourceType.DATABASE, datasourceName)));
        Assert.assertFalse(0 == databaseDTO.getId());

        activeObjects.flushAll();

        DatabaseAO databaseAO = this.activeObjects.get(DatabaseAO.class, databaseDTO.getId());

        Assert.assertEquals(databaseAO.getHost(), databaseHost);
        Assert.assertEquals(databaseAO.getName(), databaseName);
        Assert.assertEquals(databaseAO.getPort(), databasePort);
        Assert.assertEquals(databaseAO.getType(), DatabaseType.POSTGRESQL);
        Assert.assertEquals(databaseAO.getSchema(), databaseSchema);
        Assert.assertEquals(databaseAO.getLogin(), databaseLogin);
        //Assert.assertEquals(databaseAO.getPassword(), databasePassword);
        Assert.assertEquals(databaseAO.getService(), databaseService);
        Assert.assertEquals(databaseAO.getDatasourceAO().getType(), DatasourceType.DATABASE);
        Assert.assertEquals(databaseAO.getDatasourceAO().getName(), datasourceName);
    }

    @Test
    public void getAll() throws Exception{
        this.activeObjects.migrate(DatabaseAO.class);

        DatasourceAO datasourceAO = this.activeObjects.create(DatasourceAO.class);
        datasourceAO.setName(datasourceName);
        datasourceAO.setType(DatasourceType.DATABASE);
        datasourceAO.save();

        DatabaseAO databaseAO = this.activeObjects.create(DatabaseAO.class);
        databaseAO.setName(databaseName);
        databaseAO.setHost(databaseHost);
        databaseAO.setType(DatabaseType.POSTGRESQL);
        databaseAO.setPort(databasePort);
        databaseAO.setSchema(databaseSchema);
        databaseAO.setService(databaseService);
        databaseAO.setLogin(databaseLogin);
        databaseAO.setPassword(databasePassword);
        databaseAO.setDatasourceAO(datasourceAO);
        databaseAO.save();

        this.activeObjects.flushAll();

        List<DatabaseAO> databasesAO = this.databaseManagerRepo.getAll().parallelStream().collect(Collectors.toList());
        Assert.assertEquals(1, databasesAO.size());
        Assert.assertEquals(DatabaseType.POSTGRESQL, databasesAO.get(0).getType());
        Assert.assertEquals(databaseHost, databasesAO.get(0).getHost());
        Assert.assertEquals(databaseLogin, databasesAO.get(0).getLogin());
        Assert.assertEquals(databasePort, databasesAO.get(0).getPort());
        Assert.assertEquals(datasourceName, databasesAO.get(0).getDatasourceAO().getName());

        DatabaseDTO dDTO = this.databaseManagerRepo.getByDatasourceName(datasourceName);
        Assert.assertTrue(dDTO!=null);
        Assert.assertEquals(DatabaseType.POSTGRESQL, dDTO.getType());
        Assert.assertEquals(databaseHost, dDTO.getHost());
        Assert.assertEquals(databaseLogin, dDTO.getLogin());
        Assert.assertEquals(databasePort, dDTO.getPort());
    }
}
