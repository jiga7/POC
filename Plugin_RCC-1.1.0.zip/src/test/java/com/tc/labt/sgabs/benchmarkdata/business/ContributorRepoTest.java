package com.tc.labt.sgabs.benchmarkdata.business;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.activeobjects.test.TestActiveObjects;

import net.java.ao.test.junit.ActiveObjectsJUnitRunner;
import net.java.ao.EntityManager;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import static org.junit.Assert.*;

@RunWith(ActiveObjectsJUnitRunner.class)
public class ContributorRepoTest {

    private EntityManager entityManager;

    private ContributorRepo contributorRepo;

    private ActiveObjects activeObjects;

    @Before
    public void setUp() throws Exception{
        assertNotNull(entityManager);
        activeObjects = new TestActiveObjects(entityManager);
        //contributorRepo = new ContributorRepo(activeObjects);
    }

    @After
    public void tearDown() throws Exception{
    }

    final String username = "farba.elhadj";
    final String fullname = "El Hadj Farba TOURE";
    final String subsidiary = "SGBS";

    @Test
    public void saveTest() throws Exception{
        /*activeObjects.migrate(ContributorAO.class);

        assertEquals(0, activeObjects.find(ContributorAO.class).length);

        final ContributorAO addedAO = contributorRepo.saveOrRetrieves(new Contributor(username, fullname, subsidiary));
        assertFalse(addedAO.getID() == 0);

        activeObjects.flushAll();

        final ContributorAO[] contributorAOs = activeObjects.find(ContributorAO.class);
        assertEquals(1, contributorAOs.length);
        assertEquals(username, contributorAOs[0].getUsername());
        assertEquals(subsidiary, contributorAOs[0].getSubsidiary());
        assertEquals(fullname, contributorAOs[0].getFullname());*/
    }
}
