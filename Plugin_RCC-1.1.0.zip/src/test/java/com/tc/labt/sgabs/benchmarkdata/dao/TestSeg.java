package com.tc.labt.sgabs.benchmarkdata.dao;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.activeobjects.test.TestActiveObjects;
import com.tc.labt.sgabs.benchmarkdata.ao.MethodControlAO;
import com.tc.labt.sgabs.benchmarkdata.configuration.database.DatabaseType;
import com.tc.labt.sgabs.benchmarkdata.configuration.database.DatasourceType;
import com.tc.labt.sgabs.benchmarkdata.configuration.database.ao.DatabaseAO;
import com.tc.labt.sgabs.benchmarkdata.configuration.database.dao.DatabaseDAOHandler;
import com.tc.labt.sgabs.benchmarkdata.configuration.database.dao.DatasourceDAOHandler;
import com.tc.labt.sgabs.benchmarkdata.configuration.database.dto.DatabaseDTO;
import com.tc.labt.sgabs.benchmarkdata.configuration.database.dto.DatasourceDTO;
import com.tc.labt.sgabs.benchmarkdata.configuration.database.repo.DatabaseManagerRepo;
import com.tc.labt.sgabs.benchmarkdata.configuration.service.DatasourceConfigurationService;
import com.tc.labt.sgabs.benchmarkdata.dto.MethodControl;
import com.tc.labt.sgabs.benchmarkdata.business.MethodControlRepo;
import net.java.ao.EntityManager;
import net.java.ao.test.jdbc.NonTransactional;
import net.java.ao.test.junit.ActiveObjectsJUnitRunner;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.Date;

import static org.junit.Assert.*;

@RunWith(ActiveObjectsJUnitRunner.class)
public class TestSeg {

    private EntityManager entityManager;

    private ActiveObjects activeObjects, businessActiveObjects;

    private MethodControlRepo methodControlRepo;

    private DatabaseDAOHandler daoHandler;
    private DatabaseManagerRepo databaseManagerRepo;

    private static final String databaseHost = "localhost";
    private static final String databasePort = "5433";
    private static final String databaseName = "segregation"; //postgres
    private static final String databaseLogin = "postgres";
    private static final String databasePassword = "123";
    private static final String databaseSchema = "public";
    private static final String databaseService = null;

    private static final String datasourceName= "SGBS";

    private final static String _SUFFIXE_URL = "?useSSL=false&useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";

    final String code = "COHE";
    final String method = "Cohérences des comptes";
    final String subsidiary = "SGBS";
    final Date created = new Date();
    final boolean active = true;

    @Before
    public void setUp() throws Exception{
        Assert.assertNotNull(entityManager);
        this.activeObjects = new TestActiveObjects(entityManager);
        this.daoHandler = new DatabaseDAOHandler(activeObjects, new DatasourceDAOHandler(activeObjects));
        this.databaseManagerRepo = new DatabaseManagerRepo(activeObjects, daoHandler);
    }

    @Test
    @NonTransactional
    public void saveTest() throws Exception{

        this.activeObjects.migrate(DatabaseAO.class);

        Assert.assertEquals(0, this.activeObjects.find(DatabaseAO.class).length);

        DatabaseDTO databaseDTO = this.databaseManagerRepo.create(new DatabaseDTO(null, databaseName, DatabaseType.POSTGRESQL, databaseHost,databaseLogin,databasePassword,null, null, databasePort,databaseSchema,databaseService, new DatasourceDTO(null, DatasourceType.DATABASE, datasourceName)));
        Assert.assertFalse(0 == databaseDTO.getId());

        activeObjects.flushAll();

        DatasourceConfigurationService configurationService = new DatasourceConfigurationService(databaseManagerRepo);
        configurationService.initDatabase(datasourceName);
        this.businessActiveObjects =  configurationService.getActiveObjects(datasourceName); //TestActiveObjects(entityManager);
        this.methodControlRepo = new MethodControlRepo(configurationService);

        // ---------------------------------------------------

        try{ businessActiveObjects.migrate(MethodControlAO.class);} catch (Exception e) {}

        assertEquals(0, businessActiveObjects.find(MethodControlAO.class).length);

        final MethodControlAO addedAO = methodControlRepo.save(new MethodControl(code, method, subsidiary, created, active));
        assertFalse(addedAO.getID() <= 0);

        businessActiveObjects.flushAll();

        final MethodControlAO[] methodControlAOs = businessActiveObjects.find(MethodControlAO.class);
        assertEquals(1, methodControlAOs.length);
        assertEquals(code, methodControlAOs[0].getCode());
        assertEquals(method, methodControlAOs[0].getMethod());
        assertEquals(active, methodControlAOs[0].isActive());
    }

    @After
    public void tearDown() throws Exception{ }
}
