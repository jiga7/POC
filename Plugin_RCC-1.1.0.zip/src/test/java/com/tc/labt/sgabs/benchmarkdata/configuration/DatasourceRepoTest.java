package com.tc.labt.sgabs.benchmarkdata.configuration;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.activeobjects.test.TestActiveObjects;
import com.tc.labt.sgabs.benchmarkdata.configuration.database.DatasourceType;
import com.tc.labt.sgabs.benchmarkdata.configuration.database.ao.DatasourceAO;
import com.tc.labt.sgabs.benchmarkdata.configuration.database.dao.DatasourceDAOHandler;
import com.tc.labt.sgabs.benchmarkdata.configuration.database.dto.DatasourceDTO;
import com.tc.labt.sgabs.benchmarkdata.configuration.database.repo.AbstractManager;
import com.tc.labt.sgabs.benchmarkdata.configuration.database.repo.DataSourceManagerRepo;
import net.java.ao.EntityManager;
import net.java.ao.test.jdbc.NonTransactional;
import net.java.ao.test.junit.ActiveObjectsJUnitRunner;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@RunWith(ActiveObjectsJUnitRunner.class)
public class DatasourceRepoTest {

    private EntityManager entityManager;
    private ActiveObjects activeObjects;

    private DatasourceDAOHandler daoHandler;
    private AbstractManager dataSourceManagerRepo;

    private static final String datasourceName= "SGBS";

    @Before
    public void setUp() throws Exception{
        Assert.assertNotNull(entityManager);
        this.activeObjects = new TestActiveObjects(entityManager);
        this.daoHandler = new DatasourceDAOHandler(activeObjects);
        dataSourceManagerRepo = new DataSourceManagerRepo(activeObjects, daoHandler);
    }

    @Test
    @NonTransactional
    public void saveDatasource() throws Exception{
        activeObjects.migrate(DatasourceAO.class);

        Assert.assertEquals(0, this.activeObjects.find(DatasourceAO.class).length);
        DatasourceDTO dto = new DatasourceDTO(null, DatasourceType.DATABASE, datasourceName);

        DatasourceDTO datasourceDTO = (DatasourceDTO) this.dataSourceManagerRepo.create(dto);

        Assert.assertFalse(0 == datasourceDTO.getId());

        this.activeObjects.flushAll();

        DatasourceAO datasourceAO = this.activeObjects.get(DatasourceAO.class, datasourceDTO.getId());
        Assert.assertEquals(datasourceAO.getType(), DatasourceType.DATABASE);
        Assert.assertEquals(datasourceAO.getName(), datasourceName);
    }

    @Test
    public void getAll() throws Exception{
        activeObjects.migrate(DatasourceAO.class);

        DatasourceAO datasourceAO  = activeObjects.create(DatasourceAO.class);
        datasourceAO.setType(DatasourceType.DATABASE);
        datasourceAO.setName(datasourceName);
        datasourceAO.save();

        this.activeObjects.flushAll();

        List<DatasourceAO> daos = (List<DatasourceAO>) dataSourceManagerRepo.getAll();
        Assert.assertEquals(1, daos.size());

        Assert.assertEquals(datasourceName, daos.get(0).getName());
        Assert.assertEquals(DatasourceType.DATABASE, daos.get(0).getType());
    }
}
