package com.tc.labt.sgabs.benchmarkdata.business;

import com.atlassian.activeobjects.external.ActiveObjects;
import com.atlassian.activeobjects.test.TestActiveObjects;

import net.java.ao.test.junit.ActiveObjectsJUnitRunner;
import net.java.ao.EntityManager;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import static org.junit.Assert.*;

@RunWith(ActiveObjectsJUnitRunner.class)
public class ReportingRepoTest {

    private EntityManager entityManager;

    private ReportingRepo reportingRepo;

    private ActiveObjects activeObjects;

    @Before
    public void setUp() throws Exception{
        assertNotNull(entityManager);
        activeObjects = new TestActiveObjects(entityManager);
        //reportingRepo = new ReportingRepo(activeObjects);
    }

    @After
    public void tearDown() throws Exception{

    }

    final String code = "ANNUE";
    final String lib = "Reporting annuel";
    final String subsidiary = "SGBS";

    @Test
    public void saveTest() throws Exception{
        /*activeObjects.migrate(ReportingAO.class);

        assertEquals(0, activeObjects.find(ReportingAO.class).length);

        final ReportingAO addedAO = reportingRepo.save(new Reporting(code, lib, subsidiary));
        assertFalse(addedAO.getID()==0);

        activeObjects.flushAll();

        final ReportingAO[] reportingAOs = activeObjects.find(ReportingAO.class);
        assertEquals(1, reportingAOs.length);
        assertEquals(code, reportingAOs[0].getCode());
        assertEquals(lib, reportingAOs[0].getLib());
        assertEquals(true, reportingAOs[0].isActive());*/
    }

    public void retrievesAll() throws Exception{
        /*activeObjects.migrate(ReportingAO.class);

        assertTrue(reportingRepo.retrievesBySubsidiary(subsidiary).isEmpty());

        final ReportingAO reportingAO = activeObjects.create(ReportingAO.class);
        reportingAO.setCode(code);
        reportingAO.setLib(lib);
        reportingAO.setActive(true);
        reportingAO.save();

        activeObjects.flushAll();

        final List<ReportingAO> reportingAOs = reportingRepo.retrievesBySubsidiary(subsidiary);
        assertEquals(1, reportingAOs.size());
        assertEquals(reportingAO.getID(), reportingAOs.get(0).getID());*/
    }
}
